// Python cells in Quarto documents, run by the LabTeX helper on a user's own computer.
//
//  - A user pairs a helper (labtex_helper.py) with a one-time code; the helper gets a token.
//  - The helper long-polls /api/helper/next. "Run Python" in a project creates a run for one of the
//    requester's own helpers; the helper may ask its owner to approve the code, runs the cells with the
//    chosen interpreter and local datasets, and posts the outputs back.
//  - Outputs are stored per cell, keyed by a hash of the cell's code. Renders reuse them (see quarto.js),
//    so teammates see the results without a helper; outputs whose code has changed are marked stale.
import crypto from 'node:crypto';
import path from 'node:path';
import { zipSync } from 'fflate';
import { db, newId, now } from './db.js';
import { roleFor, atLeast, requireUser, projectAccess } from './auth.js';
import { getFileText, flushProject, emitProject } from './collab.js';

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const ONLINE_MS = 45000;
const MAX_OUTPUT_BYTES = 20 * 1024 * 1024;   // per cell
const RUN_START_TIMEOUT = 90e3;              // helper must pick the run up within this
const RUN_MAX_MS = 3 * 3600e3;

// ---------------------------------------------------------------------------
// Finding Python cells in a .qmd
// ---------------------------------------------------------------------------

/** Expand {{< include file >}} (relative to the including file), like Quarto does before running. */
export function expandIncludes(text, fromPath, readFile, depth = 0) {
  return text.replace(/^[ \t]*\{\{<\s*include\s+([^\s>]+)\s*>\}\}[ \t]*$/gm, (all, rel) => {
    const p = path.posix.normalize(path.posix.join(path.posix.dirname(fromPath), rel.replace(/^["']|["']$/g, '')));
    if (depth > 8 || p.startsWith('..')) return all;
    const t = readFile(p);
    return t == null ? all : expandIncludes(t.replace(/^---[ \t]*\r?\n[\s\S]*?\r?\n---[ \t]*\r?\n/, ''), p, readFile, depth + 1);
  });
}

/** The executable part of a cell (without "#|" option lines), normalised for hashing. */
export const cellBody = (code) => code.split('\n').filter((l) => !/^\s*#\|/.test(l)).map((l) => l.replace(/\s+$/, '')).join('\n').replace(/^\n+|\n+$/g, '');
export const cellHash = (code) => sha(cellBody(code)).slice(0, 20);

/** Python cells in document order: { index, code, hash, line, eval }. */
export function parsePythonCells(text) {
  const lines = text.split('\n');
  const cells = [];
  let open = null;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!open) {
      const m = l.match(/^\s*(`{3,}|~{3,})\s*(\{[^}]*\}|[\w.+-]*)?\s*$/);
      if (!m) continue;
      const py = m[2] && /^\{\s*python\b/i.test(m[2]);
      open = { fence: m[1], start: i, py, body: [] };
    } else if (new RegExp(`^\\s*${open.fence[0] === '`' ? '`' : '~'}{${open.fence.length},}\\s*$`).test(l)) {
      if (open.py) {
        const code = open.body.join('\n');
        const opts = Object.fromEntries(open.body.filter((x) => /^\s*#\|/.test(x)).map((x) => x.replace(/^\s*#\|\s*/, '').split(/:\s*/)).filter((kv) => kv[0]).map(([k, ...v]) => [k.trim(), v.join(':').trim()]));
        cells.push({ index: cells.length, code, hash: cellHash(code), line: open.start + 1, eval: !/^false$/i.test(opts.eval || '') });
      }
      open = null;
    } else open.body.push(l);
  }
  return cells;
}

/** Read a project's text file by path (live text, including unsaved edits). */
function projectReader(pid) {
  return (p) => {
    const f = db.prepare('SELECT id,is_binary FROM files WHERE project_id=? AND path=?').get(pid, p);
    return f && !f.is_binary ? getFileText(f.id) : null;
  };
}
export function projectCells(pid, mainPath) {
  const read = projectReader(pid);
  const text = read(mainPath);
  if (text == null) return [];
  return parsePythonCells(expandIncludes(text, mainPath, read));
}

// ---------------------------------------------------------------------------
// Saved outputs
// ---------------------------------------------------------------------------

/**
 * Saved outputs for a list of cells: [{ outputs, stale, runId }] aligned with `cells` (null = none).
 * Same code -> latest outputs for that code. Changed code -> the outputs last produced at that position,
 * marked stale.
 */
export function savedOutputs(pid, file, cells) {
  const byHash = db.prepare('SELECT outputs, run_id FROM py_cells WHERE project_id=? AND file_path=? AND code_hash=? ORDER BY created_at DESC LIMIT 1');
  const last = db.prepare("SELECT id FROM py_runs WHERE project_id=? AND file_path=? AND id IN (SELECT run_id FROM py_cells) ORDER BY finished_at DESC LIMIT 1").get(pid, file);
  const byIndex = last ? db.prepare('SELECT outputs, run_id, code_hash FROM py_cells WHERE run_id=? AND cell_index=?') : null;
  return cells.map((c) => {
    const r = byHash.get(pid, file, c.hash);
    if (r) return { outputs: JSON.parse(r.outputs), stale: false, runId: r.run_id };
    const s = byIndex?.get(last.id, c.index);
    if (s) return { outputs: JSON.parse(s.outputs), stale: true, runId: s.run_id };
    return null;
  });
}
export const hasSavedOutputs = (pid, file) => !!db.prepare('SELECT 1 FROM py_cells WHERE project_id=? AND file_path=? LIMIT 1').get(pid, file);

function runInfo(r) {
  if (!r) return null;
  const who = r.requested_by ? db.prepare('SELECT name FROM users WHERE id=?').get(r.requested_by)?.name : null;
  const helper = r.helper_id ? db.prepare('SELECT name FROM helpers WHERE id=?').get(r.helper_id)?.name : null;
  return {
    id: r.id, file: r.file_path, status: r.status, progress: r.progress, total: r.total, message: r.message,
    by: who, helper, env: r.env ? JSON.parse(r.env) : null, data: r.data ? JSON.parse(r.data) : null,
    created_at: r.created_at, started_at: r.started_at, finished_at: r.finished_at,
  };
}

/** Everything the editor shows about Python in a project. */
export function pythonState(pid, file) {
  const cells = projectCells(pid, file);
  const saved = savedOutputs(pid, file, cells);
  const lastDone = db.prepare("SELECT * FROM py_runs WHERE project_id=? AND file_path=? AND status IN ('done','failed') ORDER BY finished_at DESC LIMIT 1").get(pid, file);
  const active = db.prepare("SELECT * FROM py_runs WHERE project_id=? AND status IN ('queued','awaiting_approval','running') ORDER BY created_at DESC LIMIT 1").get(pid);
  return {
    file,
    cells: cells.map((c, i) => ({ index: c.index, line: c.line, eval: c.eval, status: !c.eval ? 'skipped' : !saved[i] ? 'missing' : saved[i].stale ? 'stale' : 'fresh' })),
    lastRun: runInfo(lastDone), activeRun: runInfo(active),
    datasets: datasetsOf(pid),
  };
}
export const datasetsOf = (pid) => { try { return JSON.parse(db.prepare('SELECT py_datasets FROM projects WHERE id=?').get(pid)?.py_datasets || '[]'); } catch { return []; } };

// ---------------------------------------------------------------------------
// Helpers (pairing, tokens, presence)
// ---------------------------------------------------------------------------

const pairCodes = new Map(); // code -> { userId, expires }
const waiters = new Map();   // helperId -> { res, timer }
const isOnline = (h) => waiters.has(h.id) || (h.last_seen_at && Date.now() - h.last_seen_at < ONLINE_MS);
const helperView = (h) => ({ id: h.id, name: h.name, info: h.info ? JSON.parse(h.info) : null, online: isOnline(h), last_seen_at: h.last_seen_at, created_at: h.created_at });

function helperFromRequest(req) {
  const m = (req.headers.authorization || '').match(/^Bearer\s+(\S+)$/);
  if (!m) return null;
  const h = db.prepare('SELECT * FROM helpers WHERE token_hash=?').get(sha(m[1]));
  if (!h) return null;
  const u = db.prepare('SELECT id,name,is_admin,status FROM users WHERE id=?').get(h.user_id);
  if (!u) return null;
  return { helper: h, user: { id: u.id, name: u.name, is_admin: !!u.is_admin, lab_member: !!u.is_admin || u.status === 'active' } };
}
function requireHelper(req, res, next) {
  const r = helperFromRequest(req);
  if (!r) return res.status(401).json({ error: 'This helper is not paired (or was removed in LabTeX). Pair it again: python labtex_helper.py pair <LabTeX address> <code>' });
  req.helper = r.helper; req.helperUser = r.user;
  db.prepare('UPDATE helpers SET last_seen_at=? WHERE id=?').run(Date.now(), r.helper.id);
  next();
}

// ---------------------------------------------------------------------------
// Runs
// ---------------------------------------------------------------------------

function setRun(id, fields) {
  const keys = Object.keys(fields);
  db.prepare(`UPDATE py_runs SET ${keys.map((k) => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map((k) => fields[k]), id);
  const r = db.prepare('SELECT * FROM py_runs WHERE id=?').get(id);
  if (r) emitProject(r.project_id, { type: 'python', run: runInfo(r) });
  return r;
}

/** Has someone other than the helper's owner changed the project since this helper last ran it? */
function othersEdited(pid, helper) {
  const last = db.prepare("SELECT MAX(finished_at) AS t FROM py_runs WHERE project_id=? AND helper_id=? AND status='done'").get(pid, helper.id)?.t || 0;
  const rows = db.prepare('SELECT DISTINCT user_id FROM file_edits WHERE project_id=? AND user_id != ? AND last_at > ?').all(pid, helper.user_id, last);
  // Files nobody is recorded as editing (e.g. older than this feature) are of unknown authorship.
  const unknown = !last && db.prepare("SELECT 1 FROM files f WHERE f.project_id=? AND f.is_binary=0 AND NOT EXISTS (SELECT 1 FROM file_edits e WHERE e.file_id=f.id) LIMIT 1").get(pid);
  const by = rows.map((r) => (r.user_id ? db.prepare('SELECT name FROM users WHERE id=?').get(r.user_id)?.name || 'a former member' : 'an upload, import, restore or conversion'));
  if (unknown && !by.length) by.push('content created before edit tracking');
  return { changed: by.length > 0, by: [...new Set(by)] };
}

function deliver(run) {
  const w = waiters.get(run.helper_id);
  if (!w) return false;
  clearTimeout(w.timer);
  waiters.delete(run.helper_id);
  w.res.json({ run: JSON.parse(run.payload) });
  return true;
}

// Expire runs nobody picked up or that never finished.
setInterval(() => {
  const t = Date.now();
  for (const r of db.prepare("SELECT * FROM py_runs WHERE status IN ('queued','awaiting_approval','running')").all()) {
    if (r.status === 'queued' && t - r.created_at > RUN_START_TIMEOUT) setRun(r.id, { status: 'expired', message: 'The helper didn’t pick up the run. Is it running and connected?', finished_at: t });
    else if (t - r.created_at > RUN_MAX_MS) setRun(r.id, { status: 'expired', message: 'The run took too long and was stopped.', finished_at: t });
  }
}, 15000).unref();

/** Cap and clean outputs from a helper (they are rendered into PDFs and the HTML preview). */
function cleanOutputs(outputs) {
  if (!Array.isArray(outputs)) return [];
  const out = [];
  let bytes = 0;
  for (const o of outputs.slice(0, 200)) {
    if (!o || typeof o !== 'object') continue;
    const t = o.output_type;
    let v;
    if (t === 'stream') v = { output_type: 'stream', name: o.name === 'stderr' ? 'stderr' : 'stdout', text: String(o.text ?? '').slice(0, 200000) };
    else if (t === 'error') v = { output_type: 'error', ename: String(o.ename || 'Error').slice(0, 200), evalue: String(o.evalue || '').slice(0, 5000), traceback: (Array.isArray(o.traceback) ? o.traceback : []).map((x) => String(x).slice(0, 5000)).slice(0, 60) };
    else if (t === 'display_data' || t === 'execute_result') {
      const data = {};
      for (const [k, val] of Object.entries(o.data || {})) {
        if (!/^(text\/(plain|html|markdown|latex)|image\/(png|jpeg|svg\+xml)|application\/pdf)$/.test(k)) continue;
        data[k] = Array.isArray(val) ? val.join('') : String(val);
      }
      if (!Object.keys(data).length) continue;
      v = { output_type: t, data, metadata: {} };
      if (t === 'execute_result') v.execution_count = Number(o.execution_count) || null;
    } else continue;
    bytes += JSON.stringify(v).length;
    if (bytes > MAX_OUTPUT_BYTES) { out.push({ output_type: 'stream', name: 'stderr', text: '[LabTeX: further output was too large to save]\n' }); break; }
    out.push(v);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

export function mountPython(app, { wrap, bad }) {
  // ----- pairing (signed-in user) -----
  app.post('/api/helpers/pair-code', requireUser, (req, res) => {
    for (const [c, v] of pairCodes) if (v.expires < Date.now()) pairCodes.delete(c);
    const code = crypto.randomBytes(5).toString('hex').toUpperCase().replace(/(.{5})/, '$1-');
    pairCodes.set(code, { userId: req.user.id, expires: Date.now() + 10 * 60e3 });
    res.json({ code, expires_in: 600 });
  });
  app.get('/api/helpers', requireUser, (req, res) => {
    res.json(db.prepare('SELECT * FROM helpers WHERE user_id=? ORDER BY last_seen_at DESC').all(req.user.id).map(helperView));
  });
  app.patch('/api/helpers/:hid', requireUser, (req, res) => {
    const name = String(req.body?.name || '').trim().slice(0, 60);
    if (!name) return bad(res, 'Name required.');
    const r = db.prepare('UPDATE helpers SET name=? WHERE id=? AND user_id=?').run(name, req.params.hid, req.user.id);
    if (!r.changes) return bad(res, 'Helper not found.', 404);
    res.json({ ok: true });
  });
  app.delete('/api/helpers/:hid', requireUser, (req, res) => {
    const r = db.prepare('DELETE FROM helpers WHERE id=? AND user_id=?').run(req.params.hid, req.user.id);
    const w = waiters.get(req.params.hid);
    if (w) { clearTimeout(w.timer); waiters.delete(req.params.hid); w.res.status(401).json({ error: 'This helper was removed in LabTeX.' }); }
    res.json({ ok: !!r.changes });
  });
  app.get('/helper/labtex_helper.py', (req, res) => {
    res.setHeader('Content-Disposition', 'attachment; filename="labtex_helper.py"');
    res.type('text/x-python').sendFile(new URL('../helper/labtex_helper.py', import.meta.url).pathname);
  });

  // ----- helper endpoints (Bearer token) -----
  app.post('/api/helper/pair', (req, res) => {
    const code = String(req.body?.code || '').trim().toUpperCase().replace(/^(.{5})-?(.{5})$/, '$1-$2');
    const p = pairCodes.get(code);
    if (!p || p.expires < Date.now()) return res.status(400).json({ error: 'That pairing code is wrong or has expired. Get a new one in LabTeX: Account menu → Python helper.' });
    pairCodes.delete(code);
    const token = crypto.randomBytes(32).toString('base64url');
    const id = newId();
    const name = String(req.body?.name || 'My computer').slice(0, 60);
    db.prepare('INSERT INTO helpers (id,user_id,name,token_hash,info,created_at,last_seen_at) VALUES (?,?,?,?,?,?,?)')
      .run(id, p.userId, name, sha(token), JSON.stringify(req.body?.info || {}), Date.now(), Date.now());
    const u = db.prepare('SELECT name,email FROM users WHERE id=?').get(p.userId);
    res.json({ helperId: id, token, user: u.name, email: u.email });
  });
  app.post('/api/helper/hello', requireHelper, (req, res) => {
    const info = req.body?.info && typeof req.body.info === 'object' ? req.body.info : {};
    db.prepare('UPDATE helpers SET info=? WHERE id=?').run(JSON.stringify(info).slice(0, 20000), req.helper.id);
    res.json({ ok: true, user: req.helperUser.name, helper: req.helper.name });
  });
  app.get('/api/helper/next', requireHelper, (req, res) => {
    const h = req.helper;
    const pending = db.prepare("SELECT * FROM py_runs WHERE helper_id=? AND status='queued' ORDER BY created_at LIMIT 1").get(h.id);
    if (pending) return res.json({ run: JSON.parse(pending.payload) });
    const old = waiters.get(h.id);
    if (old) { clearTimeout(old.timer); old.res.status(204).end(); }
    const wait = Math.min(Number(req.query.wait) || 25, 55) * 1000;
    const timer = setTimeout(() => { if (waiters.get(h.id)?.res === res) waiters.delete(h.id); db.prepare('UPDATE helpers SET last_seen_at=? WHERE id=?').run(Date.now(), h.id); res.status(204).end(); }, wait);
    waiters.set(h.id, { res, timer });
    req.on('close', () => { if (waiters.get(h.id)?.res === res) { clearTimeout(timer); waiters.delete(h.id); } });
  });
  const ownRun = (req, res) => {
    const r = db.prepare('SELECT * FROM py_runs WHERE id=? AND helper_id=?').get(req.params.rid, req.helper.id);
    if (!r) { res.status(404).json({ error: 'Run not found.' }); return null; }
    return r;
  };
  app.get('/api/helper/runs/:rid/files', requireHelper, (req, res) => {
    const r = ownRun(req, res); if (!r) return;
    if (!['awaiting_approval', 'running', 'queued'].includes(r.status)) return res.status(409).json({ error: 'This run is no longer active.' });
    if (!atLeast(roleFor(req.helperUser, r.project_id), 'editor')) return res.status(403).json({ error: 'You no longer have edit access to this project.' });
    flushProject(r.project_id);
    const entries = {};
    for (const f of db.prepare('SELECT id,path,is_binary,content,data FROM files WHERE project_id=?').all(r.project_id)) {
      entries[f.path] = f.is_binary ? new Uint8Array(f.data || []) : Buffer.from(getFileText(f.id) ?? f.content ?? '', 'utf8');
    }
    res.type('application/zip').send(Buffer.from(zipSync(entries, { level: 6 })));
  });
  app.post('/api/helper/runs/:rid/status', requireHelper, (req, res) => {
    const r = ownRun(req, res); if (!r) return;
    if (['cancelled', 'expired', 'done', 'failed', 'declined'].includes(r.status)) return res.json({ cancelled: true, status: r.status });
    const state = req.body?.state;
    const f = {};
    if (state === 'awaiting_approval') f.status = 'awaiting_approval';
    else if (state === 'running') { f.status = 'running'; if (!r.started_at) f.started_at = Date.now(); }
    else if (state === 'declined') { f.status = 'declined'; f.finished_at = Date.now(); f.message = String(req.body?.message || 'Declined on the helper’s computer.').slice(0, 500); }
    if (req.body?.progress != null) f.progress = Number(req.body.progress) || 0;
    if (req.body?.message && state !== 'declined') f.message = String(req.body.message).slice(0, 500);
    if (Object.keys(f).length) setRun(r.id, f);
    res.json({ cancelled: false });
  });
  app.post('/api/helper/runs/:rid/result', requireHelper, (req, res) => {
    const r = ownRun(req, res); if (!r) return;
    if (!['awaiting_approval', 'running', 'queued'].includes(r.status)) return res.status(409).json({ error: `This run is ${r.status}; results were not saved.` });
    if (!atLeast(roleFor(req.helperUser, r.project_id), 'editor')) return res.status(403).json({ error: 'You no longer have edit access to this project.' });
    const payload = JSON.parse(r.payload);
    const known = new Map(payload.cells.map((c) => [c.index, c.hash]));
    const t = Date.now();
    const ins = db.prepare('INSERT OR REPLACE INTO py_cells (run_id,project_id,file_path,cell_index,code_hash,outputs,created_at) VALUES (?,?,?,?,?,?,?)');
    let saved = 0;
    db.transaction(() => {
      for (const c of Array.isArray(req.body?.cells) ? req.body.cells : []) {
        const idx = Number(c.index);
        if (!known.has(idx) || known.get(idx) !== c.hash) continue; // only cells this run was asked to run
        ins.run(r.id, r.project_id, r.file_path, idx, c.hash, JSON.stringify(cleanOutputs(c.outputs)), t);
        saved++;
      }
    })();
    const err = req.body?.error;
    const env = req.body?.env && typeof req.body.env === 'object' ? JSON.stringify(req.body.env).slice(0, 20000) : null;
    const data = req.body?.data && typeof req.body.data === 'object' ? JSON.stringify(req.body.data).slice(0, 20000) : null;
    setRun(r.id, {
      status: err ? 'failed' : 'done', finished_at: t, progress: saved, env, data,
      message: err ? String(err.message || err).slice(0, 2000) : `${saved} cell(s) ran.`,
    });
    // Keep the last 5 runs' outputs per file.
    const old = db.prepare("SELECT id FROM py_runs WHERE project_id=? AND file_path=? AND status IN ('done','failed') ORDER BY finished_at DESC LIMIT -1 OFFSET 5").all(r.project_id, r.file_path);
    for (const o of old) db.prepare('DELETE FROM py_cells WHERE run_id=?').run(o.id);
    res.json({ ok: true, saved });
  });

  // ----- project endpoints (signed-in user) -----
  app.get('/api/projects/:id/python', requireUser, projectAccess('viewer'), (req, res) => {
    const p = db.prepare('SELECT main_file FROM projects WHERE id=?').get(req.params.id);
    const st = pythonState(req.params.id, p.main_file);
    st.helpers = atLeast(req.role, 'editor') ? db.prepare('SELECT * FROM helpers WHERE user_id=? ORDER BY last_seen_at DESC').all(req.user.id).map(helperView) : [];
    st.canRun = atLeast(req.role, 'editor');
    res.json(st);
  });
  app.post('/api/projects/:id/python/run', requireUser, projectAccess('editor'), wrap(async (req, res) => {
    const pid = req.params.id;
    const p = db.prepare('SELECT id,name,main_file FROM projects WHERE id=?').get(pid);
    if (!/\.qmd$/i.test(p.main_file)) return bad(res, 'Python cells run in Quarto (.qmd) documents. Make a .qmd the main document first.');
    const cells = projectCells(pid, p.main_file);
    if (!cells.some((c) => c.eval)) return bad(res, 'This document has no Python cells. Add one with ```{python} … ```.');
    const mine = db.prepare('SELECT * FROM helpers WHERE user_id=? ORDER BY last_seen_at DESC').all(req.user.id);
    if (!mine.length) return bad(res, 'You haven’t paired a Python helper yet. Open Account menu → Python helper to set one up.', 409);
    const h = req.body?.helperId ? mine.find((x) => x.id === req.body.helperId) : mine.find(isOnline);
    if (!h) return bad(res, 'Choose one of your helpers.', 404);
    if (!isOnline(h)) return bad(res, `Your helper “${h.name}” isn’t running. Start it on that computer: python labtex_helper.py`, 409);
    const active = db.prepare("SELECT * FROM py_runs WHERE project_id=? AND status IN ('queued','awaiting_approval','running')").get(pid);
    if (active) return bad(res, 'Python is already running for this project. Wait for it to finish or cancel it.', 409);
    const id = newId();
    const edited = othersEdited(pid, h);
    const payload = {
      id, server: `${req.protocol}://${req.get('host')}`,
      project: { id: pid, name: p.name }, file: p.main_file,
      requestedBy: { id: req.user.id, name: req.user.name },
      cells: cells.map((c) => ({ index: c.index, code: c.code, hash: c.hash, line: c.line, eval: c.eval })),
      datasets: datasetsOf(pid), othersEdited: edited,
    };
    db.prepare('INSERT INTO py_runs (id,project_id,file_path,requested_by,helper_id,status,total,payload,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(id, pid, p.main_file, req.user.id, h.id, 'queued', cells.filter((c) => c.eval).length, JSON.stringify(payload), Date.now());
    const run = db.prepare('SELECT * FROM py_runs WHERE id=?').get(id);
    emitProject(pid, { type: 'python', run: runInfo(run) });
    deliver(run);
    res.json({ run: runInfo(run) });
  }));
  app.post('/api/projects/:id/python/runs/:rid/cancel', requireUser, projectAccess('editor'), (req, res) => {
    const r = db.prepare('SELECT * FROM py_runs WHERE id=? AND project_id=?').get(req.params.rid, req.params.id);
    if (!r) return bad(res, 'Run not found.', 404);
    if (['queued', 'awaiting_approval', 'running'].includes(r.status)) setRun(r.id, { status: 'cancelled', finished_at: Date.now(), message: `Cancelled by ${req.user.name}.` });
    res.json({ ok: true });
  });
  app.delete('/api/projects/:id/python/outputs', requireUser, projectAccess('editor'), (req, res) => {
    db.prepare('DELETE FROM py_cells WHERE project_id=?').run(req.params.id);
    emitProject(req.params.id, { type: 'python', cleared: true });
    res.json({ ok: true });
  });
}
