# LabTeX: a self-hosted, Overleaf-style LaTeX editor for your lab

LabTeX is a self-hosted web app where lab members write LaTeX together in the browser. It has:

- **Real-time co-editing**: several people can edit the same file at once and see each other's named cursors (built on Yjs CRDTs, so edits never conflict).
- **Track changes and comments**: turn on *Track changes* in the **Review** panel and everyone's edits become suggestions (insertions highlighted, deletions struck through, colored by author) that you accept or reject one at a time or all at once. Select any text and click **💬 Comment** (or press Ctrl/⌘+Alt+M) to start a threaded discussion, which you can reply to, resolve, or reopen. The PDF is always built from the text as if all suggestions were accepted.
- **Real TeX Live compilation**: pdflatex, xelatex or lualatex through `latexmk`. BibTeX and biber run automatically.
- **PDF preview with SyncTeX**: *Go to PDF →* jumps from your cursor to the PDF, and double-clicking the PDF jumps to the source line.
- **Clickable error log**: errors and warnings link to the file and line that caused them. The raw log is available too.
- **Teammates and roles**: each project has five roles: **Viewer** (read, compile, download), **Commenter** (viewer + comments and tasks), **Editor** (commenter + edit files, accept/reject suggestions), **Admin** (editor + manage sharing and project settings) and **Owner** (admin + delete the project or transfer ownership). Share with a person by picking them from the lab directory, or share with **everyone in the lab** (view, comment or edit), which also covers people who join later. Lab-wide projects appear under the **Lab workspace** tab on the Projects page.
- **Team directory**: the **Team** page lists every lab member with their role in the lab, whether they're online, and how many projects and open tasks you share. Open a profile to share one of your projects with them or assign them a task. Lab admins add members, reset passwords and grant admin rights from the same page.
- **Accounts vs. the lab team**: anyone can sign up and use LabTeX right away for their own projects and for anything shared with them directly (collaborators outside the lab, students, co-authors). Being on the **lab team** is separate and is up to a lab admin. Only lab-team members see the Team directory, the lab library (`lab.bib`), lab templates, and projects shared with "everyone in the lab". New sign-ups appear under **Not on the lab team** on the Team page. From there an admin can click **Add to lab team** or delete the account, and every admin gets a notification when someone signs up. Use **Remove from lab team** in a member's ⋯ menu to take them off the team; they keep their account and projects. The **New sign-ups** setting on the Team page chooses between: anyone can sign up and an admin adds them to the team (the default); anyone can sign up and joins the team automatically; or sign-up is off and only admins create accounts. `ALLOW_REGISTRATION=false` in `docker-compose.yml` forces sign-up off, and `REGISTRATION_CODE` still works if you want a code on the sign-up form.
- **Tasks**: create tasks from the **✓ Tasks** drawer in any project (new tasks link to the line you're on) or straight from a comment thread (**✓ Task**). Tasks have an assignee, a due date and a status (to do, in progress, done). **My tasks** collects everything assigned to you or created by you, grouped into overdue, today, this week and later. Your open tasks also appear at the top of the Projects page.
- **Notifications**: the 🔔 bell shows a live unread count and a list of what happened: projects shared with you, role changes, task assignments, completions and due-date reminders, comments on your projects, replies to your threads, **@mentions** (type @ in a comment to pick a teammate), and labelled versions. Clicking a notification opens the exact project, comment thread or task. You can also turn on desktop pop-ups for when LabTeX is in the background. Notifications are in-app only; LabTeX does not send email.
- **Quarto projects**: write in Quarto (`.qmd`) and compile to PDF like a LaTeX project. Start from the **Quarto article** template, or make any `.qmd` the main document (its ⋯ menu → **Set as main document**). The **PDF / HTML** switch above the preview renders a web-page version too. In the editor you get Markdown highlighting, and typing `@` completes citation keys and cross-reference labels (`@fig-…`, `@tbl-…`, `@eq-…`, `@sec-…`). Errors are explained the same way as LaTeX errors. Python cells can run on your own computer with the **LabTeX Python helper** (see below); the server never runs code. Filters, extensions and other settings that could run programs or read files outside the project are ignored, and LabTeX lists anything it ignored in the logs. SyncTeX (jumping between source and PDF) is available for LaTeX projects only.
- **Python helper**: run the Python cells of a Quarto document on your own computer, with the Python you choose (system, a virtual environment or a conda environment, as with VS Code's interpreter picker) and with your local data folders. Click **▶ Run Python** in the project. The results (printed output, tables, plots) are saved with the project, so teammates see them in the PDF and HTML preview without a helper of their own. Set it up under **Account menu → Python helper**.
- **LaTeX ⇄ Quarto conversion**: convert `.tex` to Quarto `.qmd` and back, one file or many at once. In a project use **☰ Menu → Convert LaTeX ⇄ Quarto…**, or a file's ⋯ menu. To convert files without a project, use **⇄ Convert files** on the Projects page, where you can upload `.tex`/`.qmd` files and whole project `.zip`s together. Results can be added to the project (Editors and above), saved as a new project, or downloaded as a `.zip` (anyone with access). Your original files are never changed. Settings cover cross-references, citations, line wrapping, figure conversion (PDF/EPS/SVG to PNG or JPEG at a chosen resolution and quality), text encoding, line endings and `.zip` compression. Conversion uses pandoc; the Quarto program is not needed, and code in Quarto files is never run.
- **Templates**: starter templates (article, paper with BibTeX, thesis, Beamer). Any project can be published as a **lab template** for everyone to start from.
- **Shared lab bibliography**: a lab-wide `lab.bib` that everyone can edit. Every project can cite it with `\bibliography{lab}` or `\addbibresource{lab.bib}`.
- **Version history**: a snapshot is saved automatically on successful compiles (at most one every 2 minutes), and you can save labelled versions by hand. You can view a line diff against the current state, restore a single file or the whole project, and download any version as a .zip.
- **Import and export**: import a .zip (an Overleaf "Download source" zip works) and download the source as a .zip or the PDF.
- **Editor features**: LaTeX syntax highlighting, autocomplete for commands and environments (`\begin{…}` inserts the matching `\end`), `\cite{}` keys from your .bib files and the lab library, `\ref{}` labels, and file names. Also: browser spell-check, Ctrl/⌘+B and Ctrl/⌘+I, Ctrl/⌘+/ to comment a line, Ctrl/⌘+S or Ctrl/⌘+Enter to compile, optional auto-compile, and drag-and-drop uploads for images and other files.

---

## Quick start (Docker, recommended)

You need a Linux machine with Docker and Docker Compose, about 8 GB of free disk space for the full TeX Live image, and at least 2 GB of RAM.

```bash
# 1. Copy this folder to the server, then:
cd labtex

# 2. Edit docker-compose.yml and set REGISTRATION_CODE to a secret you'll share with the lab.

# 3. Build and start (the first build downloads TeX Live and takes a while)
docker compose up -d --build

# 4. Open http://SERVER:3000
```

**The first account you create becomes the administrator.** After that, people can register only with the lab registration code. You can also turn registration off (`ALLOW_REGISTRATION: "false"`) and create accounts from **Admin → Lab members**.

All data lives in `./labtex-data` (a single SQLite database containing users, projects, files and history). **Back up this folder.** A simple nightly backup (add it to root's crontab):

```bash
0 3 * * *  cd /path/to/labtex && docker compose stop labtex && tar czf /backups/labtex-$(date +\%F).tgz labtex-data && docker compose start labtex
```

### HTTPS (strongly recommended beyond a trusted LAN)

Put a reverse proxy in front of LabTeX. With [Caddy](https://caddyserver.com), a complete `Caddyfile` is:

```
latex.yourlab.org {
    reverse_proxy localhost:3000
}
```

Caddy gets certificates automatically and proxies WebSockets. Then set `SECURE_COOKIES: "true"` and `TRUST_PROXY: "true"` in `docker-compose.yml`.

For nginx, remember the WebSocket headers:

```nginx
location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 1h;
    client_max_body_size 60m;
}
```

---

## Running without Docker

```bash
sudo apt install texlive-full latexmk nodejs npm   # Node 20+ required
sudo apt install pandoc poppler-utils ghostscript librsvg2-bin   # LaTeX ⇄ Quarto conversion (pandoc 3+)
# and Quarto (https://quarto.org/docs/download/) to compile .qmd projects
npm ci
npm run build
DATA_DIR=/var/lib/labtex PORT=3000 npm start
```

> **Security note:** without Docker, TeX runs as the same user as the server. pdflatex and xelatex are restricted to the project folder (`openin_any=p`), but **lualatex's Lua `io.open` can read any file the server user can read, including the database**. If your users aren't fully trusted, use Docker. Or replicate its setup: create a separate `texrunner` user, add a sudoers rule `labtex ALL=(texrunner) NOPASSWD: /usr/bin/env`, and set `COMPILE_USER=texrunner` and `BUILD_DIR` to a directory with mode `711`.

---

## Configuration

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `DATA_DIR` | `./data` | Where the SQLite database lives |
| `BUILD_DIR` | `$DATA_DIR/builds` | Compile working folders (safe to delete; they're a cache) |
| `ALLOW_REGISTRATION` | `true` | Allow self sign-up (the first user can always register) |
| `REGISTRATION_CODE` | *(none)* | If set, sign-up requires this code |
| `SECURE_COOKIES` | `false` | Set `true` when served over HTTPS |
| `TRUST_PROXY` | `false` | Set `true` behind a reverse proxy |
| `COMPILE_USER` | *(none; `texrunner` in Docker)* | Run TeX as this user via sudo |
| `COMPILE_TIMEOUT_SECONDS` | `120` | Kill compiles that run longer than this |
| `MAX_CONCURRENT_COMPILES` | `3` | Extra compiles queue up |
| `MAX_UPLOAD_MB` | `50` | Per-file upload limit |
| `ALLOWED_ORIGINS` | *(none)* | Extra origins allowed to open WebSockets (comma-separated) |
| `PANDOC_BIN` | `pandoc` | pandoc executable used for LaTeX ⇄ Quarto conversion |
| `QUARTO_BIN` | `quarto` | Quarto executable used to compile `.qmd` projects |
| `MAX_CONCURRENT_QUARTO` | `2` | Quarto renders that run at once. They queue separately from LaTeX compiles, so a burst of Quarto work never makes LaTeX users wait in line |
| `QUARTO_TIMEOUT_SECONDS` | `180` | Kill Quarto renders that run longer than this |
| `CONVERT_TIMEOUT_SECONDS` | `120` | Kill conversions that run longer than this |

## Quarto projects: what to expect

- A project compiles with Quarto when its main document is a `.qmd` file. The PDF is made by Quarto's own LaTeX template with the engine from Settings → Compiler, unless the document sets `pdf-engine` itself.
- **Not supported:** running code (cells appear as code listings, without their output), Quarto extensions and custom formats (such as journal formats installed with `quarto add`), filters and project scripts (`pre-render`/`post-render`), and Mermaid diagrams (they need a web browser on the server; export them as images instead).
- The HTML preview opens in a sandboxed frame, at a private link that expires after two hours. Math is drawn with the browser's built-in MathML, so it works without internet access.
- A converted LaTeX document (`<name>-quarto.qmd`) compiles with Quarto as well. In the conversion results, click **Compile with Quarto**. On the PhD proposal this gave 16 pages instead of 17, with 99% of the text matching.
- Speed: Quarto renders take a few seconds longer than LaTeX compiles (Quarto starts its own runtime, then runs LaTeX). They queue separately from LaTeX compiles, so LaTeX never waits in line behind them, although both share the server's CPUs.

## Python helper: how it works

1. **Set up once per computer.** Under Account menu → Python helper, download `labtex_helper.py`. It is a single file that needs Python 3.8+ and no packages. Pair it with the command and one-time code shown there, then choose an interpreter (`python labtex_helper.py interpreters`, then `use <number>`). It finds system Pythons, venvs, conda environments, pyenv versions and, on Windows, those listed by the `py` launcher.
2. **Data stays on your computer.** A project lists the dataset names its code uses (Project settings → Python datasets, e.g. `pv-measurements`). Everyone links their own copy with `python labtex_helper.py link pv-measurements ~/Drive/pv-data`, and the code reads `labtex.data("pv-measurements") / "run1.csv"`. The same code then works on every teammate's computer, whether the folder is synced by Google Drive, Git or Hugging Face.
3. **Run.** Start the helper (`python labtex_helper.py`) and click **▶ Run Python**. The status next to the button shows "waiting for approval", progress, and the result. The PDF recompiles automatically when the run finishes.
4. **Approval.** The helper runs code without asking when only you changed it since that computer last ran the project. If anyone else changed the project, or its code came from an upload, import, restore or conversion, the helper shows exactly what changed, who changed it and which data folders the code can read, and asks before running. Answer **a** to trust the project from then on. `python labtex_helper.py ask always|changes|never` changes the default. Approval exists because a cell can do anything you can do on your computer.
5. **Results.** Each cell's output is saved, keyed to that cell's code. If the code changes later, the old output stays in the document marked as outdated until someone runs Python again. Logs → Python results shows who ran it, on which computer, with which Python and package versions, and a fingerprint of the data folders.

Notes: only people with Editor access can run Python, and only on their own paired computers. Printed output and plots are uploaded and visible to everyone in the project, but data files are not. Cells run in order in a single Python session from a temporary copy of the project, so files the code writes are not kept. The helper talks to LabTeX over the same address you use in the browser, so it works from anywhere your browser does. It doesn't need Quarto or Jupyter installed. Only Python cells run; R, Julia and other languages are shown as code.

## LaTeX ⇄ Quarto conversion: what to expect

- **LaTeX → Quarto** writes `<name>-quarto.qmd`, not `<name>.qmd`, so rendering it with Quarto can't overwrite your original `.tex`. The document class, packages, macros, page layout, fonts and `\DocumentMetadata` (PDF tagging) settings carry over: some go into the `.qmd`'s settings block and some into small files in `quarto-partials/`, which should stay next to the `.qmd`. Anything with no Markdown equivalent (custom title pages, TikZ, tables in two-column layouts) stays as raw LaTeX, so the PDF still matches the original. Cross-references become Quarto's `@fig-…`, `@tbl-…`, `@eq-…` and `@sec-…`, and the reference list stays where it was (`::: {#refs}`).
- **Quarto → LaTeX** understands Quarto's own syntax: cross-references, figure and subfigure layouts, table captions, numbered equations, callout boxes, content shown only for PDF or only for HTML, `{{< include >}}`, `{{< pagebreak >}}` and `{{< meta >}}`, and `format: pdf:` settings. Code cells become code listings; they aren't run, so their plots and printed output aren't included. Quarto extensions, filters and `_quarto.yml` project files are ignored.
- Quarto writes "Figure 1" and "Equation 1" for `@fig-…`/`@eq-…`, so a LaTeX "Eq. (1)" comes back as "Equation 1" after a round trip. A plain `\ref`/`\eqref` stays a plain number.
- Round trips (LaTeX → Quarto → LaTeX) were tested on the PhD proposal, MS thesis, report, IEEE conference and syllabus templates. They compile with no new errors and the same page count as the originals. The exception is the syllabus (3 pages instead of 4), which could only be tested with an older TeX Live that can't render its headings. The proposal's text matches the original exactly; the others match 91–99%, the differences being reference wording and figure placement.

## Security model

- Passwords are hashed with bcrypt. Sessions use HttpOnly, SameSite=Lax cookies. Failed logins are rate-limited.
- Only TeX Live's *restricted* shell escape is allowed: trusted helpers such as `latexminted` (minted v3), `bibtex`, `makeindex` and `repstopdf` can run, but arbitrary `\write18` commands cannot. TeX can only read and write inside the project's own folder (paranoid `openin_any`/`openout_any`).
- `latexmkrc` files inside projects are ignored (they are Perl code). LabTeX uses its own `server/latexmkrc`, which also runs `makeglossaries` (glossaries/acronyms) and nomencl automatically.
- In Docker, TeX runs as a separate `texrunner` account that cannot read `/data`, and compiles are killed after the timeout.
- Viewers can read and compile but can't edit, and Commenters can only add comments: the server checks every change and drops anything a role isn't allowed to make, not only the UI.
- Lab admins can open every project.

## How it works

```
browser ──HTTP──▶ Express API (auth, projects, files, compile, history)  ──▶ SQLite
        ──WS────▶ /ws/doc/<file>      Yjs sync + cursors (one room per open file)
        ──WS────▶ /ws/project/<id>    file-tree changes, presence, "X compiled"
compile: files are written to a per-project build folder, then `latexmk` runs there
         (incremental, so recompiles are fast) and the PDF, log and SyncTeX output are returned
```

- `server/`: `index.js` (REST API), `collab.js` (Yjs WebSocket server), `compile.js` (latexmk, log parser), `db.js`, `auth.js`, `templates.js`
- `client/`: the single-page app (CodeMirror 6, y-codemirror, pdf.js), bundled by esbuild into `public/app.js`

To add more built-in templates, edit `server/templates.js`. Usually it's easier to make a project and tick **Menu → Project settings → Lab template**.
