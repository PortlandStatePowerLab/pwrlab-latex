#!/usr/bin/env python3
"""LabTeX Python helper.

Runs the Python cells of your LabTeX Quarto documents on THIS computer, with a Python interpreter you
choose (system Python, a virtual environment or a conda environment) and data folders you link. The
outputs (printed text, tables, plots) are sent back to LabTeX and saved with the project, so teammates
see them too. Your data files stay here.

Quick start
    python labtex_helper.py pair https://labtex.example.org ABCDE-12345   # code from LabTeX
    python labtex_helper.py interpreters                                  # list Pythons found here
    python labtex_helper.py use 2                                         # pick one (number or path)
    python labtex_helper.py link pv-measurements ~/Drive/pv-data          # optional: data folders
    python labtex_helper.py                                               # start; leave it running

In your document, read linked data like this (works on every teammate's computer):
    import labtex, pandas as pd
    df = pd.read_csv(labtex.data("pv-measurements") / "run1.csv")

Needs Python 3.8+ to run the helper; your chosen interpreter can be 3.7+. No packages required.
"""
import argparse
import base64
import difflib
import hashlib
import io
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

VERSION = "1.0"
HOME = Path(os.environ.get("LABTEX_HELPER_HOME") or (Path.home() / ".labtex-helper"))
CONFIG = HOME / "config.json"
APPROVAL_TIMEOUT = 10 * 60


# ----------------------------------------------------------------------------- config

def load_config():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except Exception as e:
        sys.exit(f"Can't read {CONFIG}: {e}")


def save_config(cfg):
    HOME.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)  # holds the helper's token
    except OSError:
        pass
    os.replace(tmp, CONFIG)


def say(msg=""):
    print(msg, flush=True)


# ----------------------------------------------------------------------------- HTTP

class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def api(cfg, method, path, body=None, timeout=60, raw=False, server=None, token=None):
    url = (server or cfg["server"]).rstrip("/") + path
    data = None
    headers = {"User-Agent": f"labtex-helper/{VERSION}"}
    tok = token or cfg.get("token")
    if tok:
        headers["Authorization"] = "Bearer " + tok
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            content = r.read()
            if r.status == 204:
                return None
            return content if raw else (json.loads(content) if content else None)
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read()).get("error") or str(e)
        except Exception:
            msg = str(e)
        raise ApiError(e.code, msg)


# ----------------------------------------------------------------------------- interpreters

PROBE = "import sys,json,os;print(json.dumps([sys.version.split()[0],sys.prefix,getattr(sys,'base_prefix',sys.prefix),sys.executable]))"


def probe(py):
    """(version, kind, label) for a Python executable, or None if it doesn't run."""
    try:
        out = subprocess.run([py, "-c", PROBE], capture_output=True, text=True, timeout=15)
        if out.returncode != 0:
            return None
        ver, prefix, base, exe = json.loads(out.stdout.strip().splitlines()[-1])
    except Exception:
        return None
    if (Path(prefix) / "conda-meta").is_dir():
        name = Path(prefix).name
        kind, label = "conda", ("base" if (Path(prefix) / "condabin").is_dir() else name)
    elif os.path.normcase(prefix) != os.path.normcase(base):
        kind, label = "venv", Path(prefix).name
    else:
        kind, label = "system", "system"
    return {"path": str(py), "version": ver, "kind": kind, "label": label, "prefix": prefix}


def find_interpreters():
    """Pythons on this computer: PATH, the Windows py launcher, venvs, pyenv and conda environments."""
    cands = [sys.executable]
    win = os.name == "nt"
    names = ["python3", "python"] + [f"python3.{m}" for m in range(7, 15)]
    for n in names:
        p = shutil.which(n)
        if p:
            cands.append(p)
    if win and shutil.which("py"):
        try:
            out = subprocess.run(["py", "-0p"], capture_output=True, text=True, timeout=10).stdout
            cands += re.findall(r"([A-Za-z]:\\[^\r\n]*?python(?:w)?\.exe)", out)
        except Exception:
            pass
    exe = ("Scripts", "python.exe") if win else ("bin", "python")
    roots = [Path.cwd(), Path.home(), Path.home() / ".virtualenvs", Path.home() / ".venvs", Path.home() / "venvs",
             Path.home() / "envs", Path.home() / ".pyenv" / "versions"]
    for root in roots:
        if not root.is_dir():
            continue
        for d in list(root.iterdir())[:200]:
            if d.is_dir() and ((d / "pyvenv.cfg").exists() or root.name == "versions"):
                cands.append(str(d.joinpath(*exe)))
    # conda
    prefixes = []
    conda = os.environ.get("CONDA_EXE") or shutil.which("conda") or shutil.which("mamba")
    if conda:
        try:
            out = subprocess.run([conda, "env", "list", "--json"], capture_output=True, text=True, timeout=30).stdout
            prefixes += json.loads(out).get("envs", [])
        except Exception:
            pass
    envs_txt = Path.home() / ".conda" / "environments.txt"
    if envs_txt.exists():
        prefixes += [l.strip() for l in envs_txt.read_text(errors="ignore").splitlines() if l.strip()]
    for pre in prefixes:
        cands.append(str(Path(pre) / ("python.exe" if win else "bin/python")))
    seen, found = set(), []
    for c in cands:
        if not c or not os.path.exists(c):
            continue
        key = os.path.normcase(os.path.realpath(c)) + "|" + os.path.normcase(str(Path(c).parent.parent))
        if key in seen:
            continue
        seen.add(key)
        info = probe(c)
        if info:
            found.append(info)
    return found


def describe(info):
    if not info:
        return "?"
    extra = f"{info['kind']}: {info['label']}" if info["kind"] != "system" else "system"
    return f"Python {info['version']} ({extra})"


# ----------------------------------------------------------------------------- datasets

def fingerprint(folder, limit=20000):
    """Cheap fingerprint of a data folder: file count, size, newest change, and a hash of the listing."""
    h = hashlib.sha256()
    n = size = 0
    newest = 0.0
    root = Path(folder)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))
        for f in sorted(filenames):
            if f.startswith("."):
                continue
            p = Path(dirpath) / f
            try:
                st = p.stat()
            except OSError:
                continue
            rel = p.relative_to(root).as_posix()
            h.update(f"{rel}\0{st.st_size}\0{int(st.st_mtime)}\n".encode())
            n += 1
            size += st.st_size
            newest = max(newest, st.st_mtime)
            if n >= limit:
                break
    return {"files": n, "bytes": size, "newest": int(newest), "hash": h.hexdigest()[:12]}


# ----------------------------------------------------------------------------- the worker (runs inside the chosen interpreter)

WORKER = r'''
import ast, base64, builtins, io, json, os, sys, time, traceback, types
from pathlib import Path

cells = json.load(open(sys.argv[1], encoding="utf-8"))
OUT = sys.argv[2]
progress = sys.__stdout__
DATA = json.loads(os.environ.get("LABTEX_DATASETS", "{}"))

class LabtexModule(types.ModuleType):
    datasets = DATA
    @staticmethod
    def data(name):
        """Path of the local folder linked to dataset `name` on this computer."""
        if name not in DATA:
            raise KeyError("Dataset %r isn't linked on this computer. Link it with:  python labtex_helper.py link %s /path/to/folder" % (name, name))
        return Path(DATA[name])
labtex = LabtexModule("labtex")
labtex.data = LabtexModule.data
sys.modules["labtex"] = labtex

ns = {"__name__": "__main__", "labtex": labtex}
before = set(sys.modules)
current = []

# matplotlib: draw off-screen, with Quarto's default PDF figure size.
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as _plt
    matplotlib.rcParams["figure.figsize"] = (5.5, 3.5)
    _plt.show = lambda *a, **k: None
except Exception:
    _plt = None

def _b64(b):
    return base64.b64encode(b).decode("ascii")

def _fig_bundle(fig):
    d = {}
    b = io.BytesIO(); fig.savefig(b, format="png", dpi=200, bbox_inches="tight"); d["image/png"] = _b64(b.getvalue())
    try:
        b = io.BytesIO(); fig.savefig(b, format="pdf", bbox_inches="tight")
        if b.tell() < 3_000_000:
            d["application/pdf"] = _b64(b.getvalue())
    except Exception:
        pass
    d["text/plain"] = "<Figure>"
    return d

def _md_table(df, max_rows=60):
    try:
        return df.to_markdown()
    except Exception:
        pass
    try:
        df = df.head(max_rows)
        cols = [str(c) for c in df.columns]
        idx = [str(i) for i in df.index]
        esc = lambda s: str(s).replace("|", "\\|").replace("\n", " ")
        rows = ["| " + " | ".join([""] + [esc(c) for c in cols]) + " |", "|" + "---|" * (len(cols) + 1)]
        for i, (_, r) in enumerate(df.iterrows()):
            rows.append("| " + " | ".join([esc(idx[i])] + [esc(v) for v in r.tolist()]) + " |")
        return "\n".join(rows) + "\n"
    except Exception:
        return None

def bundle(obj):
    if _plt is not None and obj.__class__.__name__ == "Figure" and hasattr(obj, "savefig"):
        return _fig_bundle(obj)
    data = {}
    mb = getattr(obj, "_repr_mimebundle_", None)
    if callable(mb):
        try:
            r = mb()
            if isinstance(r, tuple):
                r = r[0]
            for k, v in (r or {}).items():
                data[k] = v if isinstance(v, str) else (_b64(v) if isinstance(v, bytes) else json.dumps(v))
        except Exception:
            pass
    for meth, mime in (("_repr_html_", "text/html"), ("_repr_markdown_", "text/markdown"), ("_repr_latex_", "text/latex"),
                       ("_repr_svg_", "image/svg+xml"), ("_repr_png_", "image/png"), ("_repr_jpeg_", "image/jpeg")):
        if mime in data:
            continue
        f = getattr(obj, meth, None)
        if callable(f):
            try:
                v = f()
                if isinstance(v, tuple):
                    v = v[0]
                if v is not None:
                    data[mime] = _b64(v) if isinstance(v, bytes) else str(v)
            except Exception:
                pass
    tname = type(obj).__module__.split(".")[0] + "." + type(obj).__name__
    if tname in ("pandas.DataFrame", "pandas.Series") and "text/markdown" not in data:
        t = _md_table(obj.to_frame() if tname == "pandas.Series" else obj)
        if t:
            data["text/markdown"] = t
    data["text/plain"] = repr(obj)
    return data

def display(*objs, **kw):
    for o in objs:
        current.append({"output_type": "display_data", "data": bundle(o), "metadata": {}})
builtins.display = display
try:  # make IPython's display() land here too, if IPython is installed
    import IPython.display as _ipd
    _ipd.display = display
    import IPython.core.display_functions as _ipdf
    _ipdf.display = display
except Exception:
    pass

class Stream(io.TextIOBase):
    def __init__(self, name):
        self.name = name
    def write(self, s):
        if not s:
            return 0
        if current and current[-1].get("output_type") == "stream" and current[-1]["name"] == self.name:
            current[-1]["text"] += s
        else:
            current.append({"output_type": "stream", "name": self.name, "text": s})
        return len(s)
    def flush(self):
        pass
    def isatty(self):
        return False

def collect_figures():
    if _plt is None:
        return
    for num in _plt.get_fignums():
        current.append({"output_type": "display_data", "data": _fig_bundle(_plt.figure(num)), "metadata": {}})
    _plt.close("all")

results, error = [], None
total = sum(1 for c in cells if c.get("eval", True))
done = 0
sys.stdout, sys.stderr = Stream("stdout"), Stream("stderr")
for c in cells:
    if not c.get("eval", True):
        continue
    current = []
    fname = "<cell %d>" % c["index"]
    code = c["code"]
    try:
        tree = ast.parse(code, fname, "exec")
        last = None
        if tree.body and isinstance(tree.body[-1], ast.Expr) and not code.rstrip().endswith(";"):
            last = ast.Expression(tree.body.pop().value)
        exec(compile(tree, fname, "exec"), ns)
        if last is not None:
            val = eval(compile(last, fname, "eval"), ns)
            if val is not None and not (_plt is not None and val.__class__.__module__.startswith("matplotlib")):
                current.append({"output_type": "execute_result", "data": bundle(val), "metadata": {}, "execution_count": done + 1})
        collect_figures()
    except BaseException as e:
        collect_figures()
        tb = traceback.extract_tb(e.__traceback__)
        frames = [f for f in tb if f.filename.startswith("<cell")]
        line = frames[-1].lineno if frames else getattr(e, "lineno", None)
        lines = ["Traceback (most recent call last):"] + [l.rstrip("\n") for l in traceback.format_list(frames)] + traceback.format_exception_only(type(e), e)
        current.append({"output_type": "error", "ename": type(e).__name__, "evalue": str(e), "traceback": [l.rstrip("\n") for l in lines]})
        error = {"index": c["index"], "line": line, "message": "%s: %s" % (type(e).__name__, e)}
    results.append({"index": c["index"], "hash": c["hash"], "outputs": current})
    done += 1
    progress.write("LABTEX-PROGRESS %d %d\n" % (done, total)); progress.flush()
    if error:
        break

def versions():
    out = {}
    try:
        from importlib import metadata
    except Exception:
        metadata = None
    # Versions of the packages the cells import (not their dependencies).
    imported = set()
    for c in cells:
        try:
            for node in ast.walk(ast.parse(c["code"])):
                if isinstance(node, ast.Import):
                    imported.update(a.name.split(".")[0] for a in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
                    imported.add(node.module.split(".")[0])
        except SyntaxError:
            pass
    for name in sorted(imported):
        if name.startswith("_") or name in ("labtex",) or name not in sys.modules:
            continue
        mod = sys.modules.get(name)
        f = (getattr(mod, "__file__", None) or "").replace("\\", "/")
        if "-packages/" not in f:  # standard library or built-in, not an installed package
            continue
        v = getattr(mod, "__version__", None)
        if v is None and metadata is not None:
            try:
                v = metadata.version(name)
            except Exception:
                v = None
        if isinstance(v, str):
            out[name] = v
        if len(out) >= 40:
            break
    return out

env_name = os.environ.get("CONDA_DEFAULT_ENV") or (Path(sys.prefix).name if sys.prefix != getattr(sys, "base_prefix", sys.prefix) else "system")
if (Path(sys.prefix) / "conda-meta").is_dir():
    env_name = "conda: " + ("base" if (Path(sys.prefix) / "condabin").is_dir() else Path(sys.prefix).name)
elif sys.prefix != getattr(sys, "base_prefix", sys.prefix):
    env_name = "venv: " + Path(sys.prefix).name
json.dump({"cells": results, "error": error,
           "env": {"python": sys.version.split()[0], "implementation": sys.implementation.name, "env": env_name,
                   "platform": sys.platform, "packages": versions()}},
          open(OUT, "w", encoding="utf-8"))
'''


# ----------------------------------------------------------------------------- running a request

def post_status(cfg, run, **body):
    try:
        r = api(cfg, "POST", f"/api/helper/runs/{run['id']}/status", body, timeout=30)
        return bool(r and r.get("cancelled"))
    except Exception:
        return False


def ask_approval(cfg, run, cells_to_show, interp, datasets):
    """Ask in this terminal. Returns 'yes', 'always' or 'no'."""
    if not sys.stdin or not sys.stdin.isatty():
        return "no-tty"
    proj = run["project"]
    say("")
    say("=" * 72)
    say(f"  {run['requestedBy']['name']} wants to run Python from “{proj['name']}” ({run['file']}) on this computer.")
    by = run.get("othersEdited", {}).get("by") or []
    if by:
        say(f"  Changed since this computer last ran it by: {', '.join(by)}")
    say(f"  Interpreter: {describe(interp)}  {interp['path']}")
    if datasets:
        say("  Data folders it can read: " + ", ".join(f"{k} → {v}" for k, v in datasets.items()))
    say("  Printed text, tables and plots will be uploaded to LabTeX and visible to everyone in the project.")
    say("=" * 72)
    prev = cfg.get("approved", {}).get(proj["id"], {}).get("code", {})
    for c in cells_to_show:
        old = prev.get(str(c["index"]))
        say(f"\n--- Cell {c['index'] + 1} (line {c['line']}){' — changed' if old else ' — new'}")
        if old:
            diff = list(difflib.unified_diff(old.splitlines(), c["code"].splitlines(), "before", "now", lineterm="", n=2))
            for l in diff[2:]:
                say("    " + l)
        else:
            for l in c["code"].splitlines():
                say("    " + l)
    say("")
    answer = {}

    def read():
        try:
            answer["v"] = input("Run these cells?  [y] yes   [a] yes, and always for this project   [n] no : ").strip().lower()
        except EOFError:
            answer["v"] = "n"
    t = threading.Thread(target=read, daemon=True)
    t.start()
    end = time.time() + APPROVAL_TIMEOUT
    while t.is_alive() and time.time() < end:
        t.join(3)
        if t.is_alive() and post_status(cfg, run):  # cancelled in LabTeX
            say("\n(The run was cancelled in LabTeX.)")
            return "cancelled"
    v = answer.get("v", "")
    if v in ("a", "always"):
        return "always"
    if v in ("y", "yes"):
        return "yes"
    return "timeout" if t.is_alive() else "no"


def safe_extract(data, dest):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for m in z.infolist():
            name = m.filename.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/") or re.match(r"^[A-Za-z]:", name):
                continue
            target = dest / name
            if m.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(m) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)


def handle_run(cfg, run):
    proj = run["project"]
    cells = [c for c in run["cells"] if c.get("eval", True)]
    say(f"\n▶ Run request from {run['requestedBy']['name']}: “{proj['name']}” — {len(cells)} Python cell(s)")
    interp = probe(cfg.get("interpreter") or sys.executable)
    if not interp:
        msg = f"The chosen interpreter doesn't run: {cfg.get('interpreter')}. Pick another with: python labtex_helper.py use"
        say("  ✗ " + msg)
        post_status(cfg, run, state="declined", message=msg)
        return
    linked = cfg.get("datasets", {})
    wanted = run.get("datasets") or []
    datasets = {n: linked[n] for n in wanted if n in linked}
    missing = [n for n in wanted if n not in linked]
    for n, p in list(datasets.items()):
        if not Path(p).is_dir():
            missing.append(n)
            datasets.pop(n)
    if missing:
        say(f"  ! Not linked on this computer: {', '.join(missing)} (python labtex_helper.py link NAME FOLDER)")

    # --- approval
    appr = cfg.setdefault("approved", {}).setdefault(proj["id"], {"hashes": [], "code": {}, "trusted": False})
    mode = cfg.get("ask", "changes")
    new = [c for c in cells if c["hash"] not in appr["hashes"]]
    others = run.get("othersEdited", {}).get("changed", True)
    if mode == "never" or appr.get("trusted"):
        need = False
    elif mode == "always":
        need = True
    else:
        need = bool(new) and others
    if need:
        post_status(cfg, run, state="awaiting_approval", message=f"Waiting for approval on {cfg.get('name', 'the helper')}")
        a = ask_approval(cfg, run, new or cells, interp, datasets)
        if a == "cancelled":
            return
        if a not in ("yes", "always"):
            msg = {"no-tty": "Approval was needed, but the helper isn't running in a terminal. Start it in a terminal, or see 'python labtex_helper.py ask --help'.",
                   "timeout": "Nobody approved the run on the helper's computer within 10 minutes."}.get(a, "Declined on the helper's computer.")
            say("  ✗ " + msg)
            post_status(cfg, run, state="declined", message=msg)
            return
        if a == "always":
            appr["trusted"] = True
    elif new and not others:
        say("  (Only you changed the code since the last run here, so no approval is needed.)")

    if post_status(cfg, run, state="running", progress=0, message=f"Running on {cfg.get('name')} · {describe(interp)}"):
        say("  (Cancelled in LabTeX.)")
        return

    # --- files + worker
    work = Path(tempfile.mkdtemp(prefix="labtex-run-"))
    try:
        try:
            z = api(cfg, "GET", f"/api/helper/runs/{run['id']}/files", timeout=300, raw=True)
            safe_extract(z, work / "project")
        except ApiError as e:
            raise RuntimeError(f"Couldn't download the project files: {e}")
        (work / "worker.py").write_text(WORKER, encoding="utf-8")
        (work / "cells.json").write_text(json.dumps(cells), encoding="utf-8")
        env = dict(os.environ, LABTEX_DATASETS=json.dumps(datasets), MPLBACKEND="Agg", PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
        cwd = work / "project" / Path(run["file"]).parent
        timeout = float(cfg.get("timeout_minutes", 60)) * 60
        started = time.time()
        p = subprocess.Popen([interp["path"], "-u", str(work / "worker.py"), str(work / "cells.json"), str(work / "out.json")],
                             cwd=str(cwd), env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
        state = {"cancelled": False, "last": 0}
        err_lines = []
        threading.Thread(target=lambda: err_lines.extend(p.stderr), daemon=True).start()

        def watch():
            while p.poll() is None:
                time.sleep(3)
                if p.poll() is None and (post_status(cfg, run) or time.time() - started > timeout):
                    state["cancelled"] = True
                    p.kill()
        threading.Thread(target=watch, daemon=True).start()
        for line in p.stdout:
            m = re.match(r"LABTEX-PROGRESS (\d+) (\d+)", line)
            if m:
                say(f"  cell {m.group(1)}/{m.group(2)} done")
                if time.time() - state["last"] > 1:
                    state["last"] = time.time()
                    if post_status(cfg, run, state="running", progress=int(m.group(1))):
                        state["cancelled"] = True
                        p.kill()
        p.wait()
        if state["cancelled"]:
            if time.time() - started > timeout:
                msg = f"Stopped: it ran longer than the helper's time limit ({cfg.get('timeout_minutes', 60)} minutes)."
                say("  ✗ " + msg)
                api(cfg, "POST", f"/api/helper/runs/{run['id']}/result", {"cells": [], "error": {"message": msg}}, timeout=60)
            else:
                say("  ✗ Cancelled in LabTeX.")
            return
        out = work / "out.json"
        if not out.exists():
            tail = "".join(err_lines)[-1500:].strip()
            raise RuntimeError(f"Python exited before finishing (code {p.returncode}).{(' ' + tail) if tail else ''}")
        res = json.loads(out.read_text(encoding="utf-8"))
        res["env"]["interpreter"] = describe(interp)
        res["env"]["helper"] = cfg.get("name")
        res["data"] = {n: fingerprint(pth) for n, pth in datasets.items()}
        if res.get("error"):
            e = res["error"]
            cell = next((c for c in cells if c["index"] == e["index"]), None)
            if cell and e.get("line"):
                e["qmd_line"] = cell["line"] + int(e["line"])
            e["message"] = f"Cell {e['index'] + 1}{(' (line ' + str(e['qmd_line']) + ')') if e.get('qmd_line') else ''}: {e['message']}"
        r = api(cfg, "POST", f"/api/helper/runs/{run['id']}/result", res, timeout=600)
        took = time.time() - started
        if res.get("error"):
            say(f"  ✗ {res['error']['message']}  (outputs of {r.get('saved', 0)} cell(s) saved)")
        else:
            say(f"  ✓ {r.get('saved', 0)} cell(s) ran in {took:.1f}s; outputs sent to LabTeX.")
        ran = {c["hash"] for c in res["cells"]}
        appr["hashes"] = list((set(appr["hashes"]) | ran))[-2000:]
        for c in cells:
            if c["hash"] in ran:
                appr["code"][str(c["index"])] = c["code"]
        save_config(cfg)
    except Exception as e:
        msg = str(e)
        say("  ✗ " + msg)
        try:
            api(cfg, "POST", f"/api/helper/runs/{run['id']}/result", {"cells": [], "error": {"message": msg}}, timeout=60)
        except Exception:
            pass
    finally:
        shutil.rmtree(work, ignore_errors=True)


# ----------------------------------------------------------------------------- commands

def need_pairing(cfg):
    if not cfg.get("token"):
        sys.exit("This helper isn't paired yet. In LabTeX open Account menu → Python helper, then run:\n"
                 "  python labtex_helper.py pair <LabTeX address> <code>")


def cmd_pair(args):
    cfg = load_config()
    server = args.server.rstrip("/")
    if not re.match(r"^https?://", server):
        server = "https://" + server
    name = args.name or socket.gethostname() or "My computer"
    info = {"os": f"{platform.system()} {platform.release()}", "helper": VERSION}
    try:
        r = api(cfg, "POST", "/api/helper/pair", {"code": args.code, "name": name, "info": info}, server=server, token="")
    except ApiError as e:
        sys.exit(f"Pairing failed: {e}")
    except urllib.error.URLError as e:
        sys.exit(f"Can't reach {server}: {e.reason}")
    cfg.update({"server": server, "token": r["token"], "helper_id": r["helperId"], "name": name, "user": r["user"]})
    cfg.setdefault("interpreter", sys.executable)
    save_config(cfg)
    say(f"✓ Paired with {server} as {r['user']} (this computer: “{name}”).")
    say(f"  Interpreter: {describe(probe(cfg['interpreter']))} — change it with: python labtex_helper.py interpreters")
    say("  Start the helper with: python labtex_helper.py")


def cmd_interpreters(args):
    cfg = load_config()
    say("Looking for Python interpreters…")
    found = find_interpreters()
    cur = os.path.normcase(cfg.get("interpreter") or sys.executable)
    for i, f in enumerate(found, 1):
        mark = "→" if os.path.normcase(f["path"]) == cur else " "
        say(f" {mark} {i:2}. {describe(f):38} {f['path']}")
    cfg["_found"] = [f["path"] for f in found]
    save_config(cfg)
    say("\nChoose one with: python labtex_helper.py use <number or path>")


def cmd_use(args):
    cfg = load_config()
    target = args.interpreter
    if target.isdigit() and cfg.get("_found"):
        i = int(target) - 1
        if not 0 <= i < len(cfg["_found"]):
            sys.exit("No interpreter with that number. List them with: python labtex_helper.py interpreters")
        target = cfg["_found"][i]
    target = os.path.expanduser(target)
    if os.path.isdir(target):  # a venv/conda folder: find its python
        for cand in ("bin/python", "Scripts/python.exe", "python.exe"):
            if os.path.exists(os.path.join(target, cand)):
                target = os.path.join(target, cand)
                break
    info = probe(target)
    if not info:
        sys.exit(f"That doesn't look like a working Python: {target}")
    cfg["interpreter"] = info["path"]
    save_config(cfg)
    say(f"✓ Using {describe(info)}: {info['path']}")
    report(cfg)


def cmd_link(args):
    cfg = load_config()
    if not re.match(r"^[A-Za-z0-9][\w.-]{0,63}$", args.name):
        sys.exit("Dataset names may use letters, numbers, dots, dashes and underscores, e.g. pv-measurements.")
    folder = Path(os.path.expanduser(args.folder)).resolve()
    if not folder.is_dir():
        sys.exit(f"Not a folder: {folder}")
    cfg.setdefault("datasets", {})[args.name] = str(folder)
    save_config(cfg)
    fp = fingerprint(folder)
    say(f"✓ “{args.name}” → {folder}  ({fp['files']} files)")
    say(f'  In Python: labtex.data("{args.name}") / "file.csv"')
    report(cfg)


def cmd_unlink(args):
    cfg = load_config()
    if cfg.get("datasets", {}).pop(args.name, None) is None:
        sys.exit(f"“{args.name}” isn't linked.")
    save_config(cfg)
    say(f"✓ Unlinked “{args.name}”.")
    report(cfg)


def cmd_ask(args):
    cfg = load_config()
    cfg["ask"] = args.mode
    save_config(cfg)
    say({"changes": "✓ Will ask before running code someone else changed (recommended).",
         "always": "✓ Will ask before every run with new or changed code.",
         "never": "✓ Will never ask. Only use this if you trust everyone who can edit your projects."}[args.mode])


def cmd_trust(args):
    cfg = load_config()
    appr = cfg.setdefault("approved", {}).setdefault(args.project, {"hashes": [], "code": {}, "trusted": False})
    appr["trusted"] = not args.off
    save_config(cfg)
    say(("✓ Project %s will run without asking." if not args.off else "✓ Project %s will ask again when someone else changes its code.") % args.project)


def cmd_status(args):
    cfg = load_config()
    if not cfg.get("token"):
        say("Not paired.")
        return
    say(f"LabTeX:      {cfg['server']}  (as {cfg.get('user')}, this computer: “{cfg.get('name')}”)")
    say(f"Interpreter: {describe(probe(cfg.get('interpreter') or sys.executable))}  {cfg.get('interpreter')}")
    ds = cfg.get("datasets", {})
    say("Datasets:    " + (", ".join(f"{k} → {v}" for k, v in ds.items()) if ds else "none linked"))
    say(f"Approval:    {cfg.get('ask', 'changes')}")
    trusted = [k for k, v in cfg.get("approved", {}).items() if v.get("trusted")]
    if trusted:
        say("Trusted projects: " + ", ".join(trusted))


def report(cfg):
    """Tell LabTeX which interpreter and dataset names this helper has (paths stay here)."""
    if not cfg.get("token"):
        return
    interp = probe(cfg.get("interpreter") or sys.executable)
    info = {"os": f"{platform.system()} {platform.release()}", "helper": VERSION, "python": describe(interp) if interp else "not working",
            "datasets": sorted(cfg.get("datasets", {}).keys())}
    try:
        api(cfg, "POST", "/api/helper/hello", {"info": info}, timeout=30)
    except Exception:
        pass


def cmd_start(args):
    cfg = load_config()
    need_pairing(cfg)
    interp = probe(cfg.get("interpreter") or sys.executable)
    say(f"LabTeX Python helper {VERSION} — {cfg['server']} as {cfg.get('user')}")
    say(f"  Interpreter: {describe(interp) if interp else 'NOT WORKING: ' + str(cfg.get('interpreter'))}")
    ds = cfg.get("datasets", {})
    say("  Datasets: " + (", ".join(f"{k} → {v}" for k, v in ds.items()) if ds else "none linked"))
    say("  Waiting for “Run Python” in LabTeX… (Ctrl+C to stop)")
    report(cfg)
    delay = 2
    while True:
        try:
            r = api(cfg, "GET", "/api/helper/next?wait=25", timeout=45)
            delay = 2
            if r and r.get("run"):
                handle_run(cfg, r["run"])
                cfg = load_config()
                if args.once:
                    return
        except KeyboardInterrupt:
            say("\nStopped.")
            return
        except ApiError as e:
            if e.status == 401:
                sys.exit(f"✗ {e}")
            say(f"  (LabTeX error: {e}; retrying)")
            time.sleep(delay)
            delay = min(delay * 2, 60)
        except (urllib.error.URLError, OSError, socket.timeout) as e:
            say(f"  (Can't reach LabTeX: {getattr(e, 'reason', e)}; retrying in {delay}s)")
            time.sleep(delay)
            delay = min(delay * 2, 60)


def main():
    ap = argparse.ArgumentParser(prog="labtex_helper.py", description="Run the Python cells of LabTeX Quarto documents on this computer.")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("pair", help="connect this computer to your LabTeX account")
    p.add_argument("server"); p.add_argument("code"); p.add_argument("--name", help="name for this computer, shown in LabTeX")
    p.set_defaults(fn=cmd_pair)
    sub.add_parser("interpreters", help="list Python interpreters found on this computer").set_defaults(fn=cmd_interpreters)
    p = sub.add_parser("use", help="choose the interpreter (number from 'interpreters', a path, or a venv/conda folder)")
    p.add_argument("interpreter"); p.set_defaults(fn=cmd_use)
    p = sub.add_parser("link", help="link a dataset name to a local folder")
    p.add_argument("name"); p.add_argument("folder"); p.set_defaults(fn=cmd_link)
    p = sub.add_parser("unlink", help="remove a dataset link")
    p.add_argument("name"); p.set_defaults(fn=cmd_unlink)
    p = sub.add_parser("ask", help="when to ask before running code: changes (default), always, never")
    p.add_argument("mode", choices=["changes", "always", "never"]); p.set_defaults(fn=cmd_ask)
    p = sub.add_parser("trust", help="run a project without asking (use --off to undo)")
    p.add_argument("project", help="project id (from the LabTeX address: …/#/p/<id>)"); p.add_argument("--off", action="store_true")
    p.set_defaults(fn=cmd_trust)
    sub.add_parser("status", help="show settings").set_defaults(fn=cmd_status)
    p = sub.add_parser("start", help="start the helper (the default)")
    p.add_argument("--once", action="store_true", help="exit after one run")
    p.set_defaults(fn=cmd_start)
    args = ap.parse_args()
    if not getattr(args, "fn", None):
        args = ap.parse_args(["start"] + sys.argv[1:])
    args.fn(args)


if __name__ == "__main__":
    main()
