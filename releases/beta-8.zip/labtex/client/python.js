// Python cells: the helper settings page and the "Run Python" controls in the editor.
import { h, api, toast, modal, confirmBox, prompt, menu, timeAgo } from './util.js';

const STATUS_TEXT = {
  queued: 'Sending to your helper…',
  awaiting_approval: 'Waiting for approval on',
  running: 'Running on',
  done: 'Python finished',
  failed: 'Python stopped with an error',
  declined: 'Declined on the helper’s computer',
  cancelled: 'Cancelled',
  expired: 'The helper didn’t respond',
};
const ACTIVE = new Set(['queued', 'awaiting_approval', 'running']);
const fmtBytes = (n) => (n > 1e9 ? (n / 1e9).toFixed(1) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : n > 1e3 ? (n / 1e3).toFixed(0) + ' KB' : n + ' B');

/** Account menu → Python helper: pair computers, see their interpreter and datasets, remove them. */
export async function renderHelperPage(main, me) {
  const list = h('div', { class: 'plist' });
  const origin = location.origin;
  const load = async () => {
    const helpers = await api('/api/helpers');
    list.replaceChildren(...(helpers.length ? helpers.map((x) => h('div', { class: 'helper-row' },
      h('span', { class: 'presence-dot static' + (x.online ? ' on' : ''), title: x.online ? 'Running now' : 'Not running' }),
      h('div', { class: 'grow' },
        h('div', {}, h('strong', {}, x.name), h('span', { class: 'muted small' }, x.online ? ' · running now' : x.last_seen_at ? ` · last seen ${timeAgo(x.last_seen_at)}` : '')),
        h('div', { class: 'muted small' }, [x.info?.python, x.info?.os].filter(Boolean).join(' · ') || 'No details yet'),
        x.info?.datasets?.length ? h('div', { class: 'small' }, 'Datasets linked: ', x.info.datasets.map((d) => h('code', { class: 'ds' }, d))) : null),
      h('button', { class: 'icon-btn', 'aria-label': `Actions for ${x.name}`, onclick: (e) => menu(e.currentTarget, [
        { label: 'Rename…', onClick: async () => { const n = await prompt('Rename helper', { value: x.name, okText: 'Rename' }); if (n) { await api(`/api/helpers/${x.id}`, { method: 'PATCH', body: { name: n } }); load(); } } },
        'sep',
        { label: 'Remove…', danger: true, onClick: async () => { if (await confirmBox('Remove helper', `Remove “${x.name}”? It will stop working until you pair it again.`, { okText: 'Remove', danger: true })) { await api(`/api/helpers/${x.id}`, { method: 'DELETE' }); load(); } } },
      ]) }, '⋯'))) : [h('div', { class: 'muted pad' }, 'No computers paired yet.')]));
  };
  const codeBox = h('div', { class: 'pair-box', hidden: true });
  const newCode = async () => {
    const { code } = await api('/api/helpers/pair-code', { method: 'POST' });
    const cmd = `python labtex_helper.py pair ${origin} ${code}`;
    codeBox.hidden = false;
    codeBox.replaceChildren(
      h('div', { class: 'muted small' }, 'Run this on the computer, in the folder where you saved the helper. The code works once, for 10 minutes.'),
      h('div', { class: 'cmd' }, h('code', {}, cmd), h('button', { class: 'btn small', onclick: () => { navigator.clipboard?.writeText(cmd); toast('Copied', 'ok'); } }, 'Copy')));
    const t = setInterval(() => { if (!main.isConnected) clearInterval(t); else load(); }, 4000);
    setTimeout(() => clearInterval(t), 10 * 60e3);
  };
  const step = (n, title, ...body) => h('li', { class: 'setup-step' }, h('span', { class: 'step-n' }, n), h('div', { class: 'grow' }, h('strong', {}, title), ...body));
  const cmd = (c) => h('div', { class: 'cmd' }, h('code', {}, c), h('button', { class: 'btn small', onclick: () => { navigator.clipboard?.writeText(c); toast('Copied', 'ok'); } }, 'Copy'));
  main.replaceChildren(
    h('div', { class: 'dash-head' }, h('div', {}, h('h1', {}, 'Python helper'),
      h('p', { class: 'muted' }, 'Run the Python cells of your Quarto documents on your own computer, with your own Python environment and data. Printed output, tables and plots are saved with the project, so teammates see them too. Your data files never leave your computer.'))),
    h('section', {}, h('h3', {}, 'Your computers'), list),
    h('section', { class: 'setup' }, h('h3', {}, 'Set up a computer'),
      h('ol', { class: 'setup-steps' },
        step(1, 'Download the helper', h('p', { class: 'muted small' }, 'A single file. It needs Python 3.8 or newer and no extra packages.'),
          h('a', { class: 'btn', href: '/helper/labtex_helper.py', download: 'labtex_helper.py' }, '⤓ labtex_helper.py')),
        step(2, 'Pair it with your account', h('div', {}, h('button', { class: 'btn primary', onclick: newCode }, 'Get a pairing code')), codeBox),
        step(3, 'Choose your Python', h('p', { class: 'muted small' }, 'Like choosing the interpreter in VS Code: system Python, a virtual environment or a conda environment. The helper lists the ones it finds.'),
          cmd('python labtex_helper.py interpreters'), cmd('python labtex_helper.py use 2')),
        step(4, 'Link your data folders (optional)', h('p', { class: 'muted small' }, 'Give each folder the dataset name your project uses (Project settings → Python datasets). It can be a Google Drive, Git or Hugging Face folder; files stay on your computer.'),
          cmd('python labtex_helper.py link pv-measurements ~/Drive/pv-data'),
          h('p', { class: 'muted small' }, 'In your code: ', h('code', {}, 'pd.read_csv(labtex.data("pv-measurements") / "run1.csv")'))),
        step(5, 'Start it and leave it running', cmd('python labtex_helper.py'),
          h('p', { class: 'muted small' }, 'Then click ▶ Run Python in a Quarto project. The helper asks you to approve code that someone else changed; your own edits run straight away.')))),
    h('details', { class: 'roles-help' }, h('summary', {}, 'More helper commands'),
      h('ul', {},
        h('li', {}, h('code', {}, 'python labtex_helper.py status'), ' — show the server, interpreter, datasets and approval setting'),
        h('li', {}, h('code', {}, 'python labtex_helper.py ask always|changes|never'), ' — when to ask before running code (default: when someone else changed it)'),
        h('li', {}, h('code', {}, 'python labtex_helper.py trust <project id>'), ' — run a project without asking (', h('code', {}, '--off'), ' to undo)'),
        h('li', {}, h('code', {}, 'python labtex_helper.py unlink <name>'), ' — remove a dataset link'))));
  await load();
}

/**
 * Editor controls: ▶ Run Python + live status. `getProject()` returns the current project.
 * Calls onFinished() when a run finishes so the editor can recompile.
 */
export class PythonControls {
  constructor({ projectId, getProject, me, canRun, onFinished, openLogs }) {
    Object.assign(this, { projectId, getProject, me, canRun, onFinished, openLogs });
    this.state = null;
    this.runBtn = h('button', { class: 'btn small py-run', title: 'Run the Python cells on your computer with the LabTeX helper', onclick: () => this.run() }, '▶ Run Python');
    this.chip = h('span', { class: 'py-chip', hidden: true });
    this.el = h('div', { class: 'py-controls', hidden: true }, this.runBtn, this.chip);
  }
  async refresh() {
    const p = this.getProject();
    if (!/\.qmd$/i.test(p.main_file || '')) { this.el.hidden = true; this.state = null; return; }
    try { this.state = await api(`/api/projects/${this.projectId}/python`); } catch { this.el.hidden = true; return; }
    const hasCells = this.state.cells.length > 0;
    this.el.hidden = !hasCells;
    this.runBtn.hidden = !this.state.canRun;
    this.showRun(this.state.activeRun || this.state.lastRun, !this.state.activeRun);
  }
  summary() {
    const c = this.state?.cells || [];
    const n = (s) => c.filter((x) => x.status === s).length;
    return { fresh: n('fresh'), stale: n('stale'), missing: n('missing'), total: c.filter((x) => x.eval).length };
  }
  showRun(run, settled) {
    const busy = run && ACTIVE.has(run.status);
    this.runBtn.disabled = !!busy;
    this.runBtn.textContent = busy ? 'Python running…' : '▶ Run Python';
    if (!run) {
      const s = this.summary();
      this.chip.hidden = !s.total;
      this.chip.className = 'py-chip muted';
      this.chip.textContent = s.total ? 'Not run yet' : '';
      return;
    }
    this.chip.hidden = false;
    if (busy) {
      const where = run.helper ? ` ${run.helper}` : '';
      this.chip.className = 'py-chip busy';
      this.chip.replaceChildren(h('span', { class: 'spinner' }),
        run.status === 'running' ? `${STATUS_TEXT.running}${where}${run.total ? ` · ${run.progress}/${run.total}` : ''}` : run.status === 'awaiting_approval' ? `${STATUS_TEXT.awaiting_approval}${where}…` : STATUS_TEXT.queued,
        this.canRun ? h('button', { class: 'linkish', onclick: () => this.cancel(run) }, 'Cancel') : null);
      return;
    }
    const s = this.summary();
    const ok = run.status === 'done' && !s.stale && !s.missing;
    this.chip.className = 'py-chip ' + (run.status === 'done' ? (ok ? 'ok' : 'warn') : 'bad');
    this.chip.replaceChildren(
      run.status === 'done' ? (s.stale || s.missing ? `Python: ${s.stale ? `${s.stale} outdated` : ''}${s.stale && s.missing ? ', ' : ''}${s.missing ? `${s.missing} not run` : ''}` : 'Python up to date')
        : STATUS_TEXT[run.status] || run.status,
      h('button', { class: 'linkish', onclick: () => this.openLogs?.() }, 'Details'));
    this.chip.title = [run.finished_at ? `Last run ${timeAgo(run.finished_at)}${run.by ? ' by ' + run.by : ''}${run.helper ? ' on ' + run.helper : ''}` : '', run.message || ''].filter(Boolean).join(' · ');
  }
  async run() {
    const helpers = (this.state?.helpers || []);
    if (!helpers.length) {
      const go = await confirmBox('Set up the Python helper', 'Python cells run on your own computer with the LabTeX helper, using your Python environment and data. Set it up now? It takes a couple of minutes.', { okText: 'Set up' });
      if (go) location.hash = '#/helper';
      return;
    }
    const online = helpers.filter((x) => x.online);
    let helperId = null;
    if (online.length > 1) {
      helperId = await new Promise((resolve) => menu(this.runBtn, online.map((x) => ({ label: `${x.name}${x.info?.python ? ' · ' + x.info.python : ''}`, onClick: () => resolve(x.id) })), () => resolve(null)));
      if (!helperId) return;
    }
    try {
      const r = await api(`/api/projects/${this.projectId}/python/run`, { method: 'POST', body: helperId ? { helperId } : {} });
      this.showRun(r.run);
    } catch (e) {
      toast(e.message, 'error', 8000);
    }
  }
  async cancel(run) {
    try { await api(`/api/projects/${this.projectId}/python/runs/${run.id}/cancel`, { method: 'POST' }); } catch (e) { toast(e.message, 'error'); }
  }
  /** Project event from the server. */
  async onEvent(ev) {
    if (ev.cleared) { await this.refresh(); return; }
    const run = ev.run;
    if (!run) return;
    if (ACTIVE.has(run.status)) { this.showRun(run); return; }
    await this.refresh();
    if (run.status === 'done') this.onFinished?.(run);
    else if (run.status === 'failed') { toast(`Python: ${run.message}`, 'error', 9000); this.onFinished?.(run); }
    else if (['declined', 'expired'].includes(run.status)) toast(`Python: ${run.message || STATUS_TEXT[run.status]}`, 'error', 9000);
  }
  /** "Where these results come from", for the logs panel. */
  provenance() {
    const st = this.state;
    if (!st || !st.cells.length) return null;
    const run = st.lastRun;
    const s = this.summary();
    const pk = run?.env?.packages ? Object.entries(run.env.packages).map(([k, v]) => `${k} ${v}`).join(', ') : '';
    return h('div', { class: 'py-prov' },
      h('div', { class: 'log-head' }, h('strong', {}, 'Python results'), h('span', { class: 'log-src' }, `${s.fresh} up to date${s.stale ? ` · ${s.stale} outdated` : ''}${s.missing ? ` · ${s.missing} not run` : ''}`)),
      run ? h('div', { class: 'small' },
        `${run.status === 'failed' ? 'Last run stopped with an error' : 'Last run'} by ${run.by || 'someone'}${run.helper ? ` on “${run.helper}”` : ''}, ${run.finished_at ? new Date(run.finished_at).toLocaleString() : ''}`,
        run.env ? h('div', { class: 'muted' }, [run.env.interpreter || `Python ${run.env.python}`, pk].filter(Boolean).join(' · ')) : null,
        run.data && Object.keys(run.data).length ? h('div', { class: 'muted' }, 'Data: ', Object.entries(run.data).map(([k, v]) => `${k} (${v.files} files, ${fmtBytes(v.bytes)}, fingerprint ${v.hash})`).join('; ')) : null,
        run.status === 'failed' ? h('div', { class: 'form-error' }, run.message) : null)
        : h('div', { class: 'muted small' }, 'Not run yet. Click ▶ Run Python to run the cells on your computer.'),
      s.stale ? h('div', { class: 'log-hint' }, '💡 Outdated outputs are from an earlier version of the code; they are marked in the document until someone runs Python again.') : null,
      this.canRun && run ? h('button', { class: 'btn tiny', onclick: async () => {
        if (!(await confirmBox('Clear Python outputs', 'Remove all saved Python outputs from this project? The document will show code only until someone runs Python again.', { okText: 'Clear', danger: true }))) return;
        await api(`/api/projects/${this.projectId}/python/outputs`, { method: 'DELETE' });
      } }, 'Clear saved outputs') : null);
  }
}

/** Project settings: dataset names the project's code uses. */
export function datasetsField(project, canEdit) {
  let names = [];
  try { names = JSON.parse(project.py_datasets || '[]'); } catch {}
  const listEl = h('div', { class: 'ds-list' });
  const input = h('input', { type: 'text', placeholder: 'e.g. pv-measurements', disabled: !canEdit });
  const draw = () => listEl.replaceChildren(...(names.length ? names.map((n) => h('span', { class: 'ds-chip' }, h('code', {}, n),
    canEdit && h('button', { type: 'button', class: 'linkish', 'aria-label': `Remove ${n}`, onclick: () => { names = names.filter((x) => x !== n); draw(); } }, '✕'))) : [h('span', { class: 'muted small' }, 'None')]));
  const add = () => { const v = input.value.trim(); if (v && !names.includes(v)) { names.push(v); draw(); } input.value = ''; };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
  draw();
  const el = h('fieldset', {}, h('legend', {}, 'Python datasets'),
    h('p', { class: 'hint' }, 'Names of the local data folders this project’s Python code reads. Everyone links their own copy in their helper; the code uses ', h('code', {}, 'labtex.data("name")'), '.'),
    listEl, canEdit && h('div', { class: 'ds-add' }, input, h('button', { type: 'button', class: 'btn small', onclick: add }, 'Add')));
  return { el, value: () => names, changed: () => JSON.stringify(names) !== (project.py_datasets || '[]') };
}
