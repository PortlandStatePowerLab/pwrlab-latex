// Compiling Quarto (.qmd) projects with the Quarto CLI, in the same sandbox as LaTeX.
//
// Safety: a .qmd can ask Quarto to run code (Python/R/Julia cells, filters, extensions, pre/post-render
// scripts, a custom makeindex program, -shell-escape...). Before every render LabTeX rewrites the
// document's settings so that code cells are shown but never run, drops everything that could execute
// a program or read files outside the project, and never copies Quarto extensions into the build.
// HTML previews are served with a CSP sandbox so their scripts can't act as the viewer.
import fs from 'node:fs';
import path from 'node:path';
import * as yaml from 'js-yaml';
import { run, mkdirShared, writeShared, safePath } from './compile.js';
import { explain } from './diagnose.js';

const QUARTO = process.env.QUARTO_BIN || 'quarto';
const TIMEOUT_MS = Number(process.env.QUARTO_TIMEOUT_SECONDS || process.env.COMPILE_TIMEOUT_SECONDS || 180) * 1000;
const MAX_CONCURRENT = Number(process.env.MAX_CONCURRENT_QUARTO || 2);
export const isQuartoMain = (p) => /\.qmd$/i.test(p || '');

// Quarto renders get their own queue, so they never hold up LaTeX compiles.
let running = 0;
const queue = [];
const acquire = () => new Promise((r) => (running < MAX_CONCURRENT ? (running++, r()) : queue.push(r)));
const release = () => { const next = queue.shift(); if (next) next(); else running--; };
export async function withQuartoSlot(fn) { await acquire(); try { return await fn(); } finally { release(); } }

// Files/folders that only Quarto extensions or project scripts use: never copied into the build.
export const SKIP_IN_BUILD = /(^|\/)(_extensions|\.quarto)(\/|$)/;

// Settings that run programs, load code or read arbitrary files. Removed wherever they appear.
const DROP_KEYS = new Set(['filters', 'shortcodes', 'jupyter', 'knitr', 'engine', 'engines', 'execute', 'execute-dir', 'kernel', 'python', 'julia',
  'pre-render', 'post-render', 'metadata-files', 'metadata-file', 'pdf-engine-opt', 'pdf-engine-opts', 'latex-makeindex', 'latex-makeindex-opts',
  'latex-makeindex-opt', 'latex-tlmgr-opts', 'latex-tlmgr-opt', 'latex-auto-install', 'latex-auto-mk', 'output-dir', 'output-file', 'resource-path',
  'embed-resources', 'self-contained', 'lib-dir', 'freeze', 'cache', 'server', 'shortcodes', 'revealjs-plugins', 'include-in-header-file', 'contributes']);
// Settings that name files: must stay inside the project.
const FILE_KEYS = new Set(['include-in-header', 'include-before-body', 'include-after-body', 'bibliography', 'csl', 'template', 'template-partials',
  'reference-doc', 'css', 'logo', 'cover-image', 'citation-abbreviations', 'syntax-definitions', 'highlight-style', 'theme']);
const PDF_ENGINES = new Set(['pdflatex', 'xelatex', 'lualatex']);

// A relative path inside the project, a bare name (themes, highlight styles) or a web URL.
const insideProject = (p) => /^https?:\/\//.test(p) || (!/^([\/\\~]|[A-Za-z]:)/.test(p) && !!safePath(p));

/** Recursively remove dangerous settings; report what was removed. */
function sanitize(obj, removed, where = '') {
  if (Array.isArray(obj)) return obj.map((x) => sanitize(x, removed, where));
  if (!obj || typeof obj !== 'object') return obj;
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    const key = where ? `${where}.${k}` : k;
    if (DROP_KEYS.has(k)) { removed.add(key); continue; }
    if (k === 'pdf-engine' && !PDF_ENGINES.has(String(v))) { removed.add(key); continue; }
    if (FILE_KEYS.has(k)) {
      const paths = [];
      const collect = (x) => { if (typeof x === 'string') paths.push(x); else if (Array.isArray(x)) x.forEach(collect); else if (x && typeof x === 'object' && typeof x.file === 'string') paths.push(x.file); };
      collect(v);
      if (paths.some((p) => !insideProject(p))) { removed.add(key); continue; }
    }
    out[k] = sanitize(v, removed, key);
  }
  return out;
}

/** Split a .qmd into its YAML settings block and body. */
export function splitFrontMatter(text) {
  const m = text.match(/^---[ \t]*\r?\n([\s\S]*?)\r?\n(?:---|\.\.\.)[ \t]*(?:\r?\n|$)/);
  if (!m) return { meta: {}, body: text, lines: 0 };
  let meta;
  try { meta = yaml.load(m[1]) || {}; } catch (e) {
    const line = e.mark ? e.mark.line + 2 : null;
    const err = new Error(`The settings block at the top of the file isn't valid YAML: ${e.reason || e.message.split('\n')[0]}`);
    err.line = line; throw err;
  }
  if (typeof meta !== 'object' || Array.isArray(meta)) meta = {};
  return { meta, body: text.slice(m[0].length), lines: m[0].split('\n').length - 1 };
}

/**
 * Prepare the build directory for a Quarto render: rewrite the main document's settings and any
 * _quarto.yml / _metadata.yml. Returns notes for the log.
 */
function prepare(dir, mainRel, mainText, engine, target) {
  const notes = [];
  const removed = new Set();
  const { meta, body } = splitFrontMatter(mainText);
  // {{< include >}} must point inside the project.
  for (const m of body.matchAll(/\{\{<\s*include\s+([^\s>]+)\s*>\}\}/g)) {
    const p = m[1].replace(/^["']|["']$/g, '');
    if (/^([\/\\~]|[A-Za-z]:)/.test(p) || !safePath(path.posix.join(path.posix.dirname(mainRel), p))) {
      const e = new Error(`{{< include ${p} >}} points outside the project.`); e.hint = 'Included files must be inside the project, given with a relative path.'; throw e;
    }
  }
  const clean = sanitize(meta, removed);
  // Code cells are shown, never run.
  clean.engine = 'markdown';
  clean.execute = { enabled: false };
  clean['latex-auto-install'] = false;
  const fmtPdf = clean.format && typeof clean.format === 'object' && clean.format.pdf && typeof clean.format.pdf === 'object' ? clean.format.pdf : null;
  if (!clean['pdf-engine'] && !(fmtPdf && fmtPdf['pdf-engine'])) clean['pdf-engine'] = engine;
  if (target === 'pdf') clean['keep-tex'] = true; // the generated LaTeX helps explain errors
  // HTML preview: draw math with the browser's own MathML, so it works without internet access.
  const fmtHtml = clean.format && typeof clean.format === 'object' && clean.format.html && typeof clean.format.html === 'object' ? clean.format.html : null;
  if (target === 'html' && !clean['html-math-method'] && !(fmtHtml && fmtHtml['html-math-method'])) clean['html-math-method'] = 'mathml';
  if (/```\s*\{(python|r|julia|ojs|bash|sql)\b/i.test(body)) notes.push('Code cells are shown as code but not run, so their plots and printed output are not included.');
  if (removed.size) notes.push(`Ignored settings that could run programs or read files outside the project: ${[...removed].join(', ')}.`);
  writeShared(path.join(dir, mainRel), Buffer.from(`---\n${yaml.dump(clean, { lineWidth: -1, noRefs: true })}---\n${body}`, 'utf8'));
  for (const name of ['_quarto.yml', '_quarto.yaml', '_metadata.yml', '_metadata.yaml']) {
    const p = path.join(dir, path.posix.dirname(mainRel), name);
    if (!fs.existsSync(p)) continue;
    let y = {};
    try { y = yaml.load(fs.readFileSync(p, 'utf8')) || {}; } catch { y = {}; notes.push(`${name} isn't valid YAML and was ignored.`); }
    const r = new Set();
    const c = sanitize(y, r);
    if (r.size) notes.push(`Ignored settings in ${name}: ${[...r].join(', ')}.`);
    writeShared(p, Buffer.from(yaml.dump(c, { lineWidth: -1, noRefs: true }), 'utf8'));
  }
  // Extensions could add filters/shortcodes: make sure none are present.
  for (const d of [path.join(dir, '_extensions'), path.join(dir, path.posix.dirname(mainRel), '_extensions')]) fs.rmSync(d, { recursive: true, force: true });
  if (meta.format && typeof meta.format === 'object') {
    const custom = Object.keys(meta.format).filter((k) => k.includes('-') && !['gfm', 'commonmark'].includes(k) && /-(pdf|html)$/.test(k));
    if (custom.length) notes.push(`Formats from Quarto extensions (${custom.join(', ')}) aren't available on LabTeX; the standard PDF format is used.`);
  }
  return notes;
}

const strip = (s) => s.replace(/\x1b\[[0-9;]*m/g, '');

/** Quarto's own messages -> errors/warnings in the same shape as LaTeX ones. */
function parseQuartoOutput(output, mainRel) {
  const errors = [], warnings = [];
  const lines = strip(output).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    let m;
    if ((m = l.match(/^(?:ERROR|Error)(?: \([^)]*\))?:\s*(.*)$/))) {
      let msg = m[1].trim();
      if (!msg || /^compilation failed/.test(msg)) continue; // details come from the LaTeX log
      const ctx = lines.slice(i + 1, i + 4).filter((x) => x.trim()).join(' ');
      const lm = (msg + ' ' + ctx).match(/\(line (\d+), column \d+\)|:(\d+):\d+/);
      let hint = null;
      if (/YAML|front matter|Validation/i.test(msg)) hint = 'Check the settings block between the --- lines at the top of the file (a missing space after a colon or a wrong indent is the usual cause).';
      else if (/Unable to locate|not found|No such file/i.test(msg)) hint = 'Check the file name and folder; names are case-sensitive.';
      else if (/mermaid|chrom/i.test(msg)) hint = 'Mermaid diagrams need a web browser on the server, which LabTeX doesn\'t have. Export the diagram as an image and include that instead.';
      else if (/Unknown format|format .* not found/i.test(msg)) hint = 'LabTeX supports the standard pdf and html formats; formats from Quarto extensions aren\'t available.';
      errors.push({ file: mainRel, line: lm ? Number(lm[1] || lm[2]) : null, source: 'Quarto', message: msg, hint });
    } else if ((m = l.match(/^WARN(?:ING)?(?: \([^)]*\))?:?\s*(.*)$/))) {
      const msg = m[1].trim();
      if (!msg || /Error encountered when rendering files/.test(msg)) continue;
      const xr = msg.match(/Unable to resolve crossref @?([\w-]+)/);
      warnings.push(xr
        ? { file: mainRel, line: null, source: 'Quarto', message: `Cross-reference @${xr[1]} has no matching label.`, hint: `Add {#${xr[1]}} to the figure, table, equation or heading it should point to, or fix the spelling.` }
        : { file: mainRel, line: null, source: 'Quarto', message: msg });
    } else if ((m = l.match(/^\[WARNING\]\s*(.*)$/))) {
      const cite = m[1].match(/Citeproc: citation ([^\s]+) not found/);
      warnings.push(cite ? { file: mainRel, line: null, source: 'Quarto', message: `Citation @${cite[1]} isn't in your bibliography.`, hint: 'Check the key against your .bib file (keys are case-sensitive) and that `bibliography:` names the right file.' }
        : { file: mainRel, line: null, source: 'pandoc', message: m[1] });
    }
  }
  return { errors, warnings };
}

/**
 * Render a Quarto project. `target` is 'pdf' (the normal compile) or 'html' (preview).
 * Expects the build directory to be synced already. Returns the same shape as a LaTeX compile.
 */
export async function renderQuarto({ dir, mainRel, mainText, engine, target = 'pdf', parseLog }) {
  const started = Date.now();
  let notes;
  try { notes = prepare(dir, mainRel, mainText, engine || 'xelatex', target); }
  catch (e) {
    return { ok: false, hasPdf: false, kind: 'quarto', errors: [{ file: mainRel, line: e.line || null, source: 'Quarto', message: e.message, hint: e.hint || 'Check the settings block between the --- lines at the top of the file (a missing space after a colon or a wrong indent is the usual cause).' }], warnings: [], log: '', ms: Date.now() - started };
  }
  const base = mainRel.replace(/\.qmd$/i, '');
  const outFile = path.join(dir, base + (target === 'pdf' ? '.pdf' : '.html'));
  const cache = path.join(dir, '.labtex-cache');
  mkdirShared(cache);
  const { code, output, timedOut } = await run(QUARTO, ['render', mainRel, '--to', target, '--no-execute'], dir, {
    timeoutMs: TIMEOUT_MS,
    env: { XDG_CACHE_HOME: cache, XDG_DATA_HOME: cache, XDG_CONFIG_HOME: cache, DENO_DIR: path.join(cache, 'deno'), QUARTO_PRINT_STACK: '', DENO_NO_UPDATE_CHECK: '1', NO_COLOR: '1' },
  });
  const okFile = fs.existsSync(outFile) && fs.statSync(outFile).mtimeMs >= started - 1000;
  const q = parseQuartoOutput(output, mainRel);
  // LaTeX errors from the generated .tex: line numbers refer to that file, not the .qmd.
  let latex = { errors: [], warnings: [] };
  let texLog = '';
  if (target === 'pdf') {
    try { texLog = fs.readFileSync(path.join(dir, base + '.log'), 'latin1'); if (fs.statSync(path.join(dir, base + '.log')).mtimeMs < started - 1000) texLog = ''; } catch {}
    if (texLog) latex = parseLog(texLog);
    explain(latex.errors);
    for (const e of [...latex.errors, ...latex.warnings]) {
      if (!e.file || e.file.replace(/^\.\//, '') === base + '.tex') {
        e.message = e.message.replace(/\n?l\.\d+.*$/s, '');
        e.hint = (e.hint ? e.hint + ' ' : '') + `(This comes from the LaTeX that Quarto generated from ${mainRel}; look for the matching text in your document.)`;
        e.file = mainRel; e.line = null;
      }
    }
  }
  const errors = [...q.errors, ...latex.errors];
  const warnings = [...notes.map((n) => ({ file: null, line: null, source: 'LabTeX', message: n })), ...q.warnings, ...latex.warnings];
  if (timedOut) errors.unshift({ file: null, line: null, message: `Quarto timed out after ${TIMEOUT_MS / 1000}s.`, hint: 'Very large documents or many figures can take long; try again, or split the document.' });
  if (code === -1) errors.unshift({ file: null, line: null, message: 'Quarto isn\'t installed on the server.', hint: 'Ask your LabTeX admin to rebuild the Docker image (docker compose up -d --build); it includes Quarto.' });
  if (!okFile && !errors.length) {
    const tail = strip(output).trim().split('\n').filter((l) => l.trim()).slice(-3).join('\n');
    errors.push({ file: null, line: null, message: 'Quarto didn\'t produce a ' + target.toUpperCase() + '.', hint: tail ? `The last lines of its output were:\n${tail}` : 'Open the raw log for details.' });
  }
  return {
    ok: okFile && errors.length === 0, hasPdf: target === 'pdf' ? fs.existsSync(outFile) : undefined, hasHtml: target === 'html' ? okFile : undefined,
    kind: 'quarto', errors, warnings,
    log: strip(output).slice(-30000) + (texLog ? `\n\n===== LaTeX log (${base}.log) =====\n` + texLog.slice(-30000) : ''),
    ms: Date.now() - started,
  };
}
