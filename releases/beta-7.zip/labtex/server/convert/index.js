// LaTeX <-> Quarto conversion.
//
//  .tex -> .qmd   pandoc + our Lua filter (tex2qmd.lua). The LaTeX preamble is analysed and
//                 mapped to Quarto YAML (class, options, geometry, citations, PDF standard...); anything
//                 without a Quarto equivalent is kept as raw LaTeX so PDF output still matches.
//  .qmd -> .tex   pandoc + qmd2tex.lua, which understands Quarto's own syntax (cross-references,
//                 figure/table divs, callouts, code cells, shortcodes, format: pdf: options). The Quarto
//                 program is not needed and nothing in the document is ever executed.
//
// Vector figures (PDF/EPS/SVG) can be rasterised to PNG or JPEG at a chosen resolution and quality.
// Text encodings are detected/converted for uploaded files.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as yaml from 'js-yaml';
import { run, makeScratchDir, mkdirShared, writeShared, acquireSlot, releaseSlot, safePath } from '../compile.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const LUA_FILTER = path.join(here, 'tex2qmd.lua');
const QMD_FILTER = path.join(here, 'qmd2tex.lua');
const PANDOC = process.env.PANDOC_BIN || 'pandoc';
const TIMEOUT_MS = Number(process.env.CONVERT_TIMEOUT_SECONDS || 120) * 1000;

export const DEFAULT_OPTIONS = {
  wrap: 'none',            // none | columns | preserve
  columns: 80,
  xrefs: true,             // \label/\ref <-> Quarto @fig-/@tbl-/@eq-/@sec- cross-references
  preamble: true,          // carry the LaTeX class, options, packages and macros into Quarto YAML
  rawLatex: true,          // keep LaTeX that has no Markdown equivalent (instead of dropping it)
  htmlFormat: true,        // also add an HTML format to converted .qmd files
  citeMethod: 'auto',      // auto | natbib | biblatex | citeproc
  figureFormat: 'keep',    // keep | png | jpeg   (applies to PDF/EPS/SVG figures)
  dpi: 300,                // resolution used when rasterising PDF/EPS/SVG figures
  quality: 90,             // JPEG quality (1-100)
  inputEncoding: 'auto',   // auto | utf-8 | windows-1252 | iso-8859-1   (uploaded files)
  outputBom: false,        // UTF-8 byte-order mark on downloaded text files
  lineEndings: 'lf',       // lf | crlf                                   (downloaded text files)
  zipLevel: 6,             // 0 (store) - 9 (smallest) for downloads
  onConflict: 'keep-both', // keep-both | replace
};

export function normalizeOptions(o = {}) {
  const d = DEFAULT_OPTIONS;
  const pick = (k, allowed) => (allowed.includes(o[k]) ? o[k] : d[k]);
  const num = (k, lo, hi) => { const n = Number(o[k]); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d[k]; };
  const bool = (k) => (typeof o[k] === 'boolean' ? o[k] : d[k]);
  return {
    wrap: pick('wrap', ['none', 'columns', 'preserve']), columns: num('columns', 40, 200),
    xrefs: bool('xrefs'), preamble: bool('preamble'), rawLatex: bool('rawLatex'), htmlFormat: bool('htmlFormat'),
    citeMethod: pick('citeMethod', ['auto', 'natbib', 'biblatex', 'citeproc']),
    figureFormat: pick('figureFormat', ['keep', 'png', 'jpeg']),
    dpi: num('dpi', 72, 1200), quality: num('quality', 1, 100),
    inputEncoding: pick('inputEncoding', ['auto', 'utf-8', 'windows-1252', 'iso-8859-1']),
    outputBom: bool('outputBom'), lineEndings: pick('lineEndings', ['lf', 'crlf']),
    zipLevel: num('zipLevel', 0, 9), onConflict: pick('onConflict', ['keep-both', 'replace']),
  };
}

export const directionFor = (p) => (/\.tex$/i.test(p) ? 'tex2qmd' : /\.(qmd|md)$/i.test(p) ? 'qmd2tex' : null);

// ---------------- text encodings ----------------

/** Decode bytes as text. 'auto' = UTF-8 if valid, otherwise Windows-1252 (a superset of Latin-1). */
export function decodeText(buf, enc = 'auto') {
  if (typeof buf === 'string') return { text: buf, encoding: 'utf-8' };
  let b = buf;
  if (b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf) b = b.subarray(3); // strip UTF-8 BOM
  if (enc === 'auto') {
    try { return { text: new TextDecoder('utf-8', { fatal: true }).decode(b), encoding: 'utf-8' }; }
    catch { return { text: new TextDecoder('windows-1252').decode(b), encoding: 'windows-1252' }; }
  }
  return { text: new TextDecoder(enc).decode(b), encoding: enc };
}

/** Encode text for download according to the options. */
export function encodeForDownload(text, opts) {
  let t = text.replace(/\r\n/g, '\n');
  if (opts.lineEndings === 'crlf') t = t.replace(/\n/g, '\r\n');
  const body = Buffer.from(t, 'utf8');
  return opts.outputBom ? Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), body]) : body;
}

// ---------------- small LaTeX parsing helpers ----------------

/** Index just past a balanced {...} group starting at s[i] === '{'. */
function braced(s, i) {
  if (s[i] !== '{') return null;
  let depth = 0;
  for (let j = i; j < s.length; j++) {
    const c = s[j];
    if (c === '\\') { j++; continue; }
    if (c === '{') depth++;
    else if (c === '}' && --depth === 0) return { content: s.slice(i + 1, j), end: j + 1 };
  }
  return null;
}
function bracketed(s, i) {
  if (s[i] !== '[') return null;
  let depth = 0;
  for (let j = i; j < s.length; j++) {
    const c = s[j];
    if (c === '{') depth++; else if (c === '}') depth--;
    else if (c === ']' && depth === 0) return { content: s.slice(i + 1, j), end: j + 1 };
  }
  return null;
}
const skipWs = (s, i) => { while (i < s.length && /\s/.test(s[i])) i++; return i; };
/** Split "a, b={x,y}, c" at top-level commas (LaTeX comments removed first). */
function splitTop(s) {
  s = s.split('\n').map((l) => { const c = commentStart(l); return c === -1 ? l : l.slice(0, c); }).join('\n');
  const out = []; let depth = 0, cur = '';
  for (const c of s) {
    if (c === '{') depth++; else if (c === '}') depth--;
    if (c === ',' && depth === 0) { if (cur.trim()) out.push(cur.trim()); cur = ''; } else cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
/** Position of the first unescaped % on a line (start of a comment), or -1. */
function commentStart(line) {
  for (let i = 0; i < line.length; i++) {
    if (line[i] === '\\') { i++; continue; }
    if (line[i] === '%') return i;
  }
  return -1;
}
/**
 * Find a command and its arguments in s, outside comments. spec: 'o' optional [..], 'm' mandatory {..}.
 * Returns [{ start, end, args: [string|null] }].
 */
function findCommands(s, name, spec) {
  const out = [];
  const re = new RegExp(`\\\\${name}(?![A-Za-z@])`, 'g');
  let m;
  while ((m = re.exec(s))) {
    const lineStart = s.lastIndexOf('\n', m.index) + 1;
    const cs = commentStart(s.slice(lineStart, m.index + 1));
    if (cs !== -1 && lineStart + cs < m.index) continue;
    let i = m.index + m[0].length;
    const args = [];
    let ok = true;
    for (const t of spec) {
      i = skipWs(s, i);
      const r = t === 'o' ? bracketed(s, i) : braced(s, i);
      if (r) { args.push(r.content); i = r.end; } else if (t === 'o') args.push(null); else { ok = false; break; }
    }
    if (ok) { out.push({ start: m.index, end: i, args }); re.lastIndex = i; }
  }
  return out;
}
/** Remove ranges from s (ranges may be unsorted). */
function cut(s, ranges) {
  let out = s;
  for (const r of [...ranges].sort((a, b) => b.start - a.start)) out = out.slice(0, r.start) + out.slice(r.end);
  return out;
}

const posixDir = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '');
const joinRel = (dir, p) => path.posix.normalize(dir ? `${dir}/${p}` : p).replace(/^\.\//, '');

/** Inline \input/\include/\subfile recursively (paths relative to the main file's folder, like LaTeX). */
// LaTeX that must stay byte-for-byte (manual PDF tagging breaks if split into Markdown pieces).
const FRAGILE = /\\(tagstructbegin|tagstructend|tagmcbegin|tagmcend|tagpdfparaOff|tagpdfparaOn|tagpdfsetup|tagstructuse|tagmcuse)\b/;

function flattenIncludes(text, mainDir, getText, warnings, depth = 0, seen = new Set(), keepRaw = null) {
  if (depth > 20) return text;
  return text.split('\n').map((line) => {
    const cs = commentStart(line);
    const code = cs === -1 ? line : line.slice(0, cs);
    const rest = cs === -1 ? '' : line.slice(cs);
    const replaced = code.replace(/\\(input|include|subfile)\s*\{([^}]+)\}/g, (all, cmd, target) => {
      const rel = target.trim();
      const candidates = [joinRel(mainDir, rel), joinRel(mainDir, rel + '.tex')];
      const found = candidates.find((c) => getText(c) != null);
      if (!found) { warnings.push(`Could not find included file “${rel}”; left as \\${cmd}.`); return all; }
      if (seen.has(found)) return '';
      const inner = flattenIncludes(getText(found), mainDir, getText, warnings, depth + 1, new Set([...seen, found]), keepRaw);
      const wrapped = keepRaw && FRAGILE.test(inner) ? keepRaw(inner, found) : inner;
      return (cmd === 'include' ? '\\clearpage\n' : '') + wrapped + (cmd === 'include' ? '\n\\clearpage' : '');
    });
    return replaced + rest;
  }).join('\n');
}

const SCOPE_DECL = /^\s*\\(centering|raggedright|raggedleft|normalfont|normalsize|small|footnotesize|scriptsize|tiny|large|Large|LARGE|huge|Huge|bfseries|itshape|slshape|scshape|sffamily|ttfamily|rmfamily|color|singlespacing|doublespacing|onehalfspacing|setlength|linespread)\b/;
/** Keep multi-line {\declaration ...} groups that start a line verbatim (see texToQmd). */
function keepScopedGroups(body, keepRaw) {
  let out = '', i = 0;
  while (i < body.length) {
    const j = body.indexOf('{', i);
    if (j === -1) { out += body.slice(i); break; }
    const lineStart = body.lastIndexOf('\n', j - 1) + 1;
    const before = body.slice(lineStart, j);
    const g = /^\s*$/.test(before) && commentStart(body.slice(lineStart, j + 1)) === -1 ? braced(body, j) : null;
    if (g && g.content.includes('\n') && SCOPE_DECL.test(g.content.replace(/^\s*(%[^\n]*\n\s*)*/, ''))) {
      out += body.slice(i, j) + keepRaw(body.slice(j, g.end), null);
      i = g.end;
    } else { out += body.slice(i, j + 1); i = j + 1; }
  }
  return out;
}

// ---------------- LaTeX preamble -> Quarto YAML ----------------

const BABEL_LANG = { american: 'en-US', english: 'en', USenglish: 'en-US', british: 'en-GB', UKenglish: 'en-GB', canadian: 'en-CA', australian: 'en-AU',
  ngerman: 'de', german: 'de', french: 'fr', francais: 'fr', spanish: 'es', italian: 'it', portuguese: 'pt', brazilian: 'pt-BR', dutch: 'nl',
  swedish: 'sv', norsk: 'nb', danish: 'da', finnish: 'fi', polish: 'pl', czech: 'cs', russian: 'ru', greek: 'el', turkish: 'tr', japanese: 'ja', chinese: 'zh' };
// Packages Quarto's LaTeX template loads itself; a plain \usepackage of these is dropped.
const QUARTO_LOADS = new Set(['inputenc', 'fontenc', 'lmodern', 'textcomp', 'hyperref', 'bookmark', 'graphicx', 'amsmath', 'amssymb', 'xcolor',
  'geometry', 'babel', 'natbib', 'biblatex', 'iftex', 'xurl', 'url', 'upquote', 'microtype', 'longtable', 'booktabs', 'array', 'calc', 'etoolbox',
  'footnotehyper', 'footnote', 'fancyvrb', 'selnolig', 'csquotes', 'parskip']);

function analysePreamble(beforeClass, preamble, cls, engineHint, opts, warnings, customTitle) {
  const pdf = { documentclass: cls.name };
  if (cls.options.length) pdf.classoption = [...cls.options];
  const top = {};
  const cite = { method: null, natbibOptions: null, biblatexOptions: [], style: null };
  const graphicspath = [];
  let pre = preamble;
  const removals = [];

  // \DocumentMetadata{lang=...}: the language feeds Quarto's `lang`; the block itself is copied
  // verbatim into a template partial (see texToQmd) so tagging/PDF-standard settings are unchanged.
  for (const c of findCommands(beforeClass, 'DocumentMetadata', ['m'])) {
    for (const kv of splitTop(c.args[0])) {
      const [k, ...v] = kv.split('='); const val = v.join('=').trim().replace(/^\{|\}$/g, '');
      if (k.trim() === 'lang' && val && !top.lang) top.lang = val;
    }
  }

  // Packages.
  const keepLines = [];
  for (const c of [...findCommands(pre, 'usepackage', ['o', 'm']), ...findCommands(pre, 'RequirePackage', ['o', 'm'])]) {
    removals.push(c);
    const optsStr = c.args[0];
    const pkgs = c.args[1].split(',').map((x) => x.trim()).filter(Boolean);
    const optList = optsStr ? splitTop(optsStr) : [];
    const kept = [];
    for (const pkg of pkgs) {
      if (pkg === 'fontspec' || pkg === 'unicode-math') engineHint.unicode = true;
      if (pkg === 'luacode' || pkg === 'luatexbase') engineHint.lua = true;
      if (pkg === 'inputenc') engineHint.pdftex = true;
      if (!optList.length) {
        if (['inputenc', 'fontenc', 'lmodern', 'textcomp'].includes(pkg)) (top.fontLines ||= []).push(`\\usepackage{${pkg}}`);
        if (!QUARTO_LOADS.has(pkg)) kept.push(pkg);
        continue;
      }
      switch (pkg) {
        case 'graphicx': case 'graphics': {
          // Driver options (pdftex, dvips...) are chosen automatically today, and Quarto loads graphicx
          // itself: passing them again would clash. Keep any other options.
          const rest = optList.filter((o) => !/^(pdftex|dvips|dvipdfmx|xetex|luatex|dvipdfm|dvisvgm)$/.test(o));
          if (rest.length) keepLines.push(`\\PassOptionsToPackage{${rest.join(',')}}{${pkg}}`, `\\setkeys{Gin}{}`);
          break;
        }
        case 'geometry': pdf.geometry = optList; break;
        case 'hyperref': pdf.hyperrefoptions = optList; break;
        case 'xcolor': pdf.classoption = [...(pdf.classoption || []), ...optList.filter((o) => !(pdf.classoption || []).includes(o))]; break;
        case 'babel': {
          const l = optList.filter((o) => !o.includes('=')).pop();
          if (l) { top.lang = BABEL_LANG[l] || l; top.babel = true; }
          top.babelLine = `\\usepackage[${optsStr}]{babel}`; // reproduced exactly via a template partial
          break;
        }
        case 'natbib': cite.method = 'natbib'; cite.natbibOptions = optList.join(','); break;
        case 'biblatex':
          cite.method = 'biblatex';
          for (const o of optList) { if (/^style=/.test(o)) cite.style = o.slice(6); else cite.biblatexOptions.push(o); }
          break;
        case 'microtype': pdf.microtypeoptions = optList; break;
        case 'caption': keepLines.push('\\usepackage{caption}', `\\captionsetup{${optsStr}}`); break;
        case 'inputenc': case 'fontenc': case 'lmodern': case 'textcomp':
          (top.fontLines ||= []).push(`\\usepackage[${optsStr}]{${pkg}}`); break;
        default: keepLines.push(`\\usepackage[${optsStr}]{${pkg}}`);
      }
    }
    if (!optList.length && pkgs.includes('natbib')) cite.method = 'natbib';
    if (!optList.length && pkgs.includes('biblatex')) cite.method = 'biblatex';
    if (kept.length) keepLines.push(`\\usepackage{${kept.join(',')}}`);
  }
  for (const c of findCommands(pre, 'geometry', ['m'])) { removals.push(c); pdf.geometry = [...(pdf.geometry || []), ...splitTop(c.args[0])]; }
  // With \maketitle, Quarto prints the title from YAML. A custom title page keeps its own commands.
  if (!customTitle) {
    for (const name of ['title', 'author', 'date', 'thanks', 'subtitle', 'keywords']) {
      for (const c of findCommands(pre, name, ['o', 'm'])) removals.push(c);
    }
  }
  for (const c of findCommands(pre, 'bibliographystyle', ['m'])) { removals.push(c); cite.style = cite.style || c.args[0]; }
  for (const c of findCommands(pre, 'addbibresource', ['o', 'm'])) { removals.push(c); }
  for (const c of findCommands(pre, 'graphicspath', ['m'])) {
    for (const m of c.args[0].matchAll(/\{([^}]*)\}/g)) graphicspath.push(m[1].replace(/\/$/, ''));
  }
  pre = cut(pre, removals);
  // hyperref is loaded after header includes in Quarto's template.
  pre = pre.replace(/\\hypersetup\s*\{/g, '\\AtBeginDocument{\\hypersetup{');
  // close the extra brace we opened for each \hypersetup
  pre = closeHypersetup(pre);

  // Quarto's template defines \listoflistings itself; minted/newfloat/listings define it too.
  if (keepLines.some((l) => /\{[^}]*\b(minted|newfloat|listings)\b[^}]*\}/.test(l)) || /\\usepackage(\[[^\]]*\])?\{(minted|listings)\}/.test(pre)) {
    keepLines.push('% let Quarto define its own \\listoflistings, then restore this package\'s version',
      '\\let\\labtexlistoflistings\\listoflistings\\let\\listoflistings\\relax',
      '\\AtBeginDocument{\\ifdefined\\labtexlistoflistings\\let\\listoflistings\\labtexlistoflistings\\fi}');
  }
  // Custom title page: Quarto's template always calls \author{} and \date{}, which would wipe (or, in
  // some classes, break) the document's own values. Ignore those calls; restore the commands afterwards.
  const titleGuard = customTitle ? [
    '% Quarto always emits \\author{} and \\date{}; keep this document\'s own title-page values instead',
    '\\let\\labtexauthor\\author\\let\\labtexdate\\date',
    '\\def\\author#1{}\\def\\date#1{}',
    '\\AtBeginDocument{\\let\\author\\labtexauthor\\let\\date\\labtexdate}',
  ] : [];
  const header = [...keepLines, pre.split('\n').filter((l) => !/^\s*%/.test(l)).join('\n').replace(/\n{3,}/g, '\n\n').trim()]
    .concat(titleGuard).filter(Boolean).join('\n');
  return { pdf, top, cite, graphicspath, header };
}
function closeHypersetup(s) {
  let out = '', i = 0;
  const key = '\\AtBeginDocument{\\hypersetup{';
  while (true) {
    const j = s.indexOf(key, i);
    if (j === -1) { out += s.slice(i); break; }
    const b = braced(s, j + key.length - 1);
    if (!b) { out += s.slice(i); break; }
    out += s.slice(i, b.end) + '}';
    i = b.end;
  }
  return out;
}

// ---------------- figures ----------------

const IMG_EXTS = ['.pdf', '.png', '.jpg', '.jpeg', '.eps', '.svg', '.gif', '.webp', '.tif', '.tiff'];
const VECTOR = /\.(pdf|eps|svg)$/i;

function resolveImage(ref, baseDir, graphicspath, has) {
  const clean = ref.replace(/^\.\//, '').replace(/^"|"$/g, '');
  const dirs = [baseDir, ...graphicspath.map((g) => joinRel(baseDir, g))];
  for (const d of dirs) {
    const p = joinRel(d, clean);
    if (has(p)) return p;
    if (!path.extname(clean)) for (const e of IMG_EXTS) if (has(p + e)) return p + e;
  }
  return null;
}

/**
 * Convert one vector figure (PDF/EPS/SVG). fmt: 'png' | 'jpeg' | 'pdf' (SVG -> PDF for LaTeX).
 * Runs poppler / Ghostscript / librsvg in the sandbox. Returns a Buffer.
 */
async function convertImage(relPath, buf, fmt, opts) {
  const dir = makeScratchDir('img');
  try {
    const ext = path.extname(relPath).toLowerCase();
    let src = 'in' + ext;
    writeShared(path.join(dir, src), buf);
    const tool = async (cmd, args, what) => {
      const r = await run(cmd, args, dir, { timeoutMs: 60000, clean: true });
      if (r.code !== 0) throw new Error(r.code === -1 ? `${what} needs ${cmd}, which isn't installed on the server.` : `${what} failed.`);
    };
    if (ext === '.svg') {
      if (fmt === 'pdf') { await tool('rsvg-convert', ['-f', 'pdf', '-o', 'out.pdf', src], 'SVG conversion'); return fs.readFileSync(path.join(dir, 'out.pdf')); }
      await tool('rsvg-convert', ['-f', 'pdf', '-o', 'in.pdf', src], 'SVG conversion'); src = 'in.pdf';
    } else if (ext === '.eps') {
      await tool('epstopdf', ['--outfile=in.pdf', src], 'EPS conversion'); src = 'in.pdf';
      if (fmt === 'pdf') return fs.readFileSync(path.join(dir, 'in.pdf'));
    } else if (ext !== '.pdf') throw new Error(`${ext} figures can't be converted here.`);
    const args = fmt === 'jpeg'
      ? ['-jpeg', '-jpegopt', `quality=${opts.quality}`, '-singlefile', '-f', '1', '-l', '1', '-r', String(opts.dpi), src, 'out']
      : ['-png', '-singlefile', '-f', '1', '-l', '1', '-r', String(opts.dpi), src, 'out'];
    await tool('pdftocairo', args, 'Rasterising the figure');
    return fs.readFileSync(path.join(dir, fmt === 'jpeg' ? 'out.jpg' : 'out.png'));
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

/**
 * Rewrite figure references in text: resolve paths and (optionally) convert files.
 * kind: 'md' (Markdown images + raw \includegraphics) or 'tex'.
 */
async function processFigures(text, kind, baseDir, graphicspath, fmt, forceCompat, files, outFiles, opts, warnings, scratch) {
  const has = (p) => files.has(p) || outFiles.has(p);
  const get = (p) => outFiles.get(p) || files.get(p);
  const refs = [];
  if (kind === 'md') for (const m of text.matchAll(/!\[[^\]]*\]\(([^)\s]+)/g)) refs.push({ match: m, ref: m[1], index: m.index + m[0].length - m[1].length });
  for (const m of text.matchAll(/\\includegraphics\s*(?:\[[^\]]*\])?\s*\{([^}]+)\}/g)) refs.push({ match: m, ref: m[1], index: m.index + m[0].length - m[1].length - 1 });
  const replacements = [];
  const converted = new Map();
  let count = 0;
  for (const r of refs) {
    const resolved = resolveImage(r.ref, baseDir, graphicspath, has);
    if (!resolved) { warnings.push(`Figure “${r.ref}” was not found in the project.`); continue; }
    let target = resolved;
    // Only vector figures are converted; bitmaps are copied as they are.
    let want = VECTOR.test(resolved) ? fmt : 'keep';
    if (forceCompat && /\.svg$/i.test(resolved) && want === 'keep') want = 'pdf'; // LaTeX can't include SVG
    if (forceCompat && /\.(webp|gif|tif|tiff)$/i.test(resolved)) warnings.push(`Figure “${resolved}”: LaTeX can't include ${path.extname(resolved)} images. Convert it to PNG or JPG.`);
    const ext = { png: '.png', jpeg: '.jpg', pdf: '.pdf' }[want];
    if (want !== 'keep' && path.extname(resolved).toLowerCase() !== ext) {
      if (converted.has(resolved)) target = converted.get(resolved);
      else {
        try {
          const out = await convertImage(resolved, get(resolved), want, opts);
          let name = resolved.replace(/\.[^./]+$/, '') + ext;
          if (files.has(name) && !outFiles.has(name)) name = resolved.replace(/\.[^./]+$/, '') + '-converted' + ext;
          outFiles.set(name, out);
          converted.set(resolved, name);
          target = name; count++;
        } catch (e) { warnings.push(`Figure “${resolved}”: ${e.message}`); }
      }
    }
    const rel = path.posix.relative(baseDir || '.', target) || target;
    if (rel !== r.ref) replacements.push({ start: r.index, end: r.index + r.ref.length, value: rel });
  }
  let out = text;
  for (const rep of replacements.sort((a, b) => b.start - a.start)) out = out.slice(0, rep.start) + rep.value + out.slice(rep.end);
  return { text: out, converted: count };
}

// ---------------- .tex -> .qmd ----------------

async function texToQmd(files, src, opts, ctx, outFiles) {
  const warnings = [];
  const getText = (p) => (files.has(p) ? decodeText(files.get(p), opts.inputEncoding).text : null);
  const dir = posixDir(src);
  // Chunks of LaTeX kept verbatim, substituted back as ```{=latex} blocks after pandoc.
  const rawChunks = [];
  const keepRaw = (content, file) => {
    rawChunks.push({ content, file });
    return `\n\n\\LABTEXRAW{${rawChunks.length - 1}}\n\n`;
  };
  let text = flattenIncludes(getText(src), dir, getText, warnings, 0, new Set(), keepRaw);

  let m = text.match(/\\documentclass\s*(?:\[([^\]]*)\])?\s*\{([^}]*)\}/);
  if (!m) {
    warnings.push('No \\documentclass found: converted as a document fragment.');
    text = `\\documentclass{article}\n\\begin{document}\n${text}\n\\end{document}\n`;
    m = text.match(/\\documentclass\s*(?:\[([^\]]*)\])?\s*\{([^}]*)\}/);
  }
  const cls = { name: m[2].trim(), options: m[1] ? splitTop(m[1]) : [] };
  let beginDoc = text.indexOf('\\begin{document}');
  if (beginDoc === -1) throw new Error('No \\begin{document} found.');
  // Files kept verbatim only matter in the body; in the preamble (copied as-is anyway) expand them back.
  const head = text.slice(0, beginDoc).replace(/\n*\\LABTEXRAW\{(\d+)\}\n*/g, (all, n) => {
    const c = rawChunks[Number(n)]; c.file = null; return '\n' + c.content + '\n';
  });
  text = head + text.slice(beginDoc);
  beginDoc = head.length;
  m = text.match(/\\documentclass\s*(?:\[([^\]]*)\])?\s*\{([^}]*)\}/);
  const beforeClass = text.slice(0, m.index);
  const preamble = text.slice(m.index + m[0].length, beginDoc);
  const body = text.slice(beginDoc + '\\begin{document}'.length);

  const engineHint = {};
  // Custom title: no \maketitle (own title page), or an author block with LaTeX formatting
  // (e.g. IEEE \IEEEauthorblockN) that Quarto's author list can't represent.
  const authorArg = findCommands(text, 'author', ['o', 'm'])[0]?.args[1] || '';
  const complexAuthor = /\\(?!and\b|thanks\b)[A-Za-z]+/.test(authorArg.replace(/\\\\/g, ''));
  const keepMaketitle = /\\maketitle\b/.test(body) && complexAuthor;
  const customTitle = !/\\maketitle\b/.test(body) || complexAuthor;
  const info = analysePreamble(beforeClass, preamble, cls, engineHint, opts, warnings, customTitle);

  // Two-column layouts: Quarto typesets Markdown tables as longtable, which LaTeX can't use in
  // two-column mode. Keep those tables as their original LaTeX instead.
  const twocol = cls.options.includes('twocolumn') || (/^IEEEtran$/i.test(cls.name) && !cls.options.includes('onecolumn')) || /\\twocolumn\b/.test(body);
  let bodyIn = body;
  let tableCount = 0;
  if (twocol) {
    bodyIn = bodyIn.replace(/\\begin\{(table\*?)\}[\s\S]*?\\end\{\1\}/g, (all) => { tableCount++; return keepRaw(all, null); });
    if (tableCount) warnings.push(`Two-column layout: ${tableCount} table(s) kept as LaTeX so they still work in the PDF (they won’t appear in HTML output).`);
  }
  if (customTitle) {
    // Title commands written in the body (IEEE style) + \maketitle: keep the whole block verbatim.
    const mt = bodyIn.search(/\\maketitle\b/);
    const first = bodyIn.search(/\\(title|author|date)\s*[[{]/);
    if (mt !== -1 && first !== -1 && first < mt) {
      const end = mt + '\\maketitle'.length;
      bodyIn = bodyIn.slice(0, first) + keepRaw(bodyIn.slice(first, end), null) + bodyIn.slice(end);
    }
    // Quarto prints an abstract only with its own title block, so keep these in place as LaTeX.
    bodyIn = bodyIn.replace(/\\begin\{(abstract|IEEEkeywords)\}[\s\S]*?\\end\{\1\}/g, (all) => keepRaw(all, null));
  }
  // Brace groups that scope declarations ({\centering ...}, {\small ...}) over several lines: pandoc
  // drops the braces, so the declaration would leak into the rest of the document. Keep them as LaTeX.
  bodyIn = keepScopedGroups(bodyIn, keepRaw);
  // Where the reference list goes: Quarto's ::: {#refs} ::: div (pandoc's reader would drop \bibliography).
  const bibCmds = findCommands(bodyIn, 'bibliography', ['m']);
  const bibFromBody = bibCmds.flatMap((c) => c.args[0].split(',').map((x) => x.trim()).filter(Boolean));
  if (bibCmds.length) bodyIn = cut(bodyIn, bibCmds.slice(1)).replace(/\\bibliography\s*\{[^}]*\}/, '\n\nLABTEXREFSHERE\n\n');
  // TeX logos (\LaTeX, \TeX, \LaTeXe): pandoc would flatten them to plain text.
  bodyIn = bodyIn.replace(/\\(LaTeXe|LaTeX|BibTeX|TeX)(?![A-Za-z])(\{\})?/g, (all, name) => `\\labtexlogo{${name}}`);
  // Paragraphs in the main file that use manual PDF tagging are kept verbatim too.
  bodyIn = bodyIn.split(/\n\s*\n/).map((para) => (FRAGILE.test(para) && !/\\LABTEXRAW\{/.test(para) ? keepRaw(para, null) : para)).join('\n\n');
  const taggedFiles = [...new Set(rawChunks.filter((c) => c.file).map((c) => c.file))];
  if (taggedFiles.length) warnings.push(`Kept as LaTeX because they contain manual PDF tagging: ${taggedFiles.join(', ')}.`);
  // pandoc input: the flattened document with a marker where the body starts.
  const input = text.slice(0, beginDoc) + '\\begin{document}\nLABTEXBODYSTART\n\n' + bodyIn;
  const scratch = makeScratchDir('convert');
  try {
    writeShared(path.join(scratch, 'input.tex'), Buffer.from(input, 'utf8'));
    const filter = path.join(scratch, 'tex2qmd.lua');
    writeShared(filter, fs.readFileSync(LUA_FILTER));
    const wrap = opts.wrap === 'columns' ? ['--wrap=auto', `--columns=${opts.columns}`] : opts.wrap === 'preserve' ? ['--wrap=preserve'] : ['--wrap=none'];
    // A hand-written thebibliography (no .bib file): keep \cite as LaTeX so it still resolves.
    const manualBib = /\\begin\{thebibliography\}/.test(body) && !/\\(bibliography|addbibresource)\s*\{/.test(text);
    if (manualBib) warnings.push('The bibliography is written by hand (thebibliography), so citations were kept as LaTeX \\cite commands. Move the entries to a .bib file to use Quarto citations.');
    // Acronym definitions (glossaries): used for readable HTML text next to \gls commands.
    const acronyms = {};
    for (const c of findCommands(text, 'newacronym', ['o', 'm', 'm', 'm'])) acronyms[c.args[1]] = { short: c.args[2], long: c.args[3] };
    writeShared(path.join(scratch, 'acronyms.json'), Buffer.from(JSON.stringify(acronyms)));
    const usesGlossaries = /\\(printglossary|printglossaries|printacronyms|printnoidxglossary)/.test(body);
    if (usesGlossaries) warnings.push('Glossary/acronym commands were kept as LaTeX. LabTeX builds the list of acronyms; Quarto does not run makeglossaries, so that list stays empty if you render the .qmd with Quarto.');
    const args = ['input.tex', '-f', opts.rawLatex ? 'latex+raw_tex' : 'latex', '-t', 'markdown-raw_attribute+raw_tex-smart-simple_tables-multiline_tables',
      '-s', ...wrap, '--lua-filter', 'tex2qmd.lua', '-M', `labtex-xrefs=${opts.xrefs}`, '-M', `labtex-rawcites=${manualBib}`, '-M', `labtex-keepmaketitle=${keepMaketitle}`, '-M', `labtex-acronyms=${JSON.stringify(acronyms)}`, '-o', 'output.md'];
    const r = await run(PANDOC, args, scratch, { timeoutMs: TIMEOUT_MS, clean: true });
    if (r.code !== 0 || !fs.existsSync(path.join(scratch, 'output.md'))) {
      throw new Error(r.timedOut ? 'Conversion timed out.' : `pandoc failed: ${r.output.trim().split('\n').slice(-3).join(' ')}`);
    }
    for (const line of r.output.split('\n')) if (/^\[WARNING\]/.test(line)) warnings.push(line.replace(/^\[WARNING\]\s*/, ''));
    const md = fs.readFileSync(path.join(scratch, 'output.md'), 'utf8');
    const fm = md.match(/^---\n([\s\S]*?)\n---\n?/);
    const meta = fm ? (yaml.load(fm[1]) || {}) : {};
    let content = fm ? md.slice(fm[0].length) : md;

    const stats = meta['labtex-stats'] || {};
    delete meta['labtex-stats'];
    const raw = Math.max(0, Number(stats.raw_blocks || 0) + Number(stats.raw_inlines || 0) - rawChunks.length);
    if (raw && opts.rawLatex) warnings.push(`${raw} piece(s) of LaTeX with no Markdown equivalent were kept as raw LaTeX (they appear in PDF output only).`);
    if (Array.isArray(stats.unresolved) && stats.unresolved.length) warnings.push(`References to unknown labels kept as LaTeX: ${[...new Set(stats.unresolved)].slice(0, 8).join(', ')}`);

    // Assemble YAML in a readable order.
    const out = {};
    const htmlTitle = {};
    for (const k of ['title', 'subtitle', 'author', 'date', 'abstract', 'keywords']) {
      if (meta[k] == null) continue;
      // Custom LaTeX title page: keep Quarto from printing a second title in the PDF.
      if (customTitle && k !== 'abstract' && k !== 'keywords') htmlTitle[k] = meta[k]; else out[k] = meta[k];
      delete meta[k];
    }
    if (customTitle && Object.keys(htmlTitle).length) warnings.push(keepMaketitle
      ? 'The author block uses LaTeX formatting, so \\title, \\author and \\maketitle were kept as LaTeX; the title and author are set for HTML output only.'
      : 'The document has its own title page, so it was kept as LaTeX; the title and author are set for HTML output only.');
    // Keep the date as written: Quarto would otherwise reformat it.
    if (/\\today/.test(preamble) && !meta.date) out.date = 'today';
    const dateHolder = out.date != null ? out : htmlTitle;
    if (typeof dateHolder.date === 'string') {
      const d = dateHolder.date.trim();
      if (/^[A-Za-z]+\s+\d{4}$/.test(d)) dateHolder['date-format'] = 'MMMM YYYY';
      else if (/^[A-Za-z]+\s+\d{1,2},\s*\d{4}$/.test(d)) dateHolder['date-format'] = 'MMMM D, YYYY';
      else if (/^\d{1,2}\s+[A-Za-z]+\s+\d{4}$/.test(d)) dateHolder['date-format'] = 'D MMMM YYYY';
    }
    // Quarto's `lang` loads babel in the PDF. Only do that if the original used babel/polyglossia;
    // otherwise (language only declared in \DocumentMetadata) set it for HTML output only.
    const langForPdf = info.top.babel || /\\usepackage(\[[^\]]*\])?\{polyglossia\}/.test(preamble);
    if (info.top.lang && langForPdf) out.lang = info.top.lang;
    if (info.top.lang && !langForPdf) htmlTitle.lang = info.top.lang;
    let bib = meta.bibliography ? [].concat(meta.bibliography) : [];
    bib.push(...bibFromBody);
    for (const c of findCommands(text, 'addbibresource', ['o', 'm'])) bib.push(c.args[1]);
    bib = [...new Set(bib.map((b) => (/\.bib$/i.test(b) ? b : b + '.bib')))];
    if (bib.length) out.bibliography = bib.length === 1 ? bib[0] : bib;
    for (const b of bib) {
      const p = joinRel(dir, b);
      if (!files.has(p)) {
        if (b === 'lab.bib' && ctx.labBib) { outFiles.set(p, Buffer.from(ctx.labBib, 'utf8')); warnings.push('Added a copy of the shared lab library as lab.bib (Quarto needs the file next to the document).'); }
        else warnings.push(`Bibliography “${b}” is not in the project.`);
      }
    }
    if (meta.toc) htmlTitle.toc = true; // PDF keeps \tableofcontents in place
    const numbered = /\\(section|chapter)\s*\{/.test(body);
    if (numbered) out['number-sections'] = true;
    if (/\\chapter\s*[{*]/.test(body)) out['top-level-division'] = 'chapter';
    if (info.top.linestretch) out.linestretch = info.top.linestretch;
    for (const [k, v] of Object.entries(meta)) if (!(k in out) && !['bibliography', 'toc', 'labtex-xrefs'].includes(k)) out[k] = v;

    if (!info.cite.style) { const bs = findCommands(text, 'bibliographystyle', ['m'])[0]; if (bs) info.cite.style = bs.args[0]; }
    const pdf = opts.preamble ? { ...info.pdf } : {};
    // fontspec/unicode-math need XeLaTeX or LuaLaTeX whatever the project setting says.
    const inferred = engineHint.lua ? 'lualatex' : engineHint.unicode ? 'xelatex' : 'pdflatex';
    const engine = (engineHint.lua || engineHint.unicode) && (!ctx.engine || ctx.engine === 'pdflatex') ? inferred : (ctx.engine || inferred);
    pdf['pdf-engine'] = engine;
    const method = opts.citeMethod === 'auto' ? info.cite.method : opts.citeMethod === 'citeproc' ? null : opts.citeMethod;
    if (bib.length && method) {
      pdf['cite-method'] = method;
      if (info.cite.style) pdf['biblio-style'] = info.cite.style;
      if (method === 'natbib' && info.cite.natbibOptions) pdf.natbiboptions = info.cite.natbibOptions;
      if (method === 'biblatex' && info.cite.biblatexOptions.length) pdf.biblatexoptions = info.cite.biblatexOptions;
    }
    if (opts.preamble && info.header) pdf['include-in-header'] = [{ text: info.header + '\n' }];
    // Quarto (and pandoc) put space between paragraphs unless told otherwise; LaTeX indents them.
    if (opts.preamble && !/\\usepackage(\[[^\]]*\])?\{[^}]*\bparskip\b/.test(preamble) && !/\\setlength\s*\{?\\parskip/.test(preamble) && !/^scr/.test(cls.name)) pdf.indent = true;
    // Anything before \documentclass (usually \DocumentMetadata for PDF tagging/standards) goes into
    // Quarto's `document-metadata.latex` template partial, which is emitted before \documentclass.
    const beforeCode = beforeClass.split('\n').map((l) => { const c = commentStart(l); return c === -1 ? l : l.slice(0, c); }).join('\n').trim();
    const partials = [];
    // Load babel exactly like the original (Quarto would add its own options, e.g. bidi=basic).
    if (opts.preamble && info.top.babelLine) {
      outFiles.set(joinRel(dir, 'quarto-partials/babel-lang.tex'), Buffer.from(info.top.babelLine.replace(/\$/g, '$$$$') + '\n', 'utf8'));
      partials.push('quarto-partials/babel-lang.tex');
    }
    if (opts.preamble && beforeCode) {
      const partial = joinRel(dir, 'quarto-partials/document-metadata.latex');
      outFiles.set(partial, Buffer.from(beforeCode.replace(/\$/g, '$$$$') + '\n', 'utf8'));
      partials.push('quarto-partials/document-metadata.latex');
      if (/\\DocumentMetadata/.test(beforeCode)) warnings.push('\\DocumentMetadata (PDF tagging/accessibility settings) was preserved in quarto-partials/document-metadata.latex.');
    }
    // Fonts: with pdfLaTeX Quarto always loads Latin Modern and T1, replacing the class's own font
    // (e.g. Times in IEEEtran). Load only what the original loaded.
    const fontLines = info.top.fontLines || [];
    const usesUnicodeMath = /\\usepackage(\[[^\]]*\])?\{[^}]*\bunicode-math\b/.test(preamble);
    if (opts.preamble && !fontLines.some((l) => /lmodern/.test(l))) {
      const fontsPartial = [
        '% Fonts as in the original document (Quarto would otherwise load lmodern and T1 encoding)',
        '\\usepackage{iftex}',
        '\\ifPDFTeX',
        ...fontLines.map((l) => '  ' + l),
        // T1 + Computer Modern needs scalable fonts (Quarto enables microtype font expansion):
        // Latin Modern is the scalable version of the same design.
        ...(fontLines.some((l) => /\{fontenc\}/.test(l) && /T1/.test(l)) ? ['  \\usepackage{lmodern}'] : []),
        '\\else',
        usesUnicodeMath ? '  \\usepackage{unicode-math}' : '  \\usepackage{fontspec}',
        '  \\defaultfontfeatures{Scale=MatchLowercase}',
        '  \\defaultfontfeatures[\\rmfamily]{Ligatures=TeX,Scale=1}',
        '\\fi',
      ].join('\n');
      outFiles.set(joinRel(dir, 'quarto-partials/fonts.latex'), Buffer.from(fontsPartial.replace(/\$/g, '$$$$') + '\n', 'utf8'));
      partials.push('quarto-partials/fonts.latex');
    }
    if (partials.length) pdf['template-partials'] = partials;

    // Option values with LaTeX syntax ({...}, \cmd): Quarto/pandoc read YAML values as Markdown and
    // would escape them, so mark them as raw LaTeX.
    const RAW_OPTS = ['geometry', 'classoption', 'hyperrefoptions', 'natbiboptions', 'biblatexoptions', 'microtypeoptions', 'fontfamilyoptions', 'linestretch'];
    const rawify = (v) => (typeof v === 'string' && /[{}\\%#&_$^~]/.test(v) ? '`' + v + '`{=latex}' : v);
    for (const k of RAW_OPTS) if (pdf[k] != null) pdf[k] = Array.isArray(pdf[k]) ? pdf[k].map(rawify) : rawify(pdf[k]);
    out.format = { pdf };
    if (opts.htmlFormat) out.format.html = { ...htmlTitle, toc: !!htmlTitle.toc, 'number-sections': !!out['number-sections'] };

    // Placeholders may be nested (a kept file that contains a kept table): expand until none are left.
    for (let pass = 0; pass < 5 && /\\LABTEXRAW\{\d+\}/.test(content); pass++) {
      content = content.replace(/^[ \t]*\\LABTEXRAW\{(\d+)\}[ \t]*$/gm, (all, n) => '```{=latex}\n' + rawChunks[Number(n)].content.trim() + '\n```');
      content = content.replace(/\\LABTEXRAW\{(\d+)\}/g, (all, n) => rawChunks[Number(n)].content.trim());
    }
    content = content.replace(/\\labtexlogo\{(\w+)\}/g, (all, n) => `\\${n}{}`); // inside raw LaTeX blocks
    // Reference list position (only worth marking when something follows it, e.g. appendices).
    content = content.replace(/^LABTEXREFSHERE[ \t]*$/m, (all, off) => (/\S/.test(content.slice(content.indexOf('LABTEXREFSHERE') + 14)) ? '::: {#refs}\n:::' : ''));
    // Figures: resolve \graphicspath, optional conversion.
    const fig = await processFigures(content, 'md', dir, info.graphicspath, opts.figureFormat, false, files, outFiles, opts, warnings, scratch);
    content = fig.text;
    if (fig.converted) warnings.push(`${fig.converted} figure(s) converted to ${opts.figureFormat.toUpperCase()} at ${opts.dpi} dpi.`);
    if (opts.htmlFormat && opts.figureFormat === 'keep' && /!\[[^\]]*\]\([^)]*\.(pdf|eps)\)/i.test(content)) {
      warnings.push('Some figures are PDF/EPS: fine for PDF output, but browsers can’t show them in HTML. Choose PNG or JPEG under Figures to convert them.');
    }

    const yamlText = yaml.dump(out, { lineWidth: -1, noRefs: true, quotingType: '"' });
    const result = `---\n${yamlText}---\n\n${content.replace(/^\n+/, '')}`;
    return { text: result, warnings, stats: { crossRefs: Number(stats.xrefs || 0), rawLatex: raw } };
  } finally {
    fs.rmSync(scratch, { recursive: true, force: true });
  }
}

// ---------------- .qmd -> .tex ----------------

// Quarto project/extension files. They only matter to the Quarto program, which LabTeX doesn't run.
const UNSAFE_QUARTO = /(^|\/)(_quarto[^/]*\.ya?ml|_metadata\.ya?ml|_extensions|\.quarto)(\/|$)/;
// Front-matter keys that only Quarto (or code execution) understands; dropped for LaTeX output.
const QUARTO_ONLY = ['filters', 'shortcodes', 'metadata-files', 'metadata-file', 'jupyter', 'knitr', 'engine', 'execute', 'execute-dir',
  'resource-path', 'editor', 'project', 'crossref', 'format', 'keep-tex', 'keep-md', 'pdf-engine', 'pdf-engine-opt', 'pdf-engine-opts',
  'template-partials', 'include-in-header', 'include-before-body', 'include-after-body', 'cite-method', 'number-sections', 'number-depth',
  'toc', 'toc-depth', 'toc-title', 'top-level-division', 'date-format', 'fig-pos', 'fig-width', 'fig-height', 'fig-format', 'fig-dpi',
  'fig-cap-location', 'tbl-cap-location', 'reference-location', 'citation-location', 'code-fold', 'code-tools', 'echo', 'warning', 'error',
  'output', 'freeze', 'cache', 'self-contained', 'embed-resources', 'theme', 'css', 'html-math-method', 'jupyter-options', 'labtex-stats'];

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
/** Quarto formats ISO dates (2026-11-22) for display; do the same, honouring a simple date-format. */
function formatDate(d, fmt) {
  const m = String(d).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const [y, mo, da] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const f = typeof fmt === 'string' && fmt !== 'long' && fmt !== 'full' ? fmt : 'MMMM D, YYYY';
  if (fmt === 'iso') return d;
  return f.replace(/YYYY|MMMM|MMM|MM|M|DD|D/g, (t) => ({
    YYYY: y, MMMM: MONTHS[mo - 1], MMM: MONTHS[mo - 1].slice(0, 3), MM: String(mo).padStart(2, '0'), M: mo, DD: String(da).padStart(2, '0'), D: da,
  }[t]));
}

/** The text of a project file referenced from a .qmd (include, include-in-header file:, partial). */
function projectText(files, dir, rel, opts) {
  const p = safePath(joinRel(dir, String(rel)));
  return p && files.has(p) ? decodeText(files.get(p), opts.inputEncoding).text : null;
}

/** {{< include >}}, {{< pagebreak >}}, {{< meta >}}, other shortcodes; code cells (never executed). */
function preprocessQmd(body, files, dir, meta, opts, warnings, depth = 0) {
  const unknown = new Set();
  let codeCells = 0, hiddenCells = 0, diagrams = 0;
  let out = body.replace(/\{\{<\s*include\s+([^\s>]+)\s*>\}\}/g, (all, rel) => {
    const t = depth < 10 ? projectText(files, dir, rel.replace(/^["']|["']$/g, ''), opts) : null;
    if (t == null) { warnings.push(`{{< include ${rel} >}}: file not found in the project.`); return ''; }
    return preprocessQmd(t.replace(/^---\s*\n[\s\S]*?\n---\s*\n/, ''), files, dir, meta, opts, warnings, depth + 1);
  });
  // Code cells: ```{python} with "#| option: value" lines. Shown as code listings, never run.
  out = out.replace(/^(`{3,}|~{3,})[ \t]*\{([A-Za-z][\w-]*)([^}\n]*)\}[ \t]*\n([\s\S]*?)^\1[ \t]*$/gm, (all, fence, lang, rest, code) => {
    const optLines = [], codeLines = [];
    for (const l of code.split('\n')) (/^\s*#\|/.test(l) && !codeLines.some((x) => x.trim()) ? optLines : codeLines).push(l);
    let o = {};
    try { o = yaml.load(optLines.map((l) => l.replace(/^\s*#\|\s?/, '')).join('\n')) || {}; } catch {}
    if (/^(mermaid|dot)$/i.test(lang)) diagrams++;
    else codeCells++;
    if (o.echo === false || o.include === false) { hiddenCells++; return ''; }
    const attrs = [];
    const label = o.label || (rest.match(/#([\w-]+)/) || [])[1];
    if (label && /^lst-/.test(label)) attrs.push(`#${label}`);
    attrs.push(`.${lang.toLowerCase()}`);
    if (o['lst-cap']) attrs.push(`lst-cap="${String(o['lst-cap']).replace(/"/g, '\\"')}"`);
    return `${fence}{${attrs.join(' ')}}\n${codeLines.join('\n').replace(/\n+$/, '')}\n${fence}`;
  });
  // Inline code cells `{python} 1+1`
  out = out.replace(/`\{(python|r|julia|ojs)\}\s+([^`]+)`/g, (all, l, c) => { codeCells++; return '`' + c + '`'; });
  out = out.replace(/\{\{<\s*(pagebreak)\s*>\}\}/g, '\n```{=latex}\n\\newpage\n```\n');
  out = out.replace(/\{\{<\s*meta\s+([\w.-]+)\s*>\}\}/g, (all, key) => {
    const v = key.split('.').reduce((o, k) => (o && typeof o === 'object' ? o[k] : undefined), meta);
    return v == null ? '' : typeof v === 'object' ? '' : String(v);
  });
  out = out.replace(/\{\{<\s*kbd\s+([^>]*?)\s*>\}\}/g, (all, k) => '`' + k.replace(/\s+\w+=\S+/g, '') + '`');
  out = out.replace(/\{\{<\s*([\w-]+)[^>]*>\}\}/g, (all, name) => { unknown.add(name); return ''; });
  if (depth === 0) {
    if (codeCells) warnings.push(`${codeCells} code cell(s) were converted to code listings. They were not run, so plots, tables and printed output they would produce aren't included.`);
    if (hiddenCells) warnings.push(`${hiddenCells} code cell(s) with echo: false or include: false were left out (their output can't be produced without running them).`);
    if (diagrams) warnings.push(`${diagrams} Mermaid/Graphviz diagram(s) were kept as code; export them as images to include them in the PDF.`);
    if (unknown.size) warnings.push(`Shortcodes LaTeX output can't use were removed: ${[...unknown].map((n) => `{{< ${n} >}}`).join(', ')}.`);
  }
  return out;
}

async function qmdToTex(files, src, opts, ctx, outFiles) {
  const warnings = [];
  const dir = posixDir(src);
  const { text } = decodeText(files.get(src), opts.inputEncoding);
  const fm = text.match(/^---[ \t]*\r?\n([\s\S]*?)\r?\n(?:---|\.\.\.)[ \t]*(?:\r?\n|$)/);
  let meta = {};
  if (fm) { try { meta = yaml.load(fm[1]) || {}; } catch (e) { throw new Error(`The YAML front matter at the top of the file is invalid: ${e.message.split('\n')[0]}`); } }
  if (typeof meta !== 'object' || Array.isArray(meta)) meta = {};
  const bodyText = fm ? text.slice(fm[0].length) : text;

  // Settings: top level, overridden by format: pdf: (or latex:)
  let pdf = {};
  if (meta.format && typeof meta.format === 'object') {
    for (const key of ['latex', 'pdf']) if (meta.format[key] && typeof meta.format[key] === 'object') pdf = { ...pdf, ...meta.format[key] };
    const other = Object.keys(meta.format).filter((k) => !['pdf', 'latex', 'html'].includes(k));
    if (other.length) warnings.push(`Format(s) ${other.join(', ')} were ignored; only the pdf settings apply to LaTeX output.`);
  }
  const all = { ...meta, ...pdf };
  const ignoredCode = ['filters', 'shortcodes', 'jupyter', 'knitr', 'engine', 'execute'].filter((k) => k in all);
  if (ignoredCode.length) warnings.push(`Ignored Quarto-only settings: ${ignoredCode.join(', ')}.`);

  const args = ['-f', 'markdown+raw_tex+tex_math_dollars+raw_attribute-auto_identifiers+gfm_auto_identifiers', '-t', 'latex', '-s', '--lua-filter', 'qmd2tex.lua'];
  if (all['number-sections']) args.push('-N');
  if (all['number-depth']) args.push('-V', `secnumdepth=${Number(all['number-depth']) || 3}`);
  if (all.toc) args.push('--toc');
  if (all['toc-depth']) args.push(`--toc-depth=${Number(all['toc-depth']) || 3}`);
  if (all['toc-title']) args.push('-V', `toc-title=${String(all['toc-title'])}`);
  const tld = all['top-level-division'];
  if (['chapter', 'part', 'section'].includes(tld)) args.push(`--top-level-division=${tld}`);
  else if (/^(book|report|memoir|scrbook|scrreprt)$/.test(String(all.documentclass || ''))) args.push('--top-level-division=chapter');

  // Citations
  const hasBib = all.bibliography != null;
  const method = !hasBib ? null : opts.citeMethod === 'auto' ? (all['cite-method'] || 'natbib') : opts.citeMethod;
  if (method === 'natbib') args.push('--natbib');
  else if (method === 'biblatex') args.push('--biblatex');
  else if (method === 'citeproc') args.push('--citeproc');
  if (hasBib) for (const b of [].concat(all.bibliography)) {
    if (projectText(files, dir, b, opts) == null) {
      if (String(b) === 'lab.bib' && ctx.labBib) continue;
      warnings.push(`Bibliography “${b}” is not in the project.`);
    }
  }

  // Header / before / after includes, and the template partials our LaTeX -> Quarto conversion writes.
  const header = [], before = [], after = [];
  let prefix = '';
  const includes = (v, list, what) => {
    for (const item of [].concat(v || [])) {
      if (typeof item === 'string') {
        // A bare string is a file name in Quarto; fall back to treating it as LaTeX text.
        const t = /\.(tex|latex|sty)$/i.test(item) ? projectText(files, dir, item, opts) : null;
        list.push(t ?? item);
      } else if (item && typeof item === 'object') {
        if (item.text != null) list.push(String(item.text));
        else if (item.file != null) { const t = projectText(files, dir, item.file, opts); if (t == null) warnings.push(`${what}: file “${item.file}” not found.`); else list.push(t); }
      }
    }
  };
  includes(all['include-in-header'], header, 'include-in-header');
  includes(all['include-before-body'], before, 'include-before-body');
  includes(all['include-after-body'], after, 'include-after-body');
  let customFonts = false, babelLoaded = false;
  for (const part of [].concat(all['template-partials'] || [])) {
    const t = projectText(files, dir, part, opts);
    const base = path.posix.basename(String(part));
    if (t == null) { warnings.push(`Template partial “${part}” not found.`); continue; }
    if (base === 'document-metadata.latex') prefix = t.trim() + '\n';
    else if (base === 'fonts.latex' || base === 'babel-lang.tex') { header.unshift(t); if (base === 'fonts.latex') customFonts = true; if (base === 'babel-lang.tex') babelLoaded = true; }
    else warnings.push(`Template partial “${part}” is specific to Quarto's own template and was skipped.`);
  }
  // Quarto's template always loads graphicx, the table packages and xcolor; pandoc's only does when
  // Markdown images/tables/colours appear. Raw LaTeX (\includegraphics, \resizebox, \color...) needs them too.
  // (If the header loads graphicx with options itself, let it; loading it twice would clash.)
  if (!/\\usepackage\[[^\]]*\]\{graphicx\}/.test(header.join('\n'))) args.push('-V', 'graphics=true');
  args.push('-V', 'tables=true');
  const everything = bodyText + '\n' + header.join('\n') + before.join('\n') + after.join('\n');
  if (/\\(textcolor|color|definecolor|colorbox|rowcolor|cellcolor|colorlet)\b/.test(everything) && !/\\usepackage(\[[^\]]*\])?\{[^}]*\bxcolor\b/.test(header.join('\n'))) header.unshift('\\usepackage{xcolor}');
  if (header.length) args.push('-H', 'header.tex');
  // The document manages \frontmatter/\mainmatter itself: don't let the template add its own.
  if (/\\(frontmatter|mainmatter)\b/.test(bodyText)) args.push('-V', 'book-class=');
  if (before.length) args.push('-B', 'before.tex');
  if (after.length) args.push('-A', 'after.tex');
  // Fonts as in the original LaTeX: stop pandoc's template from loading Latin Modern (it loads
  // \usepackage{<fontfamily>} instead, and iftex is harmless).
  if (customFonts && !all.fontfamily) args.push('-V', 'fontfamily=iftex');

  // Settings whose values are LaTeX (option lists, lengths, class names) go to the template as
  // variables, unescaped; as metadata pandoc would escape braces and backslashes.
  const VARS = ['documentclass', 'classoption', 'geometry', 'papersize', 'fontsize', 'linestretch', 'fontfamily', 'fontfamilyoptions',
    'mainfontoptions', 'sansfontoptions', 'monofontoptions', 'mathfontoptions', 'hyperrefoptions', 'natbiboptions', 'biblatexoptions', 'biblio-style',
    'linkcolor', 'filecolor', 'citecolor', 'urlcolor', 'toccolor', 'indent', 'block-headings', 'microtypeoptions', 'babel-otherlangs', 'pagestyle', 'secnumdepth'];
  const out = {};
  for (const [k, v] of Object.entries(all)) {
    if (QUARTO_ONLY.includes(k)) continue;
    if (VARS.includes(k)) {
      if (k === 'biblio-style' && !method) continue;
      const list = Array.isArray(v) ? v : k === 'classoption' && typeof v === 'string' ? v.split(',') : [v];
      const unraw = (x) => String(x).trim().replace(/^`([\s\S]*)`\{=(?:latex|tex)\}$/, '$1');
      for (const x of list) if (x != null && typeof x !== 'object') args.push('-V', `${k}=${unraw(x)}`);
      continue;
    }
    out[k] = v;
  }
  // babel is already loaded exactly as in the original; `lang` would make the template load it again.
  if (babelLoaded) delete out.lang;
  if (out.date != null && !/^(today|now|last-modified)$/.test(String(out.date))) {
    const d = out.date instanceof Date ? out.date.toISOString().slice(0, 10) : String(out.date);
    out.date = formatDate(d, all['date-format']) || d;
  }

  const body = preprocessQmd(bodyText, files, dir, meta, opts, warnings);
  const input = `---\n${yaml.dump(out, { lineWidth: -1, noRefs: true })}---\n\n${body}`;

  const scratch = makeScratchDir('convert');
  try {
    writeShared(path.join(scratch, 'input.md'), Buffer.from(input, 'utf8'));
    writeShared(path.join(scratch, 'qmd2tex.lua'), fs.readFileSync(QMD_FILTER));
    if (header.length) writeShared(path.join(scratch, 'header.tex'), Buffer.from(header.join('\n') + '\n', 'utf8'));
    if (before.length) writeShared(path.join(scratch, 'before.tex'), Buffer.from(before.join('\n') + '\n', 'utf8'));
    if (after.length) writeShared(path.join(scratch, 'after.tex'), Buffer.from(after.join('\n') + '\n', 'utf8'));
    if (method === 'citeproc') {
      for (const b of [].concat(all.bibliography)) {
        const t = projectText(files, dir, b, opts) ?? (String(b) === 'lab.bib' ? ctx.labBib : null);
        if (t != null) { const dest = path.join(scratch, safePath(String(b)) || 'refs.bib'); mkdirShared(path.dirname(dest)); writeShared(dest, Buffer.from(t, 'utf8')); }
      }
      if (all.csl) { const t = projectText(files, dir, all.csl, opts); if (t) writeShared(path.join(scratch, safePath(String(all.csl)) || 'style.csl'), Buffer.from(t, 'utf8')); }
    }
    const r = await run(PANDOC, [...args, 'input.md', '-o', 'output.tex'], scratch, { timeoutMs: TIMEOUT_MS, clean: true });
    if (r.code !== 0 || !fs.existsSync(path.join(scratch, 'output.tex'))) {
      if (r.code === -1) throw new Error('pandoc isn\'t installed on the server.');
      const msg = r.output.split('\n').filter((l) => l.trim() && !/^LABTEX-STATS/.test(l)).slice(-3).join(' ').trim();
      throw new Error(r.timedOut ? 'Conversion timed out.' : `pandoc couldn't convert the file: ${msg || 'unknown error'}`);
    }
    for (const line of r.output.split('\n')) {
      if (/^\[WARNING\]/.test(line)) warnings.push(line.replace(/^\[WARNING\]\s*/, ''));
      const st = line.match(/^LABTEX-STATS (\d+) (\d+) (\d+) ?(.*)$/);
      if (st) {
        const unresolved = [...new Set(st[4].split(',').filter(Boolean))];
        if (unresolved.length) warnings.push(`Cross-references to labels that don't exist: ${unresolved.slice(0, 8).map((x) => '@' + x).join(', ')}. They will show as ?? in the PDF.`);
        if (Number(st[3])) warnings.push(`${st[3]} figure(s) with several panels were converted to LaTeX subfigures; check their layout.`);
      }
    }
    let tex = prefix + fs.readFileSync(path.join(scratch, 'output.tex'), 'utf8');
    // Packages for callout boxes and subfigures.
    const needs = [];
    if (/\\begin\{tcolorbox\}/.test(tex) && !/\\usepackage(\[[^\]]*\])?\{tcolorbox\}/.test(tex)) needs.push('\\usepackage{tcolorbox}');
    if (/\\begin\{codelisting\}/.test(tex)) needs.push('\\usepackage{float}', '\\floatstyle{plaintop}\\newfloat{codelisting}{htbp}{lol}\\floatname{codelisting}{Listing}');
    if (/\\begin\{subfigure\}/.test(tex) && !/\\usepackage(\[[^\]]*\])?\{(subcaption|subfig)\}/.test(tex)) needs.push('\\usepackage{subcaption}');
    if (needs.length) tex = tex.replace(/\n\\begin\{document\}/, `\n${needs.join('\n')}\n\\begin{document}`);
    // ::: {#refs} ::: marks where the reference list goes: move the template's \bibliography /
    // \printbibliography (always written at the end) there.
    if (/LABTEXREFS/.test(tex)) {
      const endBib = tex.match(/\n[ \t]*((?:\\bibliography\{[^}]*\}|\\printbibliography(?:\[[^\]]*\])?)[^\n]*)\n(?=[\s\S]*\\end\{document\}\s*$)(?![\s\S]*\\(bibliography|printbibliography)\b)/);
      if (endBib) tex = tex.replace(endBib[0], '\n').replace(/\\LABTEXREFS\b\s*/, endBib[1] + '\n');
      else tex = tex.replace(/\\LABTEXREFS\b\s*/, '');
    }
    // BibTeX wants \bibliography{refs}, without the .bib extension.
    tex = tex.replace(/\\bibliography\{([^}]*)\}/g, (all, list) => `\\bibliography{${list.split(',').map((x) => x.trim().replace(/\.bib$/i, '')).join(',')}}`);
    if (/\\begin\{thebibliography\}/.test(tex)) {
      tex = tex.replace(/\\usepackage(?:\[([^\]]*)\])?\{natbib\}/, (all, o) => (o && /numbers/.test(o) ? all : `\\usepackage[${o ? o + ',' : ''}numbers]{natbib}`));
    }
    const fig = await processFigures(tex, 'tex', dir, [], 'keep', true, files, outFiles, opts, warnings, scratch);
    tex = fig.text;
    if (fig.converted) warnings.push(`${fig.converted} SVG figure(s) converted to PDF (LaTeX can't include SVG).`);
    if (method === 'citeproc') warnings.push('Citations were written out as plain text (citeproc), so the .tex has no \\cite commands.');
    const engine = /^(xelatex|lualatex|pdflatex)$/.test(String(all['pdf-engine'] || '')) ? all['pdf-engine']
      : (all.mainfont || all.sansfont || all.monofont || all.mathfont) ? 'xelatex' : null;
    if (engine && engine !== 'pdflatex' && (!ctx.engine || ctx.engine === 'pdflatex')) warnings.push(`This document needs ${engine === 'xelatex' ? 'XeLaTeX' : 'LuaLaTeX'} (it sets fonts or asks for it). Choose it under Settings → Compiler.`);
    return { text: tex, warnings, stats: {}, engine };
  } finally {
    fs.rmSync(scratch, { recursive: true, force: true });
  }
}

function listFiles(root, rel = '') {
  const out = [];
  for (const e of fs.readdirSync(path.join(root, rel), { withFileTypes: true })) {
    const p = rel ? `${rel}/${e.name}` : e.name;
    if (e.isDirectory()) out.push(...listFiles(root, p)); else out.push(p);
  }
  return out;
}

// ---------------- batch entry point ----------------

/**
 * Convert documents.
 * @param files    Map<relativePath, Buffer>  all files of the project/upload (inputs + assets)
 * @param targets  relative paths of the documents to convert (.tex, .qmd, .md)
 * @param options  see DEFAULT_OPTIONS
 * @param ctx      { engine?: 'pdflatex'|'xelatex'|'lualatex', labBib?: string }
 * @returns { results: [{source, output, direction, ok, error?, warnings, stats}], outFiles: Map<path, Buffer> }
 */
let pandocCheck = null;
/** pandoc must be installed and at least version 3 (figures and the Lua API the filters use). */
function checkPandoc() {
  pandocCheck ||= run(PANDOC, ['--version'], process.cwd(), { timeoutMs: 15000, clean: true }).then((r) => {
    if (r.code !== 0) { pandocCheck = null; return 'pandoc isn\'t installed on the server.'; }
    const v = (r.output.match(/pandoc(?:\.exe)? (\d+)\.(\d+)/) || []).slice(1).map(Number);
    return v.length && v[0] < 3 ? `pandoc ${v.join('.')} is too old; LabTeX needs pandoc 3 or newer.` : null;
  });
  return pandocCheck;
}

export async function convertDocuments(files, targets, options, ctx = {}) {
  const opts = normalizeOptions(options);
  const problem = await checkPandoc();
  if (problem) return { results: targets.map((t) => ({ source: t, direction: directionFor(t), ok: false, error: problem, warnings: [] })), outFiles: new Map(), options: opts };
  const outFiles = new Map();
  const results = [];
  for (const src of targets) {
    const direction = directionFor(src);
    if (!direction || !files.has(src)) { results.push({ source: src, ok: false, error: 'Only .tex and .qmd files can be converted.', warnings: [] }); continue; }
    await acquireSlot();
    try {
      const res = direction === 'tex2qmd' ? await texToQmd(files, src, opts, ctx, outFiles) : await qmdToTex(files, src, opts, ctx, outFiles);
      // A .qmd must not share its name with the .tex it came from: rendering it with Quarto writes an
      // intermediate <name>.tex that would overwrite the original LaTeX source.
      let output = direction === 'tex2qmd' ? src.replace(/\.tex$/i, '-quarto.qmd') : src.replace(/\.(qmd|md)$/i, '.tex');
      if (opts.onConflict === 'keep-both' && (files.has(output) || outFiles.has(output))) {
        const base = output.replace(/\.[^./]+$/, ''), ext = path.extname(output);
        let n = 1; output = `${base}-converted${ext}`;
        while (files.has(output) || outFiles.has(output)) output = `${base}-converted-${++n}${ext}`;
      }
      outFiles.set(output, Buffer.from(res.text, 'utf8'));
      results.push({ source: src, output, direction, ok: true, warnings: res.warnings, stats: res.stats });
    } catch (e) {
      results.push({ source: src, direction, ok: false, error: e.message, warnings: [] });
    } finally { releaseSlot(); }
  }
  return { results, outFiles, options: opts };
}

/** Which files in a set look like convertible main documents (for the UI). */
export function convertibleFiles(paths, getText) {
  return paths.filter((p) => directionFor(p) && !UNSAFE_QUARTO.test(p)).map((p) => {
    const t = getText(p) || '';
    return { path: p, direction: directionFor(p), isMain: /\\documentclass/.test(t) || /^---\s*\n[\s\S]*?\btitle\s*:/.test(t) };
  });
}

export { safePath };
