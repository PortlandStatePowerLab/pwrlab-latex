-- LabTeX: pandoc Lua filter used when converting Quarto (.qmd) -> LaTeX without the Quarto program.
-- Handles Quarto's own syntax on top of pandoc Markdown:
--  * cross-references  @fig-x @tbl-x @eq-x @sec-x @lst-x (+ [-@fig-x], @Fig-x, [@fig-a; @fig-b])
--  * figure divs        ::: {#fig-x} ... caption ::: (incl. simple subfigure layouts)
--  * table captions     : Caption {#tbl-x}   and   ::: {#tbl-x} table + caption :::
--  * numbered equations $$ ... $$ {#eq-x}
--  * callouts           ::: {.callout-note title="..."} -> tcolorbox
--  * conditional content .content-visible/.content-hidden when-format
--  * title metadata     author objects (name/affiliation/email), date: today
-- Reports statistics on stderr (LABTEX-STATS xrefs callouts subfigs unresolved,ids) for the converter's warnings.

local stringify = pandoc.utils.stringify
local stats = { xrefs = 0, unresolved = {}, callouts = 0, subfigs = 0 }
local known = {}        -- ids that exist in the document

local PREFIX = { fig = "Figure", tbl = "Table", eq = "Equation", sec = "Section", lst = "Listing",
  thm = "Theorem", lem = "Lemma", cor = "Corollary", prp = "Proposition", def = "Definition", exm = "Example", exr = "Exercise" }
local PLURAL = { fig = "Figures", tbl = "Tables", eq = "Equations", sec = "Sections", lst = "Listings" }

local function kind_of(id) return id:match("^(%a+)%-") end
local function raw(s) return pandoc.RawInline("latex", s) end
local function rawb(s) return pandoc.RawBlock("latex", s) end

-- ---------------------------------------------------------------------------
-- Pass 1: equations with {#eq-x}, table captions with {#tbl-x}, collect ids
-- ---------------------------------------------------------------------------

local function label_equations(inlines)
  local out = pandoc.Inlines({})
  local i = 1
  while i <= #inlines do
    local el = inlines[i]
    if el.t == "Math" and el.mathtype == "DisplayMath" then
      -- look ahead for optional Space then Str "{#eq-...}"
      local j = i + 1
      if inlines[j] and (inlines[j].t == "Space" or inlines[j].t == "SoftBreak") then j = j + 1 end
      local tag = inlines[j] and inlines[j].t == "Str" and inlines[j].text:match("^{#(eq%-[%w%-_]+)}$")
      if tag then
        known[tag] = true
        local body = el.text
        -- Already an environment (align, gather...)? Put the label inside it.
        if body:match("^%s*\\begin{(%a+%*?)}") and not body:match("^%s*\\begin{aligned}") and not body:match("^%s*\\begin{[bpvBV]?matrix}") and not body:match("^%s*\\begin{cases}") then
          out:insert(raw((body:gsub("\\end{(%a+%*?)}%s*$", "\\label{" .. tag .. "}\\end{%1}"))))
        else
          out:insert(raw("\\begin{equation}" .. body .. "\\label{" .. tag .. "}\\end{equation}"))
        end
        i = j + 1
      else
        out:insert(el); i = i + 1
      end
    else
      out:insert(el); i = i + 1
    end
  end
  return out
end

-- "Caption text {#tbl-x}" at the end of a caption -> (caption without the tag, id)
local function caption_tag(blocks, prefix)
  if not blocks or #blocks == 0 then return nil end
  local last = blocks[#blocks]
  if last.t ~= "Para" and last.t ~= "Plain" then return nil end
  local inl = last.content
  local tail = inl[#inl]
  if not tail or tail.t ~= "Str" then return nil end
  local id = tail.text:match("^{#(" .. prefix .. "%-[%w%-_]+)[^}]*}$")
  if not id then return nil end
  inl:remove(#inl)
  while #inl > 0 and (inl[#inl].t == "Space" or inl[#inl].t == "SoftBreak") do inl:remove(#inl) end
  return id
end

local function collect_ids(doc)
  doc:walk({
    Header = function(h) if h.identifier ~= "" then known[h.identifier] = true end end,
    Figure = function(f) if f.identifier ~= "" then known[f.identifier] = true end end,
    Image = function(im) if im.identifier ~= "" then known[im.identifier] = true end end,
    Table = function(t) if t.identifier ~= "" then known[t.identifier] = true end end,
    Div = function(d) if d.identifier ~= "" then known[d.identifier] = true end end,
    CodeBlock = function(c) if c.identifier ~= "" then known[c.identifier] = true end end,
  })
end

-- ---------------------------------------------------------------------------
-- Blocks
-- ---------------------------------------------------------------------------

local CALLOUT = {
  note = { "Note", "blue" }, tip = { "Tip", "green!50!black" }, warning = { "Warning", "orange" },
  important = { "Important", "red" }, caution = { "Caution", "orange!80!black" },
}

local function latex_text(inlines)
  return pandoc.write(pandoc.Pandoc({ pandoc.Plain(inlines) }), "latex"):gsub("%s+$", "")
end

local function visible_for_latex(d)
  local when = d.attributes["when-format"] or d.attributes["unless-format"]
  if not when then return true end
  local pdfish = when == "pdf" or when == "latex" or when == "beamer"
  if d.attributes["unless-format"] then pdfish = not pdfish end
  return pdfish
end

-- Images in blocks as { src, caption (Inlines), identifier }. A lone image in a paragraph is
-- already a Figure (pandoc moves its id and caption there), so read those from the Figure.
local function images_in(blocks)
  local imgs = {}
  for _, b in ipairs(blocks) do
    if b.t == "Figure" then
      local inner = {}
      pandoc.Blocks(b.content):walk({ Image = function(im) table.insert(inner, im) end })
      if #inner == 1 then
        local cap = #b.caption.long > 0 and pandoc.utils.blocks_to_inlines(b.caption.long) or inner[1].caption
        local id = b.identifier ~= "" and b.identifier or inner[1].identifier
        table.insert(imgs, { src = inner[1].src, caption = cap, identifier = id, attributes = inner[1].attributes })
      else
        for _, im in ipairs(inner) do table.insert(imgs, { src = im.src, caption = im.caption, identifier = im.identifier, attributes = im.attributes }) end
      end
    else
      pandoc.Blocks({ b }):walk({ Image = function(im) table.insert(imgs, { src = im.src, caption = im.caption, identifier = im.identifier, attributes = im.attributes }) end })
    end
  end
  return imgs
end

function Div(d)
  local c = d.classes
  -- Conditional content
  if c:includes("content-visible") then return visible_for_latex(d) and d.content or {} end
  if c:includes("content-hidden") then return visible_for_latex(d) and {} or d.content end

  -- Callouts
  for _, cls in ipairs(c) do
    local kind = cls:match("^callout%-(%a+)$")
    if kind and CALLOUT[kind] then
      stats.callouts = stats.callouts + 1
      local title = d.attributes["title"]
      local content = d.content
      -- "## Title" as the first block is also a callout title in Quarto.
      if not title and content[1] and content[1].t == "Header" then
        title = latex_text(content[1].content); content = pandoc.Blocks({ table.unpack(content, 2) })
      elseif title then
        title = latex_text(pandoc.read(title, "markdown").blocks[1] and pandoc.utils.blocks_to_inlines(pandoc.read(title, "markdown").blocks) or {})
      end
      local name, color = CALLOUT[kind][1], CALLOUT[kind][2]
      local t = title and title ~= "" and title or name
      local out = pandoc.Blocks({ rawb("\\begin{tcolorbox}[colback=" .. color .. "!5!white,colframe=" .. color .. "!75!black,title={" .. t .. "},fonttitle=\\bfseries]") })
      out:extend(content)
      out:insert(rawb("\\end{tcolorbox}"))
      return out
    end
  end

  -- Figure div: ::: {#fig-x} <images or anything> <caption paragraph> :::
  if d.identifier:match("^fig%-") then
    local content = d.content
    local caption = {}
    if #content > 1 and (content[#content].t == "Para" or content[#content].t == "Plain") and #images_in({ content[#content] }) == 0 then
      caption = content[#content].content
      content = pandoc.Blocks({ table.unpack(content, 1, #content - 1) })
    end
    local imgs = images_in(content)
    local ncol = tonumber(d.attributes["layout-ncol"] or "") or (#imgs > 1 and #imgs or 1)
    if #imgs > 1 then
      -- Subfigures: images side by side, each with its own (a)/(b) caption when it has one.
      stats.subfigs = stats.subfigs + 1
      local w = string.format("%.3f", 0.95 / math.min(ncol, #imgs))
      local parts = { "\\begin{figure}[htbp]\n\\centering" }
      for k, im in ipairs(imgs) do
        local sid = im.identifier ~= "" and ("\\label{" .. im.identifier .. "}") or ""
        local cap = #im.caption > 0 and latex_text(im.caption) or ""
        table.insert(parts, "\\begin{subfigure}[t]{" .. w .. "\\linewidth}\\centering\n\\includegraphics[width=\\linewidth]{" .. im.src .. "}\n" ..
          (cap ~= "" and ("\\caption{" .. cap .. "}") or "\\caption{}") .. sid .. "\n\\end{subfigure}" .. ((k % ncol == 0) and "\n\n" or "\\hfill"))
      end
      table.insert(parts, "\\caption{" .. latex_text(caption) .. "}\\label{" .. d.identifier .. "}\n\\end{figure}")
      return rawb(table.concat(parts, "\n"))
    end
    -- One image or other content (e.g. a raw LaTeX/TikZ drawing): a normal figure.
    if #imgs == 1 then
      local im = pandoc.Image({}, imgs[1].src, "", pandoc.Attr("", {}, imgs[1].attributes))
      return pandoc.Figure(pandoc.Plain({ im }), { pandoc.Plain(#caption > 0 and caption or imgs[1].caption) }, pandoc.Attr(d.identifier))
    end
    return pandoc.Figure(content, { pandoc.Plain(caption) }, pandoc.Attr(d.identifier))
  end

  -- ::: {#refs} ::: — where the reference list goes; the converter moves \bibliography here.
  if d.identifier == "refs" then return rawb("\\LABTEXREFS") end

  -- Table div: ::: {#tbl-x} <table> <caption> :::   (or caption first)
  if d.identifier:match("^tbl%-") then
    local tbl, caption
    for _, b in ipairs(d.content) do
      if b.t == "Table" then tbl = b
      elseif (b.t == "Para" or b.t == "Plain") and not caption then caption = b.content end
    end
    if tbl then
      tbl.identifier = d.identifier
      if caption and #tbl.caption.long == 0 then tbl.caption.long = { pandoc.Plain(caption) } end
      return tbl
    end
  end
  return nil
end

function Span(sp)
  local c = sp.classes
  if c:includes("content-visible") then return visible_for_latex(sp) and sp.content or {} end
  if c:includes("content-hidden") then return visible_for_latex(sp) and {} or sp.content end
end

function Table(t)
  local id = caption_tag(t.caption.long, "tbl")
  if id then t.identifier = id; known[id] = true; return t end
end

function Figure(f)
  -- ![Caption](img.png){#fig-x}: pandoc puts the id on the image; move it to the figure.
  if f.identifier == "" then
    local imgs = images_in(f.content)
    if #imgs == 1 and imgs[1].identifier:match("^fig%-") then
      f.identifier = imgs[1].identifier
      imgs[1].identifier = ""
      f.content = pandoc.Blocks(f.content):walk({ Image = function(im) im.identifier = ""; return im end })
      return f
    end
  end
end

function CodeBlock(cb)
  -- Code cells arrive as CodeBlocks with a {python}-style class from the JS pre-pass; options
  -- like "#| echo: false" were already applied there. Give listings with a lst- label a caption.
  if cb.identifier:match("^lst%-") then
    local cap = cb.attributes["lst-cap"] or ""
    return { rawb("\\begin{codelisting}[htbp]\n\\caption{" .. cap .. "}\\label{" .. cb.identifier .. "}"), cb, rawb("\\end{codelisting}") }
  end
end

-- ---------------------------------------------------------------------------
-- Cross-references
-- ---------------------------------------------------------------------------

function Cite(c)
  local ids, kinds, suppress, capital = {}, {}, false, false
  for _, ct in ipairs(c.citations) do
    local id = ct.id
    local k = kind_of(id)
    if not k or not PREFIX[k:lower()] then return nil end -- a real citation
    if k ~= k:lower() then capital = true; id = k:lower() .. id:sub(#k + 1) end
    if ct.mode == "SuppressAuthor" then suppress = true end
    table.insert(ids, id); table.insert(kinds, k:lower())
  end
  local out = pandoc.Inlines({})
  for n, id in ipairs(ids) do
    if not known[id] then table.insert(stats.unresolved, id) end
    stats.xrefs = stats.xrefs + 1
    -- Quarto writes "Equation 1" (and just "1" with [-@eq-x]); keep the same text.
    local ref = "\\ref{" .. id .. "}"
    if n == 1 and not suppress then
      local word = (#ids > 1 and kinds[1] == kinds[#ids] and PLURAL[kinds[1]]) or PREFIX[kinds[1]]
      out:insert(raw(word .. "~" .. ref))
    else
      if n > 1 then out:insert(pandoc.Str(n == #ids and (#ids > 2 and ", and" or " and") or ",")); out:insert(pandoc.Space()) end
      if n > 1 and kinds[n] ~= kinds[1] then out:insert(raw(PREFIX[kinds[n]] .. "~" .. ref)) else out:insert(raw(ref)) end
    end
  end
  -- citation prefix/suffix text, e.g. [see @fig-x, left panel]
  local pre, suf = c.citations[1].prefix, c.citations[#c.citations].suffix
  if #pre > 0 then local p = pandoc.Inlines(pre); p:insert(pandoc.Space()); p:extend(out); out = p end
  if #suf > 0 then out:extend(suf) end
  return out
end

-- ---------------------------------------------------------------------------
-- Metadata
-- ---------------------------------------------------------------------------

local function author_inlines(a)
  if a.t == "MetaMap" or (type(a) == "table" and a.name ~= nil and a.t == nil) then
    local name = a.name and (a.name.literal or a.name) or ""
    if type(name) == "table" and name.given then name = pandoc.Inlines({ pandoc.Str(stringify(name.given) .. " " .. stringify(name.family)) }) end
    local out = pandoc.Inlines(pandoc.utils.type(name) == "Inlines" and name or { pandoc.Str(stringify(name)) })
    local extra = {}
    for _, key in ipairs({ "affiliation", "affiliations" }) do
      local v = a[key]
      if v then
        if pandoc.utils.type(v) == "List" then for _, x in ipairs(v) do table.insert(extra, stringify(x.name or x)) end
        else table.insert(extra, stringify(v.name or v)) end
      end
    end
    if a.email then table.insert(extra, "\\texttt{" .. stringify(a.email) .. "}") end
    for _, e in ipairs(extra) do out:insert(raw("\\\\ ")); out:insert(raw("{\\small " .. e .. "}")) end
    return pandoc.MetaInlines(out)
  end
  return a
end

function Meta(m)
  if m.author then
    if pandoc.utils.type(m.author) == "List" then
      local list = {}
      for _, a in ipairs(m.author) do table.insert(list, author_inlines(a)) end
      m.author = pandoc.MetaList(list)
    else
      m.author = author_inlines(m.author)
    end
  end
  local d = m.date and stringify(m.date)
  if d == "today" or d == "now" or d == "last-modified" then m.date = pandoc.MetaInlines({ raw("\\today") }) end
  -- Packages these constructs need are added to the preamble by the converter (header-includes
  -- metadata would be overridden by -H).
  io.stderr:write("LABTEX-STATS " .. stats.xrefs .. " " .. stats.callouts .. " " .. stats.subfigs .. " " .. table.concat(stats.unresolved, ",") .. "\n")
  return m
end

return {
  { Inlines = label_equations },
  { Pandoc = function(doc) collect_ids(doc) end },
  { Table = Table },
  { Figure = Figure },
  { Div = Div, Span = Span, CodeBlock = CodeBlock },
  { Cite = Cite },
  { Meta = Meta },
}
