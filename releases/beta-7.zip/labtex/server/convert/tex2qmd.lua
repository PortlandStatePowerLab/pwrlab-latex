-- LabTeX: pandoc Lua filter used when converting LaTeX -> Quarto.
--  * drops preamble leftovers (everything before the LABTEXBODYSTART marker)
--  * turns \label/\ref into Quarto cross-references (@fig-x, @tbl-x, @eq-x, @sec-x)
--  * moves \tableofcontents into `toc: true`
--  * reports what had to be kept as raw LaTeX
-- Options arrive as metadata: labtex-xrefs (bool).

local stringify = pandoc.utils.stringify
local xrefs = true
local labelmap = {}   -- old LaTeX label -> new Quarto id
local stats = { raw_blocks = 0, raw_inlines = 0, xrefs = 0, unresolved = {} }
local want_toc = false

local function sanitize(s)
  s = s:gsub("^[%a]+[:%-_]", "") -- strip an existing fig:/tab:/eq:/sec: style prefix
  s = s:gsub("[^%w%-_]", "-"):gsub("%-%-+", "-"):gsub("^%-", ""):gsub("%-$", "")
  if s == "" then s = "x" end
  return s
end

local used = {}
local function new_id(prefix, old)
  local base = prefix .. "-" .. sanitize(old)
  local id, n = base, 2
  while used[id] do id = base .. "-" .. n; n = n + 1 end
  used[id] = true
  return id
end

local function label_in_math(text)
  return text:match("\\label%s*{([^}]+)}")
end

-- Pass 1: find labels and assign Quarto ids.
local function collect(doc)
  local function reg(prefix, old) if old and old ~= "" and not labelmap[old] then labelmap[old] = new_id(prefix, old) end end
  doc:walk({
    Header = function(h) reg("sec", h.identifier) end,
    Figure = function(f) reg("fig", f.identifier) end,
    Div = function(d)
      if #d.content == 1 and d.content[1].t == "Table" then reg("tbl", d.identifier) end
      if #d.content == 1 and d.content[1].t == "Figure" then reg("fig", d.identifier) end
    end,
    Table = function(t) reg("tbl", t.identifier) end,
    Math = function(m)
      if m.mathtype == "DisplayMath" then
        local n = 0
        for _ in m.text:gmatch("\\label%s*{") do n = n + 1 end
        if n == 1 then reg("eq", label_in_math(m.text)) end
      end
    end,
  })
end

local PREFIX_WORDS = { "Figure", "Fig.", "Figs.", "Table", "Tab.", "Section", "Sec.", "Equation", "Eq.", "Eqs.", "Chapter", "Appendix" }

-- Remove a "Figure~" style word right before a cross-reference (Quarto adds its own).
local function strip_prefix(inlines, i)
  local prev = inlines[i - 1]
  if not prev or prev.t ~= "Str" then return end
  local s = prev.text
  for _, w in ipairs(PREFIX_WORDS) do
    local pat = "^(.-)" .. w:gsub("%.", "%%.") .. "\u{a0}$"
    local before = s:match(pat)
    if before then
      if before == "" then inlines:remove(i - 1); return true end
      prev.text = before; return false
    end
  end
end

local function rewrite_refs_in_raw(text)
  return (text:gsub("\\(%a*ref)%s*{([^}]+)}", function(cmd, lbl)
    local id = labelmap[lbl]
    if id then return "\\" .. cmd .. "{" .. id .. "}" end
    return nil
  end):gsub("\\label%s*{([^}]+)}", function(lbl)
    local id = labelmap[lbl]
    if id then return "\\label{" .. id .. "}" end
    return nil
  end))
end

-- Quarto's own figure syntax: ![caption](file){#fig-id width="80%" fig-pos="t"}
-- Several images become a Quarto figure div with a layout (subfigures).
local function width_attr(img)
  local w = img.attributes.width
  if not w then return nil end
  return w:gsub("%.0%%$", "%%")
end
local function md_inlines(inl)
  local s = pandoc.write(pandoc.Pandoc({ pandoc.Plain(inl) }), "markdown", { wrap_text = "none" })
  return (s:gsub("%s+$", ""))
end
local function image_md(img, caption, id, extra)
  local attrs = {}
  if id and id ~= "" then attrs[#attrs + 1] = "#" .. id end
  local w = width_attr(img)
  if w then attrs[#attrs + 1] = 'width="' .. w .. '"' end
  if extra then for _, a in ipairs(extra) do attrs[#attrs + 1] = a end end
  local alt = img.attributes.alt or ""
  if alt ~= "" then attrs[#attrs + 1] = 'fig-alt="' .. alt:gsub('"', '\\"') .. '"' end
  local a = #attrs > 0 and ("{" .. table.concat(attrs, " ") .. "}") or ""
  return "![" .. caption .. "](" .. img.src .. ")" .. a
end
function figure_to_quarto(f)
  local images = {}
  f:walk({ Image = function(img) images[#images + 1] = img end })
  if #images == 0 then return nil end
  local cap = md_inlines(pandoc.utils.blocks_to_inlines(f.caption.long or {}))
  local extra = {}
  local pos = f.attributes["latex-placement"]
  if pos and pos ~= "" then extra[#extra + 1] = 'fig-pos="' .. pos .. '"' end
  if #images == 1 then
    return pandoc.RawBlock("markdown", image_md(images[1], cap, f.identifier, extra))
  end
  local parts = {}
  local id = f.identifier ~= "" and ("#" .. f.identifier .. " ") or ""
  parts[#parts + 1] = "::: {" .. id .. "layout-ncol=" .. math.min(#images, 3) .. "}"
  for _, img in ipairs(images) do parts[#parts + 1] = "\n" .. image_md(img, md_inlines(img.caption or {}), nil, nil) end
  parts[#parts + 1] = "\n" .. cap .. "\n:::"
  return pandoc.RawBlock("markdown", table.concat(parts, "\n"))
end

local rawcites = false
local keep_maketitle = false
local acronyms = {}  -- key -> { short=..., long=... } from \newacronym, for the HTML fallback text

-- pandoc reads glossaries commands (\gls, \acrfull, ...) as Spans; turn them back into the LaTeX
-- command (glossaries only exist in LaTeX) plus readable text for HTML output.
local GLS_CMD = {
  ["singular+short"] = "gls", ["plural+short"] = "glspl",
  ["singular+long"] = "acrlong", ["plural+long"] = "acrlongpl",
  ["singular+abbrv"] = "acrshort", ["plural+abbrv"] = "acrshortpl",
  ["singular+full"] = "acrfull", ["plural+full"] = "acrfullpl",
}
local function glossary_span(span)
  local key = span.attributes["acronym-label"]
  if not key then return nil end
  local form = span.attributes["acronym-form"] or "singular+short"
  local cmd = GLS_CMD[form] or "gls"
  local a = acronyms[key]
  local text = key
  if a then
    local plural = form:match("^plural") and "s" or ""
    if form:match("long$") then text = a.long .. plural
    elseif form:match("full$") then text = a.long .. plural .. " (" .. a.short .. plural .. ")"
    else text = a.short .. plural end
  end
  return {
    pandoc.RawInline("latex", "\\" .. cmd .. "{" .. key .. "}"),
    pandoc.Span({ pandoc.Str(text) }, pandoc.Attr("", { "content-visible" }, { { "when-format", "html" } })),
  }
end

function Pandoc(doc)
  local ac = doc.meta["labtex-acronyms"]
  if ac then
    local ok, decoded = pcall(pandoc.json.decode, stringify(ac))
    if ok and type(decoded) == "table" then acronyms = decoded end
  end
  doc.meta["labtex-acronyms"] = nil
  if doc.meta["labtex-xrefs"] ~= nil then xrefs = doc.meta["labtex-xrefs"] == true end
  doc.meta["labtex-xrefs"] = nil
  rawcites = doc.meta["labtex-rawcites"] == true
  doc.meta["labtex-rawcites"] = nil
  keep_maketitle = doc.meta["labtex-keepmaketitle"] == true
  doc.meta["labtex-keepmaketitle"] = nil

  -- Drop preamble leftovers that pandoc emitted before the body marker.
  local blocks = pandoc.Blocks({})
  local seen = false
  for _, b in ipairs(doc.blocks) do
    if seen then blocks:insert(b)
    elseif stringify(b) == "LABTEXBODYSTART" then seen = true end
  end
  if seen then doc.blocks = blocks end

  if xrefs then collect(doc) end

  doc = doc:walk({
    Span = function(sp) return glossary_span(sp) end,
    RawBlock = function(r)
      if r.format ~= "latex" and r.format ~= "tex" then return nil end
      local t = r.text:gsub("^%s+", ""):gsub("%s+$", "")
      if t == "\\centering" or t == "\\raggedright" or t == "\\noindent" then return {} end
      -- \tableofcontents stays where the author put it (Quarto's `toc` would always go first).
      if t == "\\tableofcontents" then want_toc = true; return r end
      if (t == "\\maketitle" and not keep_maketitle) or t:match("^\\bibliographystyle") or t:match("^\\bibliography{") or t == "\\printbibliography" then return {} end
      stats.raw_blocks = stats.raw_blocks + 1
      if xrefs then r.text = rewrite_refs_in_raw(r.text) end
      return r
    end,
    Header = function(h)
      if xrefs and labelmap[h.identifier] then h.identifier = labelmap[h.identifier] end
      return h
    end,
    Figure = function(f)
      if xrefs and labelmap[f.identifier] then f.identifier = labelmap[f.identifier] end
      return figure_to_quarto(f)
    end,
    Div = function(d)
      if xrefs and #d.content == 1 and (d.content[1].t == "Table" or d.content[1].t == "Figure") and labelmap[d.identifier] then
        local inner = d.content[1]
        inner.identifier = labelmap[d.identifier]
        return inner
      end
    end,
    Table = function(t)
      if xrefs and labelmap[t.identifier] then t.identifier = labelmap[t.identifier] end
      return t
    end,
  })

  -- Equations and references (second pass, now that ids are known).
  doc = doc:walk({
    Inlines = function(inlines)
      local i = 1
      while i <= #inlines do
        local el = inlines[i]
        if el.t == "Math" and el.mathtype == "DisplayMath" then
          local lbl = label_in_math(el.text)
          local body = el.text:gsub("\\begin{equation%*?}%s*", ""):gsub("%s*\\end{equation%*?}", "")
          if xrefs and lbl and labelmap[lbl] then
            body = body:gsub("%s*\\label%s*{[^}]+}%s*", "\n")
            body = body:gsub("^%s+", ""):gsub("%s+$", "")
            inlines[i] = pandoc.RawInline("markdown", "$$\n" .. body .. "\n$$ {#" .. labelmap[lbl] .. "}")
            stats.xrefs = stats.xrefs + 1
          elseif body ~= el.text then
            el.text = body:gsub("^%s+", ""):gsub("%s+$", "")
          end
        elseif el.t == "RawInline" and (el.format == "latex" or el.format == "tex") then
          local cmd, lbl = el.text:match("^\\(%a*ref)%s*{([^}]+)}$")
          if xrefs and cmd and (cmd == "ref" or cmd == "eqref" or cmd == "autoref" or cmd == "cref" or cmd == "Cref") then
            local id = labelmap[lbl]
            if id then
              local prev = inlines[i - 1]
              local had_word = prev and prev.t == "Str" and strip_prefix(inlines, i) ~= nil
              if had_word and inlines[i - 1] ~= prev then i = i - 1 end
              if had_word then
                -- "Figure~\ref{x}": Quarto writes the word itself (@fig-x -> "Figure 1")
                inlines[i] = pandoc.Cite({ pandoc.Str("@" .. id) }, { pandoc.Citation(id, "AuthorInText") })
              else
                -- a bare \ref: number only ([-@fig-x]); \eqref keeps its parentheses
                local c = pandoc.Cite({ pandoc.Str("[-@" .. id .. "]") }, { pandoc.Citation(id, "SuppressAuthor") })
                if cmd == "eqref" then
                  inlines[i] = pandoc.Str("(")
                  inlines:insert(i + 1, c)
                  inlines:insert(i + 2, pandoc.Str(")"))
                  i = i + 2
                else
                  inlines[i] = c
                end
              end
              stats.xrefs = stats.xrefs + 1
            else
              stats.unresolved[#stats.unresolved + 1] = lbl
              stats.raw_inlines = stats.raw_inlines + 1
            end
          elseif el.text:match("^\\labtexlogo{") then
            -- TeX logo: the real command for PDF, plain text for HTML
            local name = el.text:match("^\\labtexlogo{(%w+)}")
            local plain = ({ LaTeX = "LaTeX", TeX = "TeX", LaTeXe = "LaTeX2e", BibTeX = "BibTeX" })[name] or name
            inlines[i] = pandoc.RawInline("latex", "\\" .. name .. "{}")
            inlines:insert(i + 1, pandoc.Span({ pandoc.Str(plain) }, pandoc.Attr("", { "content-visible" }, { { "when-format", "html" } })))
            i = i + 1
          elseif el.text:match("^\\cite") or el.text:match("^\\[Cc]ite") then
            -- citation text inside Cite elements; handled by the writer
          else
            stats.raw_inlines = stats.raw_inlines + 1
            if xrefs then el.text = rewrite_refs_in_raw(el.text) end
          end
        elseif el.t == "Cite" then
          if rawcites then
            -- keep the original \cite{...} (its content is the raw LaTeX when raw_tex is on)
            local raw = nil
            for _, c in ipairs(el.content) do if c.t == "RawInline" then raw = c end end
            if raw then inlines[i] = raw end
          else
            -- Make the citation's visible content plain so the markdown writer emits [@key].
            el.content = {}
          end
        end
        i = i + 1
      end
      return inlines
    end,
  })

  if want_toc then doc.meta.toc = true end
  doc.meta["labtex-stats"] = pandoc.MetaMap({
    raw_blocks = tostring(stats.raw_blocks),
    raw_inlines = tostring(stats.raw_inlines),
    xrefs = tostring(stats.xrefs),
    unresolved = pandoc.MetaList(stats.unresolved),
  })
  return doc
end
