// Turns raw TeX tool output into short, readable diagnostics.
//  - explain(): a one-line "what this means / how to fix it" hint for common LaTeX errors
//  - parseBibtexLog() / parseBiberLog(): errors and warnings from the bibliography tools,
//    which LaTeX's own log knows nothing about
//  - latexmkSummary(): latexmk's "Collected error summary", as a last resort

/** Every place a command appears in the project's .tex files (ignoring comments). */
export function findCommand(sources, cmd) {
  const hits = [];
  const re = new RegExp(`\\\\${cmd}\\s*(\\[[^\\]]*\\])?\\s*\\{([^}]*)\\}`, 'g');
  for (const [file, text] of sources) {
    if (!/\.(tex|ltx|sty|cls)$/i.test(file)) continue;
    text.split('\n').forEach((line, i) => {
      const code = line.replace(/(^|[^\\])%.*$/, '$1');
      let m; re.lastIndex = 0;
      while ((m = re.exec(code))) hits.push({ file, line: i + 1, arg: m[2].trim() });
    });
  }
  return hits;
}

const where = (h) => `${h.file} line ${h.line}`;
const listOr = (xs) => (xs.length <= 1 ? xs.join('') : xs.slice(0, -1).join(', ') + ' and ' + xs[xs.length - 1]);

/**
 * BibTeX's .blg. BibTeX treats "no \cite commands" as an error, but the PDF is fine, so we
 * report it as a warning; everything else that stops BibTeX is an error.
 */
export function parseBibtexLog(blg, sources) {
  const errors = [], warnings = [];
  if (!blg) return { errors, warnings };
  const lines = blg.split(/\r?\n/);
  const seen = new Set();
  const add = (list, e) => { const k = e.message + e.file + e.line; if (!seen.has(k)) { seen.add(k); list.push(e); } };
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    let m;
    if (/^Illegal, another \\bibstyle command/.test(l)) {
      const hits = findCommand(sources, 'bibliographystyle');
      add(errors, {
        file: hits[1]?.file || hits[0]?.file || null, line: hits[1]?.line || hits[0]?.line || null, source: 'BibTeX',
        message: 'BibTeX: \\bibliographystyle is used more than once.',
        hint: hits.length > 1
          ? `Found ${listOr(hits.map((h) => `\\bibliographystyle{${h.arg}} (${where(h)})`))}. A document can have only one bibliography style; delete or comment out the one you don't want. BibTeX is currently using the first one, {${hits[0].arg}}.`
          : 'A document can have only one bibliography style. Remove the extra \\bibliographystyle (it may come from a class or package you load).',
      });
    } else if (/^Illegal, another \\bibdata command/.test(l)) {
      const hits = findCommand(sources, 'bibliography');
      add(errors, { file: hits[1]?.file || null, line: hits[1]?.line || null, source: 'BibTeX', message: 'BibTeX: \\bibliography is used more than once.',
        hint: `${hits.length > 1 ? `Found it at ${listOr(hits.map(where))}. ` : ''}Use a single \\bibliography{a,b} listing all your .bib files.` });
    } else if (/^I found no \\citation commands/.test(l)) {
      const bib = findCommand(sources, 'bibliography')[0];
      add(warnings, { file: bib?.file || null, line: bib?.line || null, source: 'BibTeX',
        message: 'BibTeX: the document has no \\cite commands yet, so the bibliography is empty.',
        hint: 'Cite something with \\cite{key} (keys are in your .bib file), or add \\nocite{*} before \\bibliography to list every entry. This doesn\'t stop the PDF from being made.' });
    } else if (/^I found no \\bibdata command/.test(l)) {
      add(errors, { file: null, line: null, source: 'BibTeX', message: 'BibTeX: no \\bibliography{...} command.',
        hint: 'You cite sources but never say which .bib file to use. Add \\bibliography{yourfile} (without .bib) where the reference list should go.' });
    } else if (/^I found no \\bibstyle command/.test(l)) {
      add(errors, { file: null, line: null, source: 'BibTeX', message: 'BibTeX: no \\bibliographystyle{...} command.',
        hint: 'Add \\bibliographystyle{plain} (or ieeetr, unsrt, abbrv, ...) next to \\bibliography.' });
    } else if ((m = l.match(/^I couldn't open database file (.*)$/))) {
      const name = m[1].trim();
      const bib = findCommand(sources, 'bibliography').find((h) => h.arg.split(',').some((x) => name.startsWith(x.trim())));
      add(errors, { file: bib?.file || null, line: bib?.line || null, source: 'BibTeX', message: `BibTeX can't find the bibliography file "${name}".`,
        hint: 'Check that the file is in the project and that the name in \\bibliography{...} matches it exactly (it\'s case-sensitive, leave off ".bib", and avoid spaces in the name).' });
    } else if ((m = l.match(/^I couldn't open style file (.*)$/))) {
      const name = m[1].trim();
      const st = findCommand(sources, 'bibliographystyle')[0];
      add(errors, { file: st?.file || null, line: st?.line || null, source: 'BibTeX', message: `BibTeX can't find the bibliography style "${name}".`,
        hint: 'Check the spelling in \\bibliographystyle{...}, or upload the .bst file to the project.' });
    } else if ((m = l.match(/^Warning--I didn't find a database entry for "(.*)"/))) {
      add(warnings, { file: null, line: null, source: 'BibTeX', message: `Citation "${m[1]}" isn't in your .bib file.`,
        hint: 'Check the key in \\cite{...} against your .bib file (keys are case-sensitive).' });
    } else if ((m = l.match(/^Warning--(.*)$/))) {
      const loc = (lines[i + 1] || '').match(/^--line (\d+) of file (.*)$/);
      add(warnings, { file: loc?.[2] || null, line: loc ? Number(loc[1]) : null, source: 'BibTeX', message: `BibTeX: ${m[1]}` });
    } else if ((m = l.match(/^(.*)---line (\d+) of file (.*)$/))) {
      // Syntax errors in a .bib (or .aux) file. The next lines show the offending text.
      const what = m[1].trim(), file = m[3].trim(), line = Number(m[2]);
      if (/\.aux$/.test(file)) continue;
      const context = lines.slice(i + 1, i + 3).filter((x) => /^ : /.test(x)).map((x) => x.slice(3)).join('');
      let hint = 'Check this entry for a missing comma, brace or quote.';
      if (/^Repeated entry/.test(what)) hint = 'Two entries in the .bib file use the same key. Rename or delete one of them.';
      else if (/expecting a `,' or a `}'/.test(what)) hint = 'The previous field is missing a comma at the end, or a brace isn\'t closed.';
      else if (/entry type/.test(what)) hint = 'Entries must start like @article{key, ... — check the line for a stray @ or a typo.';
      add(errors, { file, line, source: 'BibTeX', message: `BibTeX: ${what}${context ? ` near "${context.replace(/\s+/g, ' ').trim().slice(-60)}"` : ''}`, hint });
    }
  }
  return { errors, warnings };
}

/** Biber's .blg (biblatex). */
export function parseBiberLog(blg) {
  const errors = [], warnings = [];
  if (!blg) return { errors, warnings };
  for (const l of blg.split(/\r?\n/)) {
    const m = l.match(/^\[\d+\] [\w:.]+> (ERROR|WARN) - (.*)$/) || l.match(/^(ERROR|WARN) - (.*)$/);
    if (!m) continue;
    let msg = m[2].trim(), file = null, line = null, hint;
    const loc = msg.match(/BibTeX subsystem: .*?([^/\\]+?\.bib)(?:_\d+\.utf8)?, line (\d+), (.*)$/);
    if (loc) { file = loc[1]; line = Number(loc[2]); msg = loc[3]; hint = 'Check this entry for a missing comma, brace or quote.'; }
    const nf = msg.match(/Cannot find '([^']+)'/);
    if (nf) hint = `Check that ${nf[1]} is in the project and that \\addbibresource{...} uses the exact name, including ".bib".`;
    if (/^Datasource .* not found/.test(msg)) hint = 'Check that the .bib file is in the project and that \\addbibresource{...} uses the exact name, including ".bib".';
    const missing = msg.match(/I didn't find a database entry for '([^']+)'/);
    if (missing) { msg = `Citation "${missing[1]}" isn't in your .bib file.`; hint = 'Check the key in \\cite{...} against your .bib file (keys are case-sensitive).'; }
    (m[1] === 'ERROR' ? errors : warnings).push({ file, line, source: 'Biber', message: `Biber: ${msg}`, hint });
  }
  return { errors, warnings };
}

/** latexmk's own list of failed steps, e.g. "makeglossaries thesis: Command failed". */
export function latexmkSummary(output) {
  const i = output.lastIndexOf('Collected error summary');
  if (i < 0) return [];
  return output.slice(i).split('\n').slice(1).map((l) => l.trim()).filter((l) => l && !/^Latexmk:/.test(l)).slice(0, 6).map((l) => {
    let hint;
    if (/^bibtex/.test(l)) hint = 'BibTeX (the bibliography tool) reported a problem. Open the raw log and look for the .blg section.';
    else if (/^biber/.test(l)) hint = 'Biber (the biblatex bibliography tool) reported a problem.';
    else if (/makeglossaries|makeindex|xindy/.test(l)) hint = 'Building the glossary, list of acronyms or index failed. Check \\newglossaryentry / \\newacronym definitions for typos.';
    return { file: null, line: null, message: l, hint };
  });
}

// ---------------------------------------------------------------------------
// Plain-English hints for common LaTeX errors
// ---------------------------------------------------------------------------

const RULES = [
  [/^Undefined control sequence/, (m, ctx) => {
    const cmd = (ctx.match(/(\\[A-Za-z@]+)\s*$/) || [])[1];
    return `${cmd ? `${cmd} isn't defined` : 'A command isn\'t defined'}. Check the spelling, or add the \\usepackage{...} that provides it.`;
  }],
  [/^LaTeX Error: File `([^']+)\.(sty|cls)' not found/, (m) => `The ${m[2] === 'cls' ? 'document class' : 'package'} "${m[1]}" isn't installed on this server. Check the spelling, upload ${m[1]}.${m[2]} to the project, or ask your admin to install it.`],
  [/^LaTeX Error: File `([^']+)' not found/, (m) => `The file "${m[1]}" isn't in the project. Check the name and folder (they're case-sensitive) or upload it.`],
  [/^LaTeX Error: Unknown graphics extension: (.*)\./, (m) => `pdfLaTeX can't include ${m[1]} images. Convert the figure to PDF, PNG or JPG.`],
  [/^Package pdftex.def Error: File `([^']+)' not found/, (m) => `The image "${m[1]}" isn't in the project. Check the path in \\includegraphics (and \\graphicspath).`],
  [/^LaTeX Error: Environment (\S+) undefined/, (m) => `\\begin{${m[1]}} isn't defined. Check the spelling, or load the package that provides it.`],
  [/^LaTeX Error: \\begin\{(\S+)\} on input line (\d+) ended by \\end\{(\S+)\}/, (m) => `\\begin{${m[1]}} (line ${m[2]}) is closed by \\end{${m[3]}}. Make sure every \\begin has a matching \\end, in the right order.`],
  [/^LaTeX Error: \\begin\{document\} ended by \\end\{(\S+)\}/, (m) => `There's an extra \\end{${m[1]}} with no matching \\begin.`],
  [/^LaTeX Error: Missing \\begin\{document\}/, () => 'Text appears before \\begin{document}, or there\'s a typo in the preamble. Look for stray characters above \\begin{document}.'],
  [/^LaTeX Error: Can be used only in preamble/, () => 'This command (e.g. \\usepackage) must go before \\begin{document}.'],
  [/^LaTeX Error: Option clash for package ([^\s.]+)/, (m) => `${m[1]} is loaded twice with different options. Load it once, or pass the options with \\PassOptionsToPackage before the first load.`],
  [/^LaTeX Error: Command (\S+) already defined/, (m) => `${m[1]} is defined twice, often by two packages. Use \\renewcommand, or rename your command.`],
  [/^LaTeX Error: There's no line here to end/, () => '\\\\ is used where there\'s no line to break (e.g. on an empty line or right after a list). Remove it or use \\vspace.'],
  [/^LaTeX Error: Something's wrong--perhaps a missing \\item/, () => 'A list environment (itemize/enumerate) has text that isn\'t inside an \\item.'],
  [/^LaTeX Error: Unicode character (.) \(U\+([0-9A-F]+)\)/, (m) => `The character "${m[1]}" (U+${m[2]}) isn't supported by pdfLaTeX. Replace it, or switch the compiler to XeLaTeX/LuaLaTeX in Settings.`],
  [/^LaTeX Error: Too many unprocessed floats/, () => 'Too many figures/tables are waiting to be placed. Add \\clearpage, or use fewer [h] placements.'],
  [/^LaTeX Error: Not in outer par mode/, () => 'A figure or table is inside something that can\'t hold floats (a box, minipage or another float).'],
  [/^Missing \$ inserted/, () => 'Math is used outside math mode: wrap it in $...$, or escape characters like _ and ^ in normal text (\\_ and \\^{}).'],
  [/^Extra \}, or forgotten \$/, () => 'There\'s an extra } or a missing $. Check that braces and $ signs are balanced.'],
  [/^Missing \} inserted/, () => 'A { isn\'t closed. Check that braces are balanced.'],
  [/^Too many \}'s/, () => 'There\'s an extra }. Check that braces are balanced.'],
  [/^Extra alignment tab has been changed to \\cr/, () => 'A table row has more & columns than the table defines. Check the column spec, e.g. {lcr}.'],
  [/^Misplaced alignment tab character &/, () => 'An & is used outside a table. Write \\& for an ampersand in text.'],
  [/^Paragraph ended before (\S+) was complete/, (m) => `The argument of ${m[1]} runs into a blank line, usually a missing }.`],
  [/^File ended while scanning use of (\S+)/, (m) => `The argument of ${m[1]} is never closed, usually a missing }.`],
  [/^Display math should end with \$\$/, () => 'Display math isn\'t closed properly. Check for a missing $$ or \\].'],
  [/^Double subscript/, () => 'Two _ in a row: group them with braces, e.g. x_{i_j}.'],
  [/^Double superscript/, () => 'Two ^ in a row: group them with braces, e.g. x^{a^b}.'],
  [/^Illegal unit of measure/, () => 'A length is missing its unit (pt, cm, mm, in, em...).'],
  [/^Dimension too large/, () => 'A length is too large, often from scaling an image or a bad coordinate.'],
  [/^You can't use `\\prevdepth' in vertical mode|^You can't use `macro parameter character #'/, () => 'A # appears in normal text: write \\# instead.'],
  [/^Package biblatex Error: File '([^']+)' not created by biblatex/, (m) => `${m[1]} was made by BibTeX, not Biber. Recompile to rebuild it, or delete it from the project.`],
  [/^Package natbib Error: Bibliography not compatible with author-year citations/, () => 'natbib is in author-year mode but the bibliography style is numeric. Use \\usepackage[numbers]{natbib} or an author-year style like plainnat.'],
  [/^Package fontspec Error: The font "([^"]+)" cannot be found/, (m) => `The font "${m[1]}" isn't installed on this server. Use a different font name.`],
  [/^Package fontspec Error: The fontspec package requires either XeTeX or LuaTeX/, () => 'fontspec needs XeLaTeX or LuaLaTeX. Change the compiler in Settings.'],
  [/^Package inputenc Error: Unicode character/, () => 'A character isn\'t supported by pdfLaTeX. Replace it, or switch the compiler to XeLaTeX/LuaLaTeX in Settings.'],
  [/^Package (\S+) Error: (.*)/, (m) => null],
  [/^Emergency stop/, () => 'LaTeX stopped early because of the error above, so the PDF may be incomplete.'],
  [/^TeX capacity exceeded/, () => 'Usually an infinite loop, e.g. a command that calls itself or a \\renewcommand that refers to the old version of the command.'],
];

/** Adds a `hint` to each LaTeX error we recognise. */
export function explain(errors) {
  // "Emergency stop" only repeats that an earlier error was fatal.
  if (errors.length > 1) for (let i = errors.length - 1; i >= 0; i--) if (/^(\*\*\* \(job aborted.*|Emergency stop\.?)$/.test(errors[i].message.split('\n')[0])) errors.splice(i, 1);
  for (const e of errors) {
    if (e.hint) continue;
    const [first, ...rest] = e.message.split('\n');
    const msg = first.replace(/^LaTeX Error:/, 'LaTeX Error:').trim();
    for (const [re, fn] of RULES) {
      const m = msg.match(re);
      if (m) { const h = fn(m, rest.join(' ')); if (h) e.hint = h; break; }
    }
  }
  return errors;
}
