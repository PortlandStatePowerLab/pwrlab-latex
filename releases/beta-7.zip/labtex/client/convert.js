// Convert files between LaTeX (.tex) and Quarto (.qmd), one at a time or in batches.
//   openConvertDialog({ mode: 'project', project, canEdit, preselect, onOpenFile })
//   openConvertDialog({ mode: 'upload' })
import { h, api, modal, toast } from './util.js';

const STORE = 'labtex.convert';
const DEFAULTS = {
  output: 'project', onConflict: 'keep-both',
  xrefs: true, preamble: true, rawLatex: true, htmlFormat: true, citeMethod: 'auto',
  wrap: 'none', columns: 80,
  figureFormat: 'keep', dpi: 300, quality: 90,
  inputEncoding: 'auto', outputBom: false, lineEndings: 'lf', zipLevel: 6,
};
const load = () => {
  let o;
  try { o = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(STORE) || '{}') }; } catch { o = { ...DEFAULTS }; }
  if (!['keep', 'png', 'jpeg'].includes(o.figureFormat)) o.figureFormat = 'keep';
  return o;
};
const save = (o) => { try { localStorage.setItem(STORE, JSON.stringify(o)); } catch {} };
const DIR_LABEL = { tex2qmd: 'LaTeX → Quarto', qmd2tex: 'Quarto → LaTeX' };
const dirOf = (p) => (/\.tex$/i.test(p) ? 'tex2qmd' : /\.(qmd|md)$/i.test(p) ? 'qmd2tex' : null);

export async function openConvertDialog(cfg) {
  const isProject = cfg.mode === 'project';
  const opts = load();
  if (isProject && !cfg.canEdit && opts.output === 'project') opts.output = 'new';
  if (!isProject && !['zip', 'projects'].includes(opts.output)) opts.output = 'zip';
  if (isProject && !['project', 'new', 'zip'].includes(opts.output)) opts.output = cfg.canEdit ? 'project' : 'new';

  let candidates = [];
  if (isProject) {
    try { candidates = await api(`/api/projects/${cfg.project.id}/convertible`); }
    catch (e) { toast(e.message, 'error'); return; }
  }
  const selected = new Set(isProject ? (cfg.preselect ? [cfg.preselect] : candidates.filter((c) => c.isMain).map((c) => c.path)) : []);
  const uploads = []; // File objects (upload mode)

  return modal(isProject ? 'Convert files: LaTeX ⇄ Quarto' : 'Convert files: LaTeX ⇄ Quarto', (close) => {
    const root = h('div', { class: 'cv' });

    // ---------- helpers for form controls ----------
    const bind = (key, el, parse = (v) => v) => {
      const get = () => (el.type === 'checkbox' ? el.checked : parse(el.value));
      el.addEventListener('change', () => { opts[key] = get(); save(opts); refresh(); });
      el.addEventListener('input', () => { if (el.type === 'range' || el.type === 'number') { opts[key] = get(); refreshLabels(); } });
      return el;
    };
    const check = (key, label, hint) => h('label', { class: 'cv-check', title: hint || null }, bind(key, h('input', { type: 'checkbox', checked: !!opts[key] })), h('span', {}, label));
    const select = (key, choices) => bind(key, h('select', {}, choices.map(([v, l]) => h('option', { value: v, selected: String(opts[key]) === String(v) }, l))), (v) => (/^\d+$/.test(v) ? Number(v) : v));
    const range = (key, min, max, step = 1) => bind(key, h('input', { type: 'range', min, max, step, value: opts[key] }), Number);
    const valueLabels = {};
    const val = (key, fmt) => (valueLabels[key] = { el: h('span', { class: 'cv-val' }), fmt });
    const refreshLabels = () => { for (const [k, { el, fmt }] of Object.entries(valueLabels)) el.textContent = fmt(opts[k]); };

    // ---------- file selection ----------
    const filesBox = h('div', { class: 'cv-files' });
    const drawFiles = () => {
      if (isProject) {
        if (!candidates.length) { filesBox.replaceChildren(h('p', { class: 'muted' }, 'This project has no .tex or .qmd files.')); return; }
        filesBox.replaceChildren(
          h('div', { class: 'cv-files-head' }, h('strong', {}, 'Files to convert'),
            h('div', { class: 'spacer' }),
            h('button', { class: 'btn tiny', type: 'button', onclick: () => { candidates.forEach((c) => selected.add(c.path)); drawFiles(); refresh(); } }, 'All'),
            h('button', { class: 'btn tiny', type: 'button', onclick: () => { selected.clear(); drawFiles(); refresh(); } }, 'None')),
          h('div', { class: 'cv-list' }, candidates.map((c) => h('label', { class: 'cv-file' },
            h('input', { type: 'checkbox', checked: selected.has(c.path), onchange: (e) => { e.target.checked ? selected.add(c.path) : selected.delete(c.path); refresh(); } }),
            h('code', {}, c.path), c.isMain && h('span', { class: 'badge' }, 'main'),
            h('span', { class: `cv-dir cv-${c.direction}` }, DIR_LABEL[c.direction])))),
          h('p', { class: 'hint' }, 'Files pulled in with \\input/\\include are converted together with the main document, so you normally only need the main file.'));
      } else {
        const input = h('input', { type: 'file', multiple: true, hidden: true, accept: '.tex,.qmd,.md,.zip,.bib,.png,.jpg,.jpeg,.pdf,.eps,.svg,.webp,.gif,.sty,.cls,.bst', onchange: () => { add([...input.files]); input.value = ''; } });
        const drop = h('div', {
          class: 'cv-drop', tabindex: '0', role: 'button',
          onclick: () => input.click(), onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } },
          ondragover: (e) => { e.preventDefault(); drop.classList.add('over'); }, ondragleave: () => drop.classList.remove('over'),
          ondrop: (e) => { e.preventDefault(); drop.classList.remove('over'); add([...e.dataTransfer.files]); },
        }, h('strong', {}, 'Drop files here or click to choose'),
        h('span', {}, '.tex / .qmd documents (with their .bib and figures), or .zip projects (e.g. Overleaf downloads). Each .zip is converted separately.'));
        filesBox.replaceChildren(drop, input, uploads.length ? h('div', { class: 'cv-list' }, uploads.map((f, i) => h('div', { class: 'cv-file' },
          h('code', {}, f.name), h('span', { class: 'muted small' }, sizeOf(f.size)),
          dirOf(f.name) ? h('span', { class: `cv-dir cv-${dirOf(f.name)}` }, DIR_LABEL[dirOf(f.name)]) : /\.zip$/i.test(f.name) ? h('span', { class: 'cv-dir' }, 'project .zip') : h('span', { class: 'muted small' }, 'supporting file'),
          h('button', { class: 'icon-btn', type: 'button', 'aria-label': `Remove ${f.name}`, onclick: () => { uploads.splice(i, 1); drawFiles(); refresh(); } }, '✕')))) : null);
      }
    };
    const add = (files) => { for (const f of files) if (!uploads.some((u) => u.name === f.name && u.size === f.size)) uploads.push(f); drawFiles(); refresh(); };

    // ---------- settings ----------
    const outputChoices = isProject
      ? [['project', 'Add to this project', !cfg.canEdit], ['new', 'Create a new project'], ['zip', 'Download as .zip']]
      : [['zip', 'Download as .zip'], ['projects', 'Create LabTeX projects']];
    const outputRadios = h('div', { class: 'cv-radios', role: 'radiogroup', 'aria-label': 'Output' }, outputChoices.map(([v, l, disabled]) => h('label', { class: 'cv-radio' + (disabled ? ' disabled' : '') },
      h('input', { type: 'radio', name: 'cv-output', value: v, checked: opts.output === v, disabled, onchange: () => { opts.output = v; save(opts); refresh(); } }), l)));
    const conflictRow = h('label', { class: 'cv-row' }, h('span', {}, 'If a file already exists'), select('onConflict', [['keep-both', 'Keep both (add “-converted”)'], ['replace', 'Replace it']]));
    const columnsInput = bind('columns', h('input', { type: 'number', min: 40, max: 200, value: opts.columns, class: 'cv-num' }), Number);

    const figureControls = h('div', { class: 'cv-grid' },
      h('label', { class: 'cv-row' }, h('span', {}, 'Resolution'), h('div', { class: 'cv-range' }, range('dpi', 72, 600, 6), val('dpi', (v) => `${v} dpi`).el)),
      h('label', { class: 'cv-row', 'data-show': 'lossy' }, h('span', {}, 'JPEG quality'), h('div', { class: 'cv-range' }, range('quality', 10, 100), val('quality', (v) => `${v}%`).el)));

    const settings = h('div', { class: 'cv-settings' },
      h('fieldset', {}, h('legend', {}, 'Output'), outputRadios, isProject && conflictRow),
      h('fieldset', {}, h('legend', {}, 'Formatting & content'),
        check('xrefs', 'Convert cross-references (\\label/\\ref ⇄ @fig-…, @tbl-…, @eq-…, @sec-…)'),
        check('preamble', 'Preserve document class, packages, macros and page layout', 'Carried into the Quarto YAML so the PDF looks like the original'),
        check('rawLatex', 'Keep LaTeX that has no Markdown equivalent (as raw LaTeX)', 'Turn off to drop it instead; raw LaTeX only appears in PDF output'),
        check('htmlFormat', 'Add an HTML format to Quarto files'),
        h('label', { class: 'cv-row' }, h('span', {}, 'Citations'), select('citeMethod', [['auto', 'Automatic (as in the source)'], ['natbib', 'natbib (\\citep, \\citet)'], ['biblatex', 'biblatex'], ['citeproc', 'Formatted text (citeproc)']])),
        h('label', { class: 'cv-row' }, h('span', {}, 'Line wrapping'), h('div', { class: 'cv-inline' }, select('wrap', [['none', 'One line per paragraph'], ['columns', 'Wrap at…'], ['preserve', 'Keep original line breaks']]), columnsInput))),
      h('fieldset', {}, h('legend', {}, 'Figures'),
        h('label', { class: 'cv-row' }, h('span', {}, 'PDF/EPS/SVG figures'), select('figureFormat', [['keep', 'Keep as they are'], ['png', 'Convert to PNG (for web pages)'], ['jpeg', 'Convert to JPEG (smaller)']])),
        h('p', { class: 'hint' }, 'Applies when converting to Quarto: browsers can’t show PDF or EPS figures in HTML output, so convert them if you’ll publish to the web. PNG and JPG figures are always kept as they are. When converting to LaTeX, SVG figures are turned into PDF because LaTeX can’t include SVG.'),
        figureControls),
      h('fieldset', {}, h('legend', {}, 'Encoding & download'),
        !isProject && h('label', { class: 'cv-row' }, h('span', {}, 'Text encoding of uploads'), select('inputEncoding', [['auto', 'Detect automatically'], ['utf-8', 'UTF-8'], ['windows-1252', 'Windows-1252 (Western)'], ['iso-8859-1', 'ISO-8859-1 (Latin-1)']])),
        h('label', { class: 'cv-row', 'data-dl': '1' }, h('span', {}, 'Output encoding'), select('outputBom', [['false', 'UTF-8'], ['true', 'UTF-8 with BOM (for some Windows editors)']])),
        h('label', { class: 'cv-row', 'data-dl': '1' }, h('span', {}, 'Line endings'), select('lineEndings', [['lf', 'LF (macOS/Linux)'], ['crlf', 'CRLF (Windows)']])),
        h('label', { class: 'cv-row', 'data-dl': '1' }, h('span', {}, '.zip compression'), h('div', { class: 'cv-range' }, range('zipLevel', 0, 9), val('zipLevel', (v) => (v === 0 ? '0 (store)' : v === 9 ? '9 (smallest)' : String(v))).el)),
        h('p', { class: 'hint', 'data-nodl': '1' }, 'Files added to LabTeX are stored as UTF-8; encoding and line endings apply to downloads.')));

    const status = h('div', { class: 'cv-status', 'aria-live': 'polite' });
    const goBtn = h('button', { class: 'btn primary', type: 'submit' });
    const form = h('form', { onsubmit: (e) => { e.preventDefault(); run(); } },
      h('div', { class: 'cv-body' }, h('div', { class: 'cv-left' }, filesBox), h('div', { class: 'cv-right' }, settings)),
      status,
      h('div', { class: 'modal-actions' }, h('button', { type: 'button', class: 'btn', onclick: () => close() }, 'Close'), goBtn));
    root.append(form);

    function refresh() {
      const n = isProject ? selected.size : uploads.filter((f) => dirOf(f.name) || /\.zip$/i.test(f.name)).length;
      goBtn.textContent = n ? `Convert ${n} ${isProject ? 'file' : 'item'}${n > 1 ? 's' : ''}` : 'Convert';
      goBtn.disabled = !n;
      columnsInput.hidden = opts.wrap !== 'columns';
      conflictRow.hidden = opts.output !== 'project';
      figureControls.classList.toggle('dim', opts.figureFormat === 'keep');
      figureControls.querySelector('[data-show="lossy"]').hidden = opts.figureFormat !== 'jpeg';
      const dl = opts.output === 'zip';
      settings.querySelectorAll('[data-dl]').forEach((el) => (el.hidden = !dl));
      settings.querySelectorAll('[data-nodl]').forEach((el) => (el.hidden = dl));
      refreshLabels();
    }

    async function run() {
      goBtn.disabled = true;
      const payload = { ...opts, outputBom: opts.outputBom === true || opts.outputBom === 'true' };
      if (isProject && opts.output === 'project' && !cfg.canEdit) payload.output = 'new';
      status.replaceChildren(h('div', { class: 'cv-working' }, h('span', { class: 'cv-spin' }), 'Converting… this takes a few seconds per document.'));
      try {
        let r;
        if (isProject) {
          r = await api(`/api/projects/${cfg.project.id}/convert`, { method: 'POST', body: { paths: [...selected], options: payload, output: opts.output } });
        } else {
          const form = new FormData();
          for (const f of uploads) form.append('files', f, f.name);
          form.append('options', JSON.stringify(payload));
          form.append('output', opts.output);
          r = await api('/api/convert', { method: 'POST', form });
        }
        showResults(r);
      } catch (e) {
        status.replaceChildren(h('div', { class: 'form-error' }, e.message));
      } finally { refresh(); }
    }

    function showResults(r) {
      const ok = r.results.filter((x) => x.ok).length;
      const actions = [];
      if (r.download) {
        actions.push(h('a', { class: 'btn primary', href: r.download, download: '' }, '⤓ Download .zip'));
        // Start the download right away too.
        const a = h('a', { href: r.download, download: '' }); document.body.append(a); a.click(); a.remove();
      }
      if (r.projectId) actions.push(h('a', { class: 'btn primary', href: `#/p/${r.projectId}`, onclick: () => close() }, 'Open the new project'));
      if (r.projects?.length) actions.push(...r.projects.map((p) => h('a', { class: 'btn', href: `#/p/${p.id}`, onclick: () => close() }, `Open “${p.name}”`)));
      status.replaceChildren(
        h('div', { class: 'cv-results' },
          h('div', { class: 'cv-summary' }, h('strong', {}, `${ok} of ${r.results.length} converted`), h('div', { class: 'spacer' }), actions),
          r.results.map((x) => h('div', { class: 'cv-result ' + (x.ok ? 'ok' : 'fail') },
            h('div', { class: 'cv-result-head' },
              h('span', { class: 'cv-ico' }, x.ok ? '✓' : '✕'),
              x.bundle && h('span', { class: 'muted small' }, `${x.bundle} / `),
              h('code', {}, x.source), x.ok && [' → ', h('code', {}, x.output)],
              x.direction && h('span', { class: `cv-dir cv-${x.direction}` }, DIR_LABEL[x.direction]),
              h('div', { class: 'spacer' }),
              x.ok && isProject && opts.output === 'project' && r.fileIds?.[x.output] && h('button', { class: 'btn tiny', type: 'button', onclick: () => { close(); cfg.onOpenFile?.(r.fileIds[x.output]); } }, 'Open'),
              x.ok && isProject && opts.output === 'project' && cfg.onSetMain && /\.qmd$/i.test(x.output) && h('button', { class: 'btn tiny', type: 'button', title: 'Make this the main document so the project compiles with Quarto', onclick: () => { close(); cfg.onSetMain(x.output); } }, 'Compile with Quarto')),
            x.error && h('div', { class: 'cv-error' }, x.error),
            x.hint && h('div', { class: 'log-hint' }, h('span', { 'aria-hidden': 'true' }, '💡 '), x.hint),
            x.ok && x.stats && (x.stats.crossRefs || x.stats.rawLatex) ? h('div', { class: 'muted small cv-stats' },
              x.stats.crossRefs ? `${x.stats.crossRefs} cross-reference(s) converted` : '',
              x.stats.crossRefs && x.stats.rawLatex ? ' · ' : '',
              x.stats.rawLatex ? `${x.stats.rawLatex} LaTeX piece(s) kept as raw LaTeX` : '') : null,
            x.warnings?.length ? h('details', { class: 'cv-warn' }, h('summary', {}, `${x.warnings.length} note${x.warnings.length > 1 ? 's' : ''}`),
              h('ul', {}, x.warnings.map((w) => h('li', {}, w)))) : null))));
      status.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      if (ok) toast(`Converted ${ok} file${ok > 1 ? 's' : ''}`, 'ok');
    }

    drawFiles();
    setTimeout(refresh);
    return root;
  }, { wide: true });
}

const sizeOf = (n) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(0)} KB` : `${(n / 1048576).toFixed(1)} MB`);
